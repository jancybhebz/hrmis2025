#
# TABLE STRUCTURE FOR: tblAgency
#

DROP TABLE IF EXISTS `tblAgency`;

CREATE TABLE `tblAgency` (
  `agencyName` varchar(100) NOT NULL DEFAULT '',
  `abbreviation` varchar(10) NOT NULL DEFAULT '',
  `dtrScheme` varchar(10) NOT NULL DEFAULT '',
  `fixedFrom` time DEFAULT '00:00:00',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zipCode` varchar(4) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `facsimile` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(80) NOT NULL DEFAULT '',
  `website` varchar(80) NOT NULL DEFAULT '',
  `fixedTo` time DEFAULT '00:00:00',
  `morningFrom` time DEFAULT '00:00:00',
  `morningTo` time DEFAULT '00:00:00',
  `afternoonFrom` time DEFAULT '00:00:00',
  `afternoonTo` time DEFAULT '00:00:00',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `mins_before_OT` time DEFAULT NULL,
  `minOT` time DEFAULT NULL,
  `maxOT` time DEFAULT NULL,
  `expr_cto_mon` int(11) DEFAULT NULL,
  `expr_cto_yr` int(11) DEFAULT NULL,
  `flagTime` time NOT NULL,
  `autoComputeTax` tinyint(4) NOT NULL,
  `pagibigId` varchar(20) NOT NULL DEFAULT '',
  `gsisId` varchar(20) NOT NULL DEFAULT '',
  `gsisEmpShare` int(4) NOT NULL DEFAULT 0,
  `gsisEmprShare` int(4) NOT NULL DEFAULT 0,
  `pagibigEmpShare` int(4) NOT NULL DEFAULT 0,
  `pagibigEmprShare` int(4) NOT NULL DEFAULT 0,
  `philhealthEmpShare` int(4) DEFAULT 0,
  `philhealthEmprShare` int(11) DEFAULT 0,
  `providentEmpShare` int(4) DEFAULT 0,
  `providentEmprShare` int(4) DEFAULT 0,
  `philhealthPercentage` decimal(4,2) NOT NULL DEFAULT 0.00,
  `lbStartMonth` int(2) NOT NULL DEFAULT 0,
  `lbStartYear` int(4) NOT NULL DEFAULT 0,
  `agencyTin` varchar(25) NOT NULL DEFAULT '',
  `PhilhealthNum` varchar(20) DEFAULT NULL,
  `Vision` mediumtext DEFAULT NULL,
  `Mission` mediumtext DEFAULT NULL,
  `Mandate` mediumtext NOT NULL,
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `region` varchar(20) NOT NULL DEFAULT '',
  `AccountNum` varchar(20) DEFAULT NULL,
  `expirationCTO` datetime DEFAULT NULL,
  PRIMARY KEY (`agencyName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAgency` (`agencyName`, `abbreviation`, `dtrScheme`, `fixedFrom`, `address`, `zipCode`, `telephone`, `facsimile`, `email`, `website`, `fixedTo`, `morningFrom`, `morningTo`, `afternoonFrom`, `afternoonTo`, `salarySchedule`, `mins_before_OT`, `minOT`, `maxOT`, `expr_cto_mon`, `expr_cto_yr`, `flagTime`, `autoComputeTax`, `pagibigId`, `gsisId`, `gsisEmpShare`, `gsisEmprShare`, `pagibigEmpShare`, `pagibigEmprShare`, `philhealthEmpShare`, `philhealthEmprShare`, `providentEmpShare`, `providentEmprShare`, `philhealthPercentage`, `lbStartMonth`, `lbStartYear`, `agencyTin`, `PhilhealthNum`, `Vision`, `Mission`, `Mandate`, `zonecode`, `region`, `AccountNum`, `expirationCTO`) VALUES ('Municipal Government of Paete', 'LGU-PAETE', '', '00:00:00', 'JV Quesada St. Municipal Building Paete, Laguna', '4016', '(049) 501-6475', '0', 'info@paete.gov.ph', 'www.paete.gov.ph', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 'Bi-Monthly', NULL, '00:00:00', '00:00:00', '0', '0', '00:08:00', '0', '2-0496976000-2', '1000021657', '9', '12', '100', '100', '50', '50', '2', '5', '0.00', '1', '2005', '000631660000', '142230100010', 'PAETE, LAGUNA: “The Carving Capital of the Philippines”, endowed with rich natural resources, renowned for world –class artist, with God-centered, warm and industrious people living in a dynamic and peaceful society under consultative, participative, responsive and ethical leadership geared towards people empowerment through transparent and good governance.', 'The Municipal Government of PAETE aims to preserve its arts, heritage, culture and good social values, nurture and enhance its human and natural resources in order to sustain socio-economic development by providing efficient and effective programs, project policies that will protect and manage its ecological and human resources and promote its ecological and human resources and promote its distinctive art products worldwide.', 'The Department is the primary agency responsible for the conservation, management, development, and proper use of the country’s environment and natural resources, specifically forest and grazing lands, mineral resources, including those in reservation and watershed areas, and lands of the public domain, as well as the licensing and regulation of all natural resources as may be provided for by law in order to ensure equitable sharing of the benefits derived therefrom for the welfare of the present and future generations of Filipinos.', '', 'Calabarzon', 'LBP 3302 1038 51', NULL);


#
# TABLE STRUCTURE FOR: tblAgencyImages
#

DROP TABLE IF EXISTS `tblAgencyImages`;

CREATE TABLE `tblAgencyImages` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `agencyLogo` longblob NOT NULL,
  `agencyName` varchar(70) NOT NULL DEFAULT '',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filesize` varchar(50) NOT NULL DEFAULT '',
  `filetype` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAgencyImages` (`id`, `agencyLogo`, `agencyName`, `filename`, `filesize`, `filetype`) VALUES ('57', '�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0`\0\0\0`\0\0\0�w8\0\0\0	pHYs\0\0\0\0\0��\0\0\nOiCCPPhotoshop ICC profile\0\0xڝSgTS�=���BK���KoR RB���&*!	J�!��Q�EEȠ�����Q,�\n��!���������{�kּ������>�����H3Q5��B�������.@�\n$p\0�d!s�#\0�~<<+\"��\0x�\0�M��0���B�\\���t�8K�\0@z�B�\0@F���&S\0�\0`�cb�\0P-\0`\'��\0����{\0[�!��\0 e�D\0h;\0��V�E\0X0\0fK�9\0�-\00IWfH\0��\0���\0\00Q��)\0{\0`�##x\0��\0F�W<�+��*\0\0x��<�$9E�[-qWW.(�I+6aa�@.�y�2�4���\0\0������x����6��_-��\"bb���ϫp@\0\0�t~��,/�\Z�;�m��%�h^�u��f�@�\0���W�p�~<<E���������J�B[a�W}�g�_�W�l�~<�����$�2]�G�����L�ϒ	�b��G�����\"�Ib�X*�Qq�D���2�\"�B�)�%��d��,�>�5\0�j>{�-�]c�K\'Xt���\0\0�o��(�h���w��?�G�%\0�fI�q\0\0^D$.Tʳ?�\0\0D��*�A��,�����`6�B$��BB\nd�r`)��B(�Ͱ*`/�@4�Qh��p.�U�=p�a��(��	A�a!ڈb�X#����!�H�$ ɈQ\"K�5H1R�T UH�=r9�\\F��;�\02����G1���Q=��C��7\Z�F��dt1�����r�\Z=�6��Ыhڏ>C�0��3�l0.��B�8,	�c˱\"���\Z�V����cϱw�E�	6wB aAHXLXN�H� $4�	7	�Q�\'\"��K�&���b21�XH,#��/{�C�7$�C2\'��I��T��F�nR#�,��4H\Z#���dk�9�, +ȅ����3��!�[\n�b@q��S�(R�jJ��4�e�2AU��Rݨ�T5�ZB���R�Q��4u�9̓IK�����\Zhh�i��t�ݕN��W���G���w\r��ǈg(�gw��L�Ӌ�T071���oUX*�*|��\n�J�&�*/T����ުU�U�T��^S}�FU3S�	Ԗ�U��P�SSg�;���g�oT?�~Y��Y�L�OC�Q��_�� c�x,!k\r��u�5�&���|v*�����=���9C3J3W�R�f?�q��tN	�(���~���)�)�4L�1e\\k����X�H�Q�G�6������E�Y��A�J\'\\\'Gg����S�Sݧ\n�M=:��.�k���Dw�n��^��Lo��y���}/�T�m���GX�$��<�5qo</���QC]�@C�a�a�ᄑ��<��F�F�i�\\�$�m�mƣ&&!&KM�M�RM��)�;L;L���͢�֙5�=1�2��כ߷`ZxZ,����eI��Z�Yn�Z9Y�XUZ]�F���%ֻ�����N�N���gð�ɶ�����ۮ�m�}agbg�Ů��}�}��=\r���Z~s�r:V:ޚΜ�?}����/gX���3��)�i�S��Ggg�s�󈋉K��.�>.���Ƚ�Jt�q]�z���������ۯ�6�i�ܟ�4�)�Y3s���C�Q��?��0k߬~OCO�g��#/c/�W�װ��w��a�>�>r��>�<7�2�Y_�7��ȷ�O�o�_��C#�d�z��\0��%g��A�[��z|!��?:�e����A���AA�������!h�쐭!��Α�i�P~���a�a��~\'���W�?�p�X\Z�1�5w��Cs�D�D�Dޛg1O9�-J5*>�.j<�7�4�?�.fY��X�XIlK9.*�6nl��������{�/�]py�����.,:�@L�N8��A*��%�w%�\ny��g\"/�6ш�C\\*N�H*Mz�쑼5y$�3�,幄\'���L\rLݛ:��v m2=:�1����qB�!M��g�g�fvˬe����n��/��k���Y-\n�B��TZ(�*�geWf�͉�9���+��̳�ې7�����ᒶ��KW-X潬j9�<qy�\n�+�V�<���*m�O��W��~�&zMk�^�ʂ��k�U\n�}����]OX/Yߵa���>������(�x��oʿ�ܔ���Ĺd�f�f���-�[����n\r�ڴ\r�V����E�/��(ۻ��C���<��e����;?T�T�T�T6��ݵa��n��{��4���[���>ɾ�UUM�f�e�I���?�������m]�Nmq����#�׹���=TR��+�G�����w-\r6\rU����#pDy���	��\r:�v�{���vg/jB��F�S��[b[�O�>����z�G��4<YyJ�T�i��ӓg�ό���}~.��`ۢ�{�c��jo�t��E���;�;�\\�t���W�W��:_m�t�<���Oǻ�����\\k��z��{f���7����y���՞9=ݽ�zo������~r\'��˻�w\'O�_�@�A�C݇�?[�����j�w����G��������C���ˆ\r��8>99�?r����C�d�&����ˮ/~�����јѡ�򗓿m|������������x31^�V���w�w��O�| (�h���SЧ��������c3-�\0\0\0 cHRM\0\0z%\0\0��\0\0��\0\0��\0\0u0\0\0�`\0\0:�\0\0o�_�F\0\0)�IDATx��}yt$Wy����U�/�n�[j�͌�Y<x�/<!6�k���!/$�?&�`�����m��6�l�Fk����������VK�m$����Q�\\���������R����u��j�4�B)\0`��q\\�a�I�2����\0�1��,WdY��V?�ۂ�T���|>0��\\Y,v�Şj�\"*�\nJ5B��,A�l6ۤ�fv:���N�3�e������,Q?��SQj�ѴL\0\0xޤ�͖��nv�\\G�N��,�0���<�lT(��D\"~��l�]�xlw�\\F�ZC�V�$I�e���R\nB���d�_<A��l���:�?����-��F.4�󛗯PU��U��*U�]�(�MQ8(2AM���_���\n\0`Y�>w�(���;::����}��?\\(�ѹwML�$����\"\n�\"��\n�����\n$I�$I� �8��O�j��f���p��p�f���i�z{����=���m��yQ(��w(J�$��]��*P�i�VI�����������`Y�6�������1�x�\\�Թ0 P,���O=03��fsH��H$�H&�H����r(�J(�˨�jPU���a����/����z��������r��-�ٱc�=��_��t���]��L�b�E ��_\r�A�T�@�H���䋟��\ZE���Á�ZZZ��=�s��u�=O��4�����?y���2�4b�8fg�0;;���y�R)d�Y��T�U(�UUa�n�	�eY�<����������mho����RٝJ%ٱc��m�U���_< K�ߩTv��r@\"$�E\"I��T��D ��J@i�-���fUn��b^f�A�JeW:��������m�8!dl�\Z�iZ���\'>sf��D\"�HdSSS�Ø��\"�ɠT*C�$(���C���p��a���r����G(ԉ��ntv�������;�g�+��q���I�鿖j��=�c����0?��A��A�\0�X��6!���e����dYn��b�K~+B�Ntww����>���K.��6�7��a\rPUu�ر�������b||cc��È��(����a��;EQ�(\n$IB�\\A.�C&�E&�A>�G__/E�.I�\r���d�n���_)��H�(\"��	`r\n���P*� +<O`��P��U���E��\nY�Q.����Ng�N�������EQvH���{��a5&p�E9\'N�����`$2���Q���\"#�J�\\.C��M�UUQ�T`HY�\\F�\\j�2Ji\0�?߷�k�U\n�g����X��\0FG��I \Zr9@�\0E����{�?ShD_ì6wUU�(�Ys�e��6\0O��w������>��gΌ�Dfp��0���155�t:�Z���ԟ�P�r��.\nc�&��d2���K�ް^�p�����wG���(���:�q�Tj���l]s��4�]����=(��^�733���&�����������0&\'�\Z�ov�[9TUE�Z��i�gǁ�����;v�g���С���J��&Ӊ�$0>�@�-��5�β�N�������fittr�앧N��D\"���	���6$�x�����Z�\"���������o�z}o�z}��\"��ҵ�꥟M&��	�S���1�����!�Js�W�A\0ϟ����<������	�R��ԉ�d2�Dfp����02�,j��y\'~�$	�\\�pgΌ5�����(�2��9�����##��I$�?񗛻A���0��N���gEq4߻��x�ht��%099���i�RiT���fvV��Z��l6�H$���)D�Q$q.��@`���R��4����v^��Zs�d��D\"���l��\"��\0��b��i=��ß��򘛛E8F2�D�\\�r�{�R2�D8���,2�,��F�R�j�p���Z��_�Y��\rS��(�a���_!��	�T\Z�H��s�d28sf�/$��v����Ʉ�J�133�h4�B��%��f��R��X}\'	�r9��ξ���r��ו��d������j^ܹ��/�=�/`nn�]K�����T*!�H \Z�W��Ŝ�������#O ��czz򝚦u�T*mw�r���<E&M ��YDӯ�\n~�C�e�ryD�Q��	��y�̄o�4m[��Z5�Ew\n�zb-�J�z�L�r6�R� �ZH����Y���n\0���~]���&�@t� �dP�hPd��h\0��L}Y���ca�)$����9e+����fsW��e�r9���r9��Z�\\u.\nH$��H�R���}-\0d2��$A,F��Sd2\Z�s >�K���\04\nPJ���*�R\'|\Z�\\�j\r�T��: �I��V��X,!�͢X,��H�S+�uI���BL?s��;�;_�JR��@�L�2f�\ndi�w6��O���\Z8���@eY(��)s�U�r9����Z!s���b��M�dT��jUPJa2���x[aK�a85�cq�����|�h<v�+�y��b2�h�j�;	�1��4=\0�C\Z�Uc�A��{�M��$I(�(�udwj����4��T*��I��5�\'K��˩�A\\����Z�5��\\Uۨ+닜8�É\'���Q�� ���mV\n�e ����4\n0@)���k��A�L�6ǔ�FXZ�VQ��P.�I����(NY����d��4�܈�0:��/B4MkTǌ:�Z��忟�;�*\n�<�A��/�L,�y��\0,�s�:C(T�@�umb+_)�\Z�Y? IR���(2E�p���F���\n��ju�B�jC/Z�]��F!ø�W����Fq��40�i���f���R�aP���~�Y���%��h�$\rQS�M&8��?w�~�x��0Z8JU�a�i�H�-���r#�Xr�F(����ĀP�����\"�X,���,�쫯�ֺ�wɊ\"YV �5�R���C�G�����e����Xt�e���)�cT�a�H*�jvh�{B��\Z4M�,K��,��M�!��RHj����qf���������\'\n&Q������Z�M�ʰ\0��\0X,��F~x���i��W�t�\nkX��\Z�e��$I�/����n��#��,w�F��ӧ�=�dY^�fތ3n���@�t�Ҳ<O!&��eU�2��ۏ�m ��c	D�X���*�r�Љ��(��|>����Q\0���lU�U,�M��M�^`]\"Ö9\0�8��8���`�oT@S5�&)]nƻRh��,��<�1�.\'̈́���*!(���p8|���f�\\�����Z����J�77�qo��q\\�\0Ad\'i���X�<��b5��z^E�!\0Y6�,C����n�$�d^2�Litt�C���������cX6��R0S�a2� �f�LB����WD8�tT�EݨKP[�%ɺϐe@UUT\nPB�,�e�J����lvxxĒN�1h�̐i�ҿ�b��e��j�(�p:�c,������ \0��XD<�;׵��	��C(ÃRu��\r���Lh�����Z�\\�����V������5̏(\n������EN��(�)f�A�E\n����8\\,���#��.#����@ԕ��v�/���g���_�e<���j��ʴ��P��`����x�t: �\"ZZ�O.*����/L�R��\0�~���L����4H�4}nt�h�T]i�p�R��3ӣG��eYƓO�<�Մ۪a�~������	��	��ux��J�Lч�v��8�<�)Z�w����\'�x�T�X���8v���G�f��f�����p��������t:\nu�˲ų�P0�a�(����v\r�\0`��Y�M1aLB���V�x�G��i�T�׾���f|��z;�~����}��l��}�֔E��ʽ/��̣n7A(Ġ�����f}�{���*&4�B{����㜢�Q���x���w�����Ӟ��n����=���AOO߯,�芆X��lU��==@W�Ң��[��ڰL�d2���5Mk4����b����{��A�\r�;v����ۃ`0�˅�޾{�Rc\0\\~��ӂp��n7��M�m�����0�9�\'��S���鹹�Fln�!M������СC��-�&�	6��`}}}����ۂ;v}U�Sk�\"�\\sɗ�֩�����;v�����L`�/��R���?�~���T�A����@h~~�\"߆@ ���>���!����TWW�}X���<�\\�����#� �};�� ���|z���.�B066&�q�]���t��H$����}���F��6�l۶\r��;��Յ��vi׮=�\"�L�;\Z�W��\"�t�\'B!`�N`�`�6�`;�tR�\n��F�\0�W��bm�8�y$	�v�mr<_dr��J)�~�����kx����.Ҍh��v������ؽ{W����{�M&��Ȳa�j�����>|%!��dٖ]���bN`z�A4����*�*���D�̹�����w\"��-�ܒ:y�dKs1������i.~����a��O�{ｻ��E��3���r��a6��v��ޮ����~tuu���\r|��j]q�䚆�Uο���W2L�a�\r�I4�\\��K13K0?K�L1��)L&������,�R\"f���o�?~����,-i\Z�7�o8�|p�$�N}�3��4ʣ�x��W-� ����m6+|>:::��ۃ��.�����о[�v�KXe��,��}��\0��С�0��=`�\n�	�ڀ� E,���K����G\0(�8v#y�����S������xC�\r,׭a0A/+.0�ᇿ�sxx$���޹m�6�j�eDcU�S\n�O�Y��f�����G{{�P��Ax�-���=�s�%��5W���d���/=������g,���N��\'�Łh� ��P�HC(X�5`���r\Z�N���������4l}��]M��}�q�,�g�}������>y�]�z���\'�X��`}���b������ϋ@�\r~��Ow}�������}q������_~��?(��?�<D�[r9�ZUφJ�Mc���J��*��������655u�\rӲZ�ظw�Y�4\r�T\Zw�u��\'����;���v�5�t��p�&�b#�t:�usӎ@ ��V?�n�������c����s���p0��׼��\0~���>?�7k��z��\\��Vh\Z�j�B�2��]�T0J)���*?��Oƿ���\r����0���^��4s5k����e�F5�І���7�g�y�_~E�-oyK�����|�&�L&k�Z��b=�\n�����΀6�����������06\0ܱ�h��W�	�Kǎ�t���H;��_UV�RU:se.�;�Ng�(2*�r1��F��(�=�ܳ�^x����w7�����R�^�J��QFX�9U�@�Ç����G���V�߿o���ˊ}}}V��G�_͖|>_t:\0l6��;14�wj׮�G�������ϙLB�@Lي�Tw�T�X,�a�ꫫ�p�|��gs�eᰏq8N�J�Rinnnltt�#�N�:<99��ͩ���j%��R��R\'ݬm�����L�S������s�10�/��s�?���=��bS.�sPS�>o�֬nWk��k���W�i���%�,K޹��?����=	��] ss�H&�(PU�����W\\�pD�4D�Q;v���O>���W�ܕH$\ZLXj6���f�.�y�f����r>���[�������*˥��2�v�L��g0xd������<\"ɷ��$Se��rR�\'���[�][���/�7qA�(ʞ����\'&��*�J\"��#�L!\Z�b~>�D\"�|>���Z�մ���0�� ����\r7܀X,��~��/}��MO��q�\"i5���W�#����1`�ޡ�{��W�7��\r���o�!���Uь\Z�j\Z*e32�P� ���s䭄���_N>b6����+���|3�;�N]�����bQK&�E2�B,�=�H �N�X��#4M��6���-��|>�y�Co{����/~���P�Zm4�6���EC˙#��MP::���O�������Ų�k� �^l�\nob!K�j���	�(�d�$u��f�󩧦1����W�o9(��c�:y���L��󘛛���,b�(R�4\n���RC�x���dZ�&X)�`4���n��?}j覛n�~�c�;ڢi��(�46���6wf��މv뭷N�ӟ�\n]g��5P��WT7kbY���R��b1\r�4�H��~O�;e�ۡCG��k.�֖1@��}Ǐ����ɉ�X�pS���\'���P���aA`2���Lc��r�������o�я~�O~��}���X�A/�o����e6���}n��xG�-��i��-��R�ѭd��P`�JQT�s�\Z�3mm@g���Ep�/}�С�뜎�_��\'o��$x��#?	�����s���8\"��J��Y��	rnMR��Y�V�����x</}�_2\"\Z�$���m\"�a~\\.��oD���ڞ��Vn(��U#�$�r	�d�|� ��1!�$��(����ηj�y��#���.�o����9z��ǧ�����a���bt�\"�2�,*�ʪ\0M�I��g|���8����/�,�ˈ\Z�4@���߈���׶-g���xW��F=+�4@��\nP��\"��i�e	J%\r�� ����<���_��A�@)�=q�أ����a�:u\Z###�#���k\"���b�H�����\\.��W���W\Z�g�&(���@�\0��ᡇ�y�k�����I�����܌�����HA�Tk:䙦ttxw���K/�p���>m�螘8s���؞�ٹ:P�����fs��B������㓿��/{B�o�\0�eq�����|��}jn���Q��~��`�i��a*_p�r{V�$�L�|����\'066���Q��d��W��`_�җz|>�\"[o���-��2������B�UU�W�LSS�����E<NQ*���С��]����<u����L���ÝA.����-��������˲R�	�x�^�{�]k~��#q�R��402���L��V��g�}~�j螛�}w<3E�QLNN5��\nZͯ�z�[v_u�U�c0��я����ټ�L04az\Z�\0��bQ@��vϊPU�666zW6����\"�0�*���\nZ�n�����η��W}�;�ٷ�}�[��e=<�����\0�4A�\Z|�3�}�e�GoI��H&����C,G�\\���,0�����j���k�u\rЯ;�cJ�k̛ռ�0�X�+�ሁ��@�[޳�ggg�^,�H$�E����h�j�o��ˆ	r�=��?{s��]2{�2��i�F�hLC.G Im�>��Z1�R)�F���B��T*�T*�R�|^M�F���7W_}����\nB����Ͽj�fcs\"���:��ZO�4�\\a�LiH�	r9�VQ*�s���k����|>�MϹ�����ݎ�/�y�]w����ٹΩ�MT�Ѭ�<ӷc��m`T�|� �rY�J�4�u���d.7�jr9�{+�+M�R�N���9�Þ={�[��^.!J��K�lm��s���R���l�T)�y���p�.\n۪�\Z��\0��-��3Qm�r��������moiiAOO��<JPJXMkj�$M��B�*����B�\"_�(���)�n\0`TU���NI�P�TP�T6�|��0���ƿ�m����\0`@���\Zؖ1��MvW�2��\Z�\")����\\S	�-�!���i@�BP*PT*��A�H\'\00���,h�H��E�����lyTb|���wv�o�~���F�\"�Q\r���$�}��FV�/`׸Sǵ��b�A�L I������4U4:�ey��x��1r5<obȖm��S�V���ڵ���\Z��峰�Kz�S�\0��\0O\r��V�nʤ\ZP�0(���T\0p�Rn	�ʖ9M�������l�Ja)���>��cT�^J�J)�L&�#�x|Q�f�~�c����N�\\.ϣT�HU�B�(!��6�	!�\Z!��iŒ@JeA��,��J�e3�q���ԓ��ȇ���zd��7�Q��UL��a�P�nM� %`\0Ma����Q�����q�҉�ҩ3���l�b�~����\n�e?���� ��Y��վ�ZM2馺J�E�x\rC��*�P�t�Z��KҥPՎ�t)�0Rs!�(ho4m��$	���JM;����C���4_Z%�O�%`XMU@���4Ü���T��M,a2�P,��|ZF߉Y��(���i�(�h*d�E�AUeP��a��8>k2	u�2�Xo���:��):8���%<G�z�d���P\r:R�(R�-� ��/\n-\r�2��ql�g�t�F|�Bt��Ou��X�-�l�9��4p�9�۔�ͱ�T�*�e\n�%�B����\r��+��qQ���U��9����ey/��G��2�V�����!C��q�\"2ԃ=y(\"L&!�������(�v�vA@�R�Tf$�\niV����]YOA\0�B`�����&��;���a\\�Kē�\'�A�TD*�n�}���V�@8���b��j� p:c,�9\0p�=��x�~����Ba�8i��ʲ���==+�\ZT�����3��	Р����%�yӿ{��=95=�ߧO\r�^Q4d2i��͢P(,�yqӀ�q8���0��p�</D��q�݇Dq�8����)*�F�i�0���9�� �z���}��]�=\0�����|��������_���J�8�~r�W#&��x�X\'�͖	��?c�������\r�ż�4B#�i\n����D\rEk+��8�5�|�/\0@�s�P�����EK��u����0E�^o�N\'\\.7���TGG�[v�\r>���mp�\\[$I���u�Ѐ����@[�����ؓ���8Sl����;N�~�~+�N���}+,\0��\r�\Z���Î���X�-73\0��m�s�[��z������ji��l�%6�\0�EEk+A����O`�i���==���}�@���nwc�~�oK����,�f3|>_}^~��tt��R�\Z����r9��.;��z!��EQg��q)|>�]\Z�B<-f��O��-�Zad�}i��3	�e)ˍ���B�x�������l[�+��r0����������Ӎ���ݮ����M^G�u������@p8j�Xb����H/�����Ѓ~[�y�.�� \\�<��р�	p�����M{ʸ%*sj׮K>��e���ՉB��h=704/�EQ\'~W�}EW7S�,\Z��������Į]�?�ͦ���Չ|>�h��D���v������^ov���o� �,�ޥ���~�}��u�$�lhdYi����E�����\n�-��6��~{z��oi��|۶���$��J��j�q��T|�����ߏ��~��������|\0ke`j``�ߖJ�m��l36^PJ133�x����8]�=��S\'���\n�#q��߹sp_r���ڶm��R��cEQ�eYj�\"����y��3\nP:\\M۷o���vtv���ޑߵ�w,Wí�e��\\r�m�Z�IUU�F���9D\"3�F��tN���1^�X\0���\'�\0�+5�pL޶w�e��$��=��5M�,�a��Ap[}\Z,�q����A���cpp;zzz�����=�&�7���߮�D^\Z\Z��FM�~�0���8���قH$�8Sx}%L�p�Sz���p,�I\0�N������������A[�pď;o�첃g���^ػw�(�?!������333��Cތ6U?�ł���@��.�8p��Mf������3�ۿ��יL��8��6��p:p�݈D\"��b����2˥�J@a8�L\ZD��� �x4��2��:	�A��Z�?r:cw��wp|c�P|n���n�y���w�����˅���b1��&7���\0kFN1Y�P��]�p5�{���b��\nŭ�T��CC�o����y�z���8�y��u�~6xx��R���%0�D���	x=��O�omn��!A����Uz`�����9D��޽n�Zm�<w��j������\ZǐW*ճc^Jt���v�������@0؀�9�s����L5M�9,�����8u����x��d�H$����H$��Cʲ�� l�/��W��G�,RXm��q:	�n�����������X[k���>�;��z�������ƁpsϡX,�V�5̪�\r���7\0��Ě�煞�����ǃ]�.�������V2\0\0 ��P$�����[s�,��r�<�����FH&��f�,��\" ��Y$ͨ;�P� ��K0�����L���[�%�����\'&��4�ˣP( ��B��G�PD�R�$I\r�C��A`�Z�p8�t:�t:�p��==}O����c6[&p�d�	��Z��F��<�~k*�tT����\r���Ƹ����y�d8Nϗ�,�{��\n�Z����>�ɞ��$.��T*�����5�J���^�FS��\r\r`Y����8�A?��P(�@���s�	�,�3���Bn_*��.�M�f��k���Y60ϲ��XVͰ�5�ژ�={���ةbM�v�rك�T�l63��f��\r)�Y����t:�n��hK��I����qYl��lqը[UU�,K~EQ\\����\ZN�w��?�EqIRͯ(�GU5�R0�\0�T9�˚L�8ϛ��!����\0��4�9�)�\0\0\0\0IEND�B`�', 'Department of Science and Technology', 'dostco.png', '13520', 'image/x-png');


#
# TABLE STRUCTURE FOR: tblAgencyx
#

DROP TABLE IF EXISTS `tblAgencyx`;

CREATE TABLE `tblAgencyx` (
  `agencyName` varchar(100) NOT NULL DEFAULT '',
  `abbreviation` varchar(10) NOT NULL DEFAULT '',
  `dtrScheme` varchar(10) NOT NULL DEFAULT '',
  `fixedFrom` time DEFAULT '00:00:00',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zipCode` varchar(4) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `facsimile` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(80) NOT NULL DEFAULT '',
  `website` varchar(80) NOT NULL DEFAULT '',
  `fixedTo` time DEFAULT '00:00:00',
  `morningFrom` time DEFAULT '00:00:00',
  `morningTo` time DEFAULT '00:00:00',
  `afternoonFrom` time DEFAULT '00:00:00',
  `afternoonTo` time DEFAULT '00:00:00',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `pagibigId` varchar(20) NOT NULL DEFAULT '',
  `gsisId` varchar(20) NOT NULL DEFAULT '',
  `gsisEmpShare` int(4) NOT NULL DEFAULT 0,
  `gsisEmprShare` int(4) NOT NULL DEFAULT 0,
  `pagibigEmpShare` int(4) NOT NULL DEFAULT 0,
  `pagibigEmprShare` int(4) NOT NULL DEFAULT 0,
  `philhealthEmpShare` int(4) DEFAULT 0,
  `philhealthEmprShare` int(11) DEFAULT 0,
  `providentEmpShare` int(4) DEFAULT 0,
  `providentEmprShare` int(4) DEFAULT 0,
  `philhealthPercentage` decimal(4,2) NOT NULL DEFAULT 0.00,
  `lbStartMonth` int(2) NOT NULL DEFAULT 0,
  `lbStartYear` int(4) NOT NULL DEFAULT 0,
  `agencyTin` varchar(25) NOT NULL DEFAULT '',
  `PhilhealthNum` varchar(20) DEFAULT NULL,
  `Vision` mediumtext DEFAULT NULL,
  `Mission` mediumtext DEFAULT NULL,
  `Mandate` mediumtext NOT NULL,
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `region` varchar(20) NOT NULL DEFAULT '',
  `AccountNum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`agencyName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAgencyx` (`agencyName`, `abbreviation`, `dtrScheme`, `fixedFrom`, `address`, `zipCode`, `telephone`, `facsimile`, `email`, `website`, `fixedTo`, `morningFrom`, `morningTo`, `afternoonFrom`, `afternoonTo`, `salarySchedule`, `pagibigId`, `gsisId`, `gsisEmpShare`, `gsisEmprShare`, `pagibigEmpShare`, `pagibigEmprShare`, `philhealthEmpShare`, `philhealthEmprShare`, `providentEmpShare`, `providentEmprShare`, `philhealthPercentage`, `lbStartMonth`, `lbStartYear`, `agencyTin`, `PhilhealthNum`, `Vision`, `Mission`, `Mandate`, `zonecode`, `region`, `AccountNum`) VALUES ('Department of Science and Technology', 'DOST', '', '00:00:00', 'General Santos Ave., Bicutan, Taguig City', '1631', '8372071-82', '8372937', '  ', 'www.dost.gov.ph', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 'Bi-Monthly', '', '', '9', '12', '100', '100', '50', '50', '2', '5', '0.00', '1', '2005', '044-000-553-203', '140039100007', 'A prosperous Filipino nation whose socio-economic well-being is assured through competent and responsible use of scientific knowledge and technological innovations.', 'To direct, lead, and coordinate scientific and technological efforts in the country and ensure that these result to the maximum economic and social benefits for the Filipino people.', '', '', 'NCR', '     ');


#
# TABLE STRUCTURE FOR: tblAppointment
#

DROP TABLE IF EXISTS `tblAppointment`;

CREATE TABLE `tblAppointment` (
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `appointmentDesc` varchar(50) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `leaveEntitled` char(1) NOT NULL DEFAULT '',
  `paymentBasis` varchar(5) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  `incPlantilla` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`appointmentCode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('T', 'Temporary', 'DOST-ICT', 'N', 'WKDY', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('a', 'Probationary', 'STII', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('P', 'Permanent', 'Permanent', 'Y', 'CLNDR', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Emrg', 'Emergency Employee', 'Emergency Employee', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Cas', 'Casual', 'Casual', 'Y', 'CLNDR', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Prt', 'Part-time', 'Part Time', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('SU', 'Substitute', 'Substitute Employee', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Phs', 'Phase Out', 'Phase Out', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('CT', 'Co-terminous', 'Co-terminous', 'Y', 'CLNDR', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Susp', 'Suspended', 'Suspended', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Lump', 'Contractual-Lumpsum', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('GIA', 'Contractual-GIA', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PA', 'Presidential Appointee', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('JO', 'Job Order', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('GOV', 'Goverment Employee', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('OJT', 'On The Job Training', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('CONT', 'Contractual', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('OA', 'Original appointment', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PRI', 'Private', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Prom', 'Promotion', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PromTran', 'PromotionTransfer', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('E', 'Elective', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Proj', 'Project Based', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Trainee', 'Trainee', '', 'N', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Reg', 'Regular', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('O', 'Others', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('SE', 'Secondment', '', 'Y', '', '1', '0');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC1', 'Conferred the rank of Scientist I', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC2', 'Conferred the rank of Scientist II', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC3', 'Conferred the rank of Scientist III', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC4', 'Conferred the rank of Scientist IV', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC5', 'Conferred the rank of Scientist V', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('CTI', 'Co-Terminous with the Incumbent', '', 'Y', '', '1', '1');
INSERT INTO `tblAppointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Int', 'Intern', '', 'Y', '', '0', '0');


#
# TABLE STRUCTURE FOR: tblAttendanceCode
#

DROP TABLE IF EXISTS `tblAttendanceCode`;

CREATE TABLE `tblAttendanceCode` (
  `code` varchar(5) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('PL', 'Privilege Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('VL', 'Vacation Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('SL', 'Sick Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('PTL', 'Paternity Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('ML', 'Maternity Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('FL', 'Force Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('STL', 'Study Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('HFL', 'Half-day Force Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('HPL', 'Half-day Privilege Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('HVL', 'Half-day Vacation Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('HSL', 'Half-day Sick Leave');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('OB', 'Official Business');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('QB', 'Quasi Official Business');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('OT', 'Overtime');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('TO', 'Travel Order');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('TT', 'Trip Ticket');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('MET', 'Meeting');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('FC', 'Flag Ceremony');
INSERT INTO `tblAttendanceCode` (`code`, `name`) VALUES ('OFF', 'Offset');


#
# TABLE STRUCTURE FOR: tblAttendanceScheme
#

DROP TABLE IF EXISTS `tblAttendanceScheme`;

CREATE TABLE `tblAttendanceScheme` (
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  `schemeName` varchar(255) NOT NULL DEFAULT '',
  `schemeType` varchar(20) NOT NULL DEFAULT '',
  `amTimeinFrom` time NOT NULL DEFAULT '00:00:00',
  `amTimeinTo` time NOT NULL DEFAULT '00:00:00',
  `overtimeStarts` time NOT NULL DEFAULT '00:00:00',
  `overtimeEnds` time NOT NULL DEFAULT '00:00:00',
  `gracePeriod` int(2) NOT NULL DEFAULT 0,
  `gpLeaveCredits` char(1) NOT NULL DEFAULT 'Y',
  `gpLate` char(1) NOT NULL DEFAULT 'N',
  `wrkhrLeave` int(2) NOT NULL DEFAULT 0,
  `hlfLateUnd` char(1) NOT NULL DEFAULT 'N',
  `fixMonday` char(1) NOT NULL,
  `allow30` char(1) NOT NULL,
  `strict` char(1) NOT NULL,
  `pmTimeoutFrom` time DEFAULT NULL,
  `pmTimeoutTo` time DEFAULT NULL,
  `nnTimeinTo` time DEFAULT NULL,
  `nnTimeoutFrom` time DEFAULT NULL,
  `nnTimeoutTo` time DEFAULT NULL,
  `nnTimeinFrom` time DEFAULT NULL,
  PRIMARY KEY (`schemeCode`),
  KEY `schemeName` (`schemeName`(250))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAttendanceScheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeinTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`) VALUES ('GEN', 'General', 'Sliding', '07:00:00', '09:00:00', '00:00:00', '00:00:00', '0', 'N', 'N', '0', 'N', 'Y', 'N', 'N', '04:00:00', '06:00:00', '02:00:00', '12:00:00', '12:59:00', '12:00:00');
INSERT INTO `tblAttendanceScheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeinTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`) VALUES ('FIX', 'Fixed', 'Fixed', '08:00:00', '08:00:00', '00:00:00', '00:00:00', '0', 'Y', 'Y', '0', 'Y', 'Y', 'N', 'N', '05:00:00', '05:00:00', '01:00:00', '12:00:00', '12:59:00', '01:00:00');
INSERT INTO `tblAttendanceScheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeinTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`) VALUES ('test', 'test', 'Sliding', '07:00:00', '12:00:00', '00:00:00', '00:00:00', '0', 'Y', 'N', '0', 'N', 'Y', 'N', 'N', '12:00:00', '04:00:00', '12:00:00', '12:00:00', '12:00:00', '12:00:00');


#
# TABLE STRUCTURE FOR: tblAttendanceScheme_Online_DTR
#

DROP TABLE IF EXISTS `tblAttendanceScheme_Online_DTR`;

CREATE TABLE `tblAttendanceScheme_Online_DTR` (
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  `schemeName` varchar(255) NOT NULL DEFAULT '',
  `schemeType` varchar(20) NOT NULL DEFAULT '',
  `amTimeinFrom` time NOT NULL DEFAULT '00:00:00',
  `amTimeinTo` time NOT NULL DEFAULT '00:00:00',
  `overtimeStarts` time NOT NULL DEFAULT '00:00:00',
  `overtimeEnds` time NOT NULL DEFAULT '00:00:00',
  `gracePeriod` int(2) NOT NULL DEFAULT 0,
  `gpLeaveCredits` char(1) NOT NULL DEFAULT 'Y',
  `gpLate` char(1) NOT NULL DEFAULT 'N',
  `wrkhrLeave` int(2) NOT NULL DEFAULT 0,
  `hlfLateUnd` char(1) NOT NULL DEFAULT 'N',
  `fixMonday` char(1) NOT NULL,
  `allow30` char(1) NOT NULL,
  `strict` char(1) NOT NULL,
  `pmTimeoutFrom_old_data` varchar(11) DEFAULT NULL,
  `pmTimeoutTo_old_data` varchar(11) DEFAULT NULL,
  `nnTimeinTo_old_data` varchar(11) DEFAULT NULL,
  `nnTimeoutFrom_old_data` varchar(11) DEFAULT NULL,
  `nnTimeoutTo_old_data` varchar(11) DEFAULT NULL,
  `nnTimeinFrom_old_data` varchar(11) DEFAULT NULL,
  `pmTimeoutFrom` time DEFAULT NULL,
  `pmTimeoutTo` time DEFAULT NULL,
  `nnTimeinTo` time DEFAULT NULL,
  `nnTimeoutFrom` time DEFAULT NULL,
  `nnTimeoutTo` time DEFAULT NULL,
  `nnTimeinFrom` time DEFAULT NULL,
  PRIMARY KEY (`schemeCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblAttendanceScheme_Online_DTR` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`, `pmTimeoutFrom_old_data`, `pmTimeoutTo_old_data`, `nnTimeinTo_old_data`, `nnTimeoutFrom_old_data`, `nnTimeoutTo_old_data`, `nnTimeinFrom_old_data`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeinTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`) VALUES ('FIX', 'Fixed', 'Fixed', '08:00:00', '08:00:00', '00:00:00', '00:00:00', '0', 'Y', 'Y', '0', 'Y', 'Y', 'N', 'N', '05:00:00', '05:00:00', '01:00:00', '12:00:00', '12:59:00', '01:00:00', '17:00:00', '17:00:00', '13:00:00', '12:00:00', '12:59:00', '13:00:00');
INSERT INTO `tblAttendanceScheme_Online_DTR` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`, `pmTimeoutFrom_old_data`, `pmTimeoutTo_old_data`, `nnTimeinTo_old_data`, `nnTimeoutFrom_old_data`, `nnTimeoutTo_old_data`, `nnTimeinFrom_old_data`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeinTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`) VALUES ('GEN', 'General', 'Sliding', '07:00:00', '09:00:00', '00:00:00', '00:00:00', '0', 'N', 'N', '0', 'N', 'Y', 'N', 'N', '04:00:00', '06:00:00', '02:00:00', '12:00:00', '12:59:00', '12:00:00', '16:00:00', '18:00:00', '14:00:00', '12:00:00', '12:59:00', '12:00:00');
INSERT INTO `tblAttendanceScheme_Online_DTR` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`, `pmTimeoutFrom_old_data`, `pmTimeoutTo_old_data`, `nnTimeinTo_old_data`, `nnTimeoutFrom_old_data`, `nnTimeoutTo_old_data`, `nnTimeinFrom_old_data`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeinTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`) VALUES ('test', 'test', 'Sliding', '07:00:00', '12:00:00', '00:00:00', '00:00:00', '0', 'Y', 'N', '0', 'N', 'Y', 'N', 'N', '12:00:00', '04:00:00', '12:00:00', '12:00:00', '12:00:00', '12:00:00', '12:00:00', '16:00:00', '12:00:00', '12:00:00', '12:00:00', '12:00:00');


#
# TABLE STRUCTURE FOR: tblBackUpScheduler
#

DROP TABLE IF EXISTS `tblBackUpScheduler`;

CREATE TABLE `tblBackUpScheduler` (
  `id` int(10) NOT NULL DEFAULT 0,
  `scriptpath` varchar(100) NOT NULL DEFAULT '',
  `time_interval` int(10) DEFAULT NULL,
  `fire_time` int(10) NOT NULL DEFAULT 0,
  `time_last_fired` int(10) DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblBackup
#

DROP TABLE IF EXISTS `tblBackup`;

CREATE TABLE `tblBackup` (
  `id` int(11) NOT NULL DEFAULT 0,
  `db_backup_name` varchar(100) NOT NULL DEFAULT '',
  `time_last_run` int(11) NOT NULL DEFAULT 0,
  `next_run_time` int(11) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT '',
  `xversion` varchar(6) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblBackupConfig
#

DROP TABLE IF EXISTS `tblBackupConfig`;

CREATE TABLE `tblBackupConfig` (
  `id` int(10) NOT NULL DEFAULT 0,
  `time_interval` int(10) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT 0,
  `time_last_fired` int(11) NOT NULL DEFAULT 0,
  `email` varchar(50) NOT NULL DEFAULT '',
  `ftpadd` varchar(50) NOT NULL DEFAULT '',
  `ftpuname` varchar(20) NOT NULL DEFAULT '',
  `ftppass` varchar(20) NOT NULL DEFAULT '',
  `xtable` mediumtext NOT NULL,
  `xstatus` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblBrokenSched
#

DROP TABLE IF EXISTS `tblBrokenSched`;

CREATE TABLE `tblBrokenSched` (
  `rec_ID` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  `dateFrom` date NOT NULL DEFAULT '0000-00-00',
  `dateTo` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`rec_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblChangeLog
#

DROP TABLE IF EXISTS `tblChangeLog`;

CREATE TABLE `tblChangeLog` (
  `changeLogId` int(10) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `module` varchar(20) NOT NULL DEFAULT '',
  `tablename` varchar(30) NOT NULL DEFAULT '',
  `databaseevent` varchar(15) NOT NULL DEFAULT '',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` longtext NOT NULL,
  `data` longtext NOT NULL,
  `data2` longtext NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`changeLogId`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('1', '1111', 'HR Module', 'tblplantilla', '', '2024-09-09 00:17:20', 'Added PAE-MO-007 Plantilla', 'PAE-MO-007;ADA01;7;007;R;;;;;', '', '172.71.218.130');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('2', '1111', 'HR Module', 'tblplantilla', '', '2024-09-09 00:17:37', 'Edited PAE-HR-0061 Plantilla', 'PAE-HR-0061;AO02;11;060;R;CSP;01-GA;;;', '', '172.69.33.37');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('3', '1111', 'HR Module', 'tblplantilla', '', '2024-09-09 00:18:25', 'Edited PAE-MO-007 Plantilla', 'PAE-MO-007;ADA01;7;007;R;CSCProf;01-GA;;;', '', '172.71.218.131');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('4', '1111', 'HR Module', 'tblEmpPersonal', '', '2024-09-09 00:20:55', 'Edited DELA ROSA Personal', 'MR.;DELA ROSA;FRANK ALBERT;NAVARRO;;;Filipino;1988-06-14;PAETE, LAGUNA;M;Single;;;90;5.7;301836126;;A+;;;;;;;;;;;;;;;;0;0;;;09065554690;', '', '172.71.218.131');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('5', '0100-070117', 'HR Module', 'tblagency', '', '2024-09-22 03:00:50', 'Edited Municipal Government of Paete Agency_profile', 'Municipal Government of Paete;LGU-PAETE;Calabarzon;000631660000;JV Quesada St. Municipal Building Paete, Laguna;4016;(049) 501-6475;0;info@paete.gov.ph;www.paete.gov.ph;Bi-Monthly;00:00:00;00:00:00;0;0;00:08:00;0;1000021657;9;12;2-0496976000-2;100;100;2;5;50;50;0.00;142230100010;The Municipal Government of PAETE aims to preserve its arts, heritage, culture and good social values, nurture and enhance its human and natural resources in order to sustain socio-economic development by providing efficient and effective programs, project policies that will protect and manage its ecological and human resources and promote its ecological and human resources and promote its distinctive art products worldwide.;PAETE, LAGUNA: “The Carving Capital of the Philippines”, endowed with rich natural resources, renowned for world –class artist, with God-centered, warm and industrious people living in a dynamic and peaceful society under consultative, participative, responsive and ethical leadership geared towards people empowerment through transparent and good governance.;The Department is the primary agency responsible for the conservation, management, development, and proper use of the country’s environment and natural resources, specifically forest and grazing lands, mineral resources, including those in reservation and watershed areas, and lands of the public domain, as well as the licensing and regulation of all natural resources as may be provided for by law in order to ensure equitable sharing of the benefits derived therefrom for the welfare of the present and future generations of Filipinos.;LBP 3302 1038 51', '', '162.158.90.176');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('6', '0100-070117', 'HR Module', 'tblProject', '', '2024-09-22 03:02:47', 'Added EXECUTIVE PERSONAL SERVICES Project_code', 'LCEO-PS;EXECUTIVE PERSONAL SERVICES;1', '', '172.71.210.212');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('7', '0100-070117', 'HR Module', 'tblEmpPersonal', '', '2024-10-05 05:14:48', 'Added PE-BCC032392 Personal Information', 'PE-BCC032392;;CAINTO;BEATRIZ;;;;Filipino;1967-03-08;;Female;Married;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.68');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('8', '0100-070117', 'HR Module', 'tblgroup2', '', '2024-10-05 05:16:32', 'Added HRMO Org_structure', 'LCEO;HRMO;Human Resource Management Office;PE-BCC032392;HRMO III;PE-MGR020106', '', '172.68.225.223');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('9', '1111', 'HR Module', 'tblempaccount', '', '2024-10-30 11:45:29', 'Edited maritess.reyes User_account', 'PE-MGR020106;maritess.reyes;2;0;;finance;01234', '', '172.71.87.196');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('10', '1111', 'HR Module', 'tblempaccount', '', '2024-10-30 11:46:49', 'Edited maritess.reyes User_account', 'PE-MGR020106;maritess.reyes;2;0;;finance;01234;90ca772b7343dc2c37e76f217cc7608a', '', '172.71.87.196');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('11', '0100-070117', 'HR Module', 'tblempaccount', '', '2024-10-31 09:15:42', 'Edited maritess.reyes User_account', 'PE-MGR020106;maritess.reyes;1;0;;hr;123456;90ca772b7343dc2c37e76f217cc7608a', '', '172.70.214.33');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('12', '0100-070117', 'HR Module', 'tblempaccount', '', '2024-10-31 09:21:15', 'Edited ronald.cosico User_account', 'EO-RQB0000;ronald.cosico;4;0;;executive;;90ca772b7343dc2c37e76f217cc7608a', '', '172.68.225.222');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('13', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:35:57', 'Added PE-BSA020123 Personal Information', 'PE-BSA020123;;ACHOY;BRYAN;;S;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.207.150');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('14', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:36:19', 'Added PE-PBA020197 Personal Information', 'PE-PBA020197;;ADEA; PEMABELLE ;B.;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.207.150');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('15', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:36:44', 'Added PE-ALA031616 Personal Information', 'PE-ALA031616;; ADEFUIN;ARMIE ;;L.;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.207.149');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('16', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:38:00', 'Added PE-CGA090123 Personal Information', 'PE-CGA090123;;AFRICANO;CHRIS JOY ;;G;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '162.158.90.124');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('17', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:40:16', 'Added PE-CEA010319 Personal Information', 'PE-CEA010319;;AFUANG	 ;CARLA ;;E;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.69.33.126');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('18', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:40:45', 'Added PE-MGA030199 Personal Information', 'PE-MGA030199;;AFUNGGOL	 ;MOISES ;;G;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.69.33.126');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('19', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:41:02', 'Added PE-LVA010108 Personal Information', 'PE-LVA010108;;AFURONG	; LEONARD ;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.69.33.126');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('20', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:41:32', 'Added PE-EEA060123 Personal Information', 'PE-EEA060123;;ALPON	 ;EDITHA;;E;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.69.33.127');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('21', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:41:55', 'Added PE-MYA070122 Personal Information', 'PE-MYA070122;;ASEOCHE	;MAR YASUKAZU; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.69.33.126');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('22', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:42:13', 'Added PE-JCA030107 Personal Information', 'PE-JCA030107;;ASIDO	; JERRY ;;C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.69.33.126');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('23', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:42:53', 'Added PE-OMB 010106 Personal Information', 'PE-OMB 010106;;BABAEL	 ;OFELIA ;;M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.210.230');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('24', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:43:18', 'Added PE-MBB031692 Personal Information', 'PE-MBB031692;;BAGABALDO	 ;MARITA ;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.210.230');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('25', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:43:36', 'Added PE-LLB050105 Personal Information', 'PE-LLB050105;;  BAGCUS	; LOREN;;L;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.210.231');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('26', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:43:54', 'Added PE-ADB070122 Personal Information', 'PE-ADB070122;;BALDEMOR	 ;ANALIE;;D;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.210.230');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('27', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:44:21', 'Added PE-DHB010111 Personal Information', 'PE-DHB010111; ;BALDEMOR	 ;DARWIN H.;;H;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.210.230');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('28', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:45:01', 'Added PE-JLB070122 Personal Information', 'PE-JLB070122;;BALDEMOR	;JERIEL ;;L;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.86');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('29', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:45:28', 'Added PE-LMB070201 Personal Information', 'PE-LMB070201;;BALDEMOR	 ;LEONARDO ;;M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.87');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('30', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:46:08', 'Added PE-SRB120104 Personal Information', 'PE-SRB120104;;BALDEMOR	 ;SHERYLL ;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.24');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('31', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:46:40', 'Added PE-RGB011392 Personal Information', 'PE-RGB011392;;BALLARES	 ;ROSALINDA ;;G;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.222');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('32', '0100-070117', 'HR Module', 'tblproject', '', '2024-10-31 09:48:03', 'Edited EXECUTIVE PERSONAL SERVICES Project_code', 'LCEO-PS;EXECUTIVE PERSONAL SERVICES;1', '', '172.71.211.24');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('33', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:55:27', 'Added PE-JRB020299 Personal Information', 'PE-JRB020299;;BARRETTO	 ;JOEL R.;R;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.212');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('34', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:55:55', 'Added PE-SDB030123 Personal Information', 'PE-SDB030123;;BAUTISTA;SHAWN MICHAEL LEE D.;;D;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.213');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('35', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:56:18', 'Added PE-BBB020193 Personal Information', 'PE-BBB020193;;BUNYE	 ;BRIGIDA B.;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.213');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('36', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:56:36', 'Added PE-JMC070122 Personal Information', 'PE-JMC070122;;CADAWAS	 ;JOHN LAURENCE ;;M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.212');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('37', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:56:59', 'Added PE-SLC080192 Personal Information', 'PE-SLC080192;;CADAY	;SHEILA L.;;L;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.213');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('38', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:57:49', 'Added PE-TRC010108 Personal Information', 'PE-TRC010108;;CADAYONA	 ;TERENCE ;;R;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '162.158.179.146');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('39', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:58:23', 'Added PE-ANC020124 Personal Information', 'PE-ANC020124;;CAGAHASTIAN	 ;ADRIAN ;;N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.32');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('40', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 09:59:20', 'Added PE-CMC050105 Personal Information', 'PE-CMC050105;;CAINTO	 ;CHRISTINE ;;M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.210.33');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('41', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:00:37', 'Added PE-CDC060324 Personal Information', 'PE-CDC060324;;CAJIPE	 ;CHARLYN ;;D;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.207.82');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('42', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:01:34', 'Added PE-MGAD010108 Personal Information', 'PE-MGAD010108;;DANTOC	 ;MARY GRACE;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('43', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:01:57', 'Added PE-GED070120 Personal Information', 'PE-GED070120;;DELA CRUZ	 ;GINO ;;E;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('44', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:02:21', 'Added CE-MSD050218 Personal Information', 'CE-MSD050218;;DELOS SANTOS	 ;MARGIE ;;SJ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('45', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:02:42', 'Added  PE-RVD070121 Personal Information', ' PE-RVD070121;;DE LUNA ;ROLANDO JR;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('46', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:03:05', 'Added PE-RGD030107 Personal Information', 'PE-RGD030107;;DIMATATAC	 ;RAMON ;;G;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('47', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:03:24', 'Added PE-RRD021696 Personal Information', 'PE-RRD021696;;DONO	 ;ROBERTO ;;R;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('48', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:03:43', 'Added PE-ACE050105 Personal Information', 'PE-ACE050105;;ENLAYO	 ;ANGELITO ;;C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('49', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:04:00', 'Added PE-MPE010285 Personal Information', 'PE-MPE010285;;ESPAÑOLA	 ;MENCHIE ;;P;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('50', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:04:21', 'Added PE-NSF010108 Personal Information', 'PE-NSF010108;;FERRER	 ;NANIT;;S;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('51', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:04:42', 'Added PE-DMF081318 Personal Information', 'PE-DMF081318;;GAJITOS	 ;DEAN EMERSON;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('52', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:05:01', 'Added PE-FBG011703 Personal Information', 'PE-FBG011703;;GAJITOS	 ;FERNANDO;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('53', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:05:22', 'Added PE-NBG010890 Personal Information', 'PE-NBG010890;;GAJITOS	 ;NENITA ;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('54', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:05:48', 'Added PE-LBG010106 Personal Information', 'PE-LBG010106;;GARCIA	;LEOPOLDO JR;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('55', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:06:09', 'Added PE-NAG010106 Personal Information', 'PE-NAG010106;;GRIMPULA	;NENITA;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('56', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:06:29', 'Added PE-EVG010323 Personal Information', 'PE-EVG010323;;GONZALES	 ;ELLAINE JOY;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('57', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:06:56', 'Added PE-RBG070120 Personal Information', 'PE-RBG070120;;GONZALES	;RICHARD;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.78');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('58', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:07:14', 'Added PE-ACG020123 Personal Information', 'PE-ACG020123;;GORDULA	 ;AILA DOMINIQUE ;; C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.206.79');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('59', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:09:00', 'Added PE-VNJ091018 Personal Information', 'PE-VNJ091018;; JUAREZ	 ;VLADIMIR ;;N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.189');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('60', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:09:14', 'Added PE-RBL010198 Personal Information', 'PE-RBL010198;;LISAY	 ;ROMEO ;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.188');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('61', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:09:40', 'Added PE-CCM080123 Personal Information', 'PE-CCM080123;;MADRIGAL	 ;CORAZON ;;C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.189');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('62', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:10:00', 'Added PE-JPM30107 Personal Information', 'PE-JPM30107;;MADRIGAL	;JOSEPH ;;P;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.188');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('63', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:10:26', 'Added PE-RCM120195 Personal Information', 'PE-RCM120195;;MEDINA	 ;RAMON ;;C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.189');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('64', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:10:47', 'Added PE-PEM090121 Personal Information', 'PE-PEM090121;;MONTES	 ;PHILIP ;;E;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.189');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('65', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:11:06', 'Added PE-RCN070115 Personal Information', 'PE-RCN070115;;NAVAL	 ;ROSIE;;C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.188');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('66', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:11:26', 'Added PE-AVN10305 Personal Information', 'PE-AVN10305;;NOCEJA	;ALBERT ;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.188');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('67', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:11:43', 'Added PE RVN 010206 Personal Information', 'PE RVN 010206;;NOMBRADO	;RODELINE ;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.188');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('68', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:12:05', 'Added PE-EBP070122 Personal Information', 'PE-EBP070122;;PAGALANAN	 ;EDMOND;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.189');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('69', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:12:24', 'Added PE-LBP020106 Personal Information', 'PE-LBP020106;;PANGILINAN	 ;LERMA ;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.71.214.188');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('70', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:12:58', 'Added PE-RRP022194 Personal Information', 'PE-RRP022194;;PILLAS	 ;RHODORA;;R;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.125');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('71', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:13:16', 'Added PE-DTR012903 Personal Information', 'PE-DTR012903;;RAFOL	 ;DINAH;;T;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.125');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('72', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:13:37', 'Added PE-LAR010220 Personal Information', 'PE-LAR010220;;RAMIREZ	 ;LANIE ;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.125');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('73', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:13:52', 'Added PE-AAA060109 Personal Information', 'PE-AAA060109;;RAMOS	 ;ANA VICTORIA;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.125');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('74', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:14:44', 'Added PE-JCR030124 Personal Information', 'PE-JCR030124;;RAMOS	 ;JOYZELLE;;C;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.124');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('75', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:15:09', 'Added PE-RDR080204 Personal Information', 'PE-RDR080204;;REYES	;RODHELYN;D;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.124');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('76', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:15:29', 'Added PE-EDR030314 Personal Information', 'PE-EDR030314;;ROCAMORA	 ;EXEQUIEL ;;D;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.125');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('77', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:15:51', 'Added PE-MAR030211 Personal Information', 'PE-MAR030211;;RUANTO	 ;MARILITO ;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.125');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('78', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:16:17', 'Added PE-MMS081897 Personal Information', 'PE-MMS081897;;SANCHEZ	 ;MA. VIVIAN;;M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.70.214.124');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('79', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:17:25', 'Added PE-ABS090122 Personal Information', 'PE-ABS090122;;SATINGIN	;ANTHONY;;B;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.161');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('80', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:17:44', 'Added PE-EMS030121 Personal Information', 'PE-EMS030121;;SORIANO	 ;EDUARDO;;M;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.160');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('81', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:18:00', 'Added PE-GVT031616 Personal Information', 'PE-GVT031616;;TRENCIO	 ;GARY;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.160');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('82', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:18:18', 'Added PE-MET030215 Personal Information', 'PE-MET030215;;TRENCIO	 ;MARIA ELENA ;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.160');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('83', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:18:34', 'Added PE-RAT020197 Personal Information', 'PE-RAT020197;;TRENCIO	 ;ROSALINDA ;;A;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.161');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('84', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:18:53', 'Added PE-MNU030520 Personal Information', 'PE-MNU030520;; UMALI	 ;MA. KATHRINA ;N;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.161');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('85', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:19:14', 'Added PE-JSV-020193 Personal Information', 'PE-JSV-020193;;VALDECANTOS	 ;JOBETH ;;S;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.160');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('86', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:19:31', 'Added PE-JIV020197 Personal Information', 'PE-JIV020197;;VALDELLON	; JOVITA;;I;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.161');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('87', 'PE-MGR020106', 'HR Module', 'tblEmpPersonal', '', '2024-10-31 10:19:49', 'Added PE-DVV031523 Personal Information', 'PE-DVV031523;;VALDELLON	 ;DEANNE MARIE;;V;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '172.68.225.161');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('88', '0100-070117', 'HR Module', 'tblproject', '', '2024-11-05 00:04:12', 'Edited EXECUTIVE PERSONAL SERVICES Project_code', 'LGU-PAETE;EXECUTIVE PERSONAL SERVICES;1', '', '172.69.134.215');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('89', '0100-070117', 'HR Module', 'tblgroup1', '', '2024-11-05 01:28:26', 'Edited LCEO Org_structure', 'LCEO;Municipal Government of Paete;EO-RQB0000;Municipal Mayor;', '', '172.71.211.37');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('90', '0100-070117', 'HR Module', 'tblgroup1', '', '2024-11-05 01:30:51', 'Edited LCEO Org_structure', 'LCEO;Office of the Municipal Mayor;EO-RQB0000;Municipal Mayor;', '', '172.71.219.32');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('91', '0100-070117', 'HR Module', 'tblplantilla', '', '2024-11-05 02:07:44', 'Edited PAE-MO-007 Plantilla', 'PAE-MO-007;ADA01;7;007;R;CSCProf;01-GA;;;', '', '172.68.225.215');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('92', '0100-070117', 'HR Module', 'tblproject', '', '2024-11-05 02:13:14', 'Edited EXECUTIVE PERSONAL SERVICES Project_code', 'LCEO-PS;EXECUTIVE PERSONAL SERVICES;1', '', '172.71.214.25');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('93', '0100-070117', 'HR Module', 'tblproject', '', '2024-11-05 02:13:22', 'Edited EXECUTIVE PERSONAL SERVICES Project_code', 'LCEO-PS1;EXECUTIVE PERSONAL SERVICES;1', '', '172.71.214.25');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('94', '0100-070117', 'HR Module', 'tblpayrollgroup', '', '2024-11-05 02:14:25', 'Added PR-Permanent Payroll_Group', '1;PR-Permanent;Permanent;1;10000', '', '162.158.114.249');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('95', '0100-070117', 'HR Module', 'tblsalarysched', '', '2024-11-05 02:27:23', 'Edited 1 Salary Schedule', '9981.00', '', '162.158.179.88');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('96', '0100-070117', 'HR Module', 'tblsalarysched', '', '2024-11-05 02:27:40', 'Edited 1 Salary Schedule', '9982.00', '', '162.158.179.87');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('97', '0100-070117', 'HR Module', 'tblgroup1', '', '2024-11-05 02:42:58', 'Edited LCEO Org_structure', 'LCEO;Municipal Government of Paete;EO-RQB0000;Municipal Mayor;', '', '172.71.214.111');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('98', '0100-070117', 'HR Module', 'tblgroup1', '', '2024-11-05 02:44:05', 'Added LGU-HRMO Org_structure', 'LGU-HRMO;Human Resources & Management Office;PE-BCC032392;HRMO III;', '', '172.71.215.33');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('99', 'PE-FND070117', 'HR Module', 'tblplantilla', '', '2024-11-05 04:45:03', 'Edited PAE-HR-0061 Plantilla', 'PAE-HR-0061;AO02;11;060;R;CSP;01-GA;;;', '', '172.69.33.39');
INSERT INTO `tblChangeLog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('100', 'PE-FND070117', 'HR Module', 'tblplantilla', '', '2024-11-05 04:46:54', 'Edited PAE-HR-0061 Plantilla', 'PAE-HR-0061;AO02;11;060;R;CSP;01-GA;;;', '', '172.71.215.143');


#
# TABLE STRUCTURE FOR: tblComputation
#

DROP TABLE IF EXISTS `tblComputation`;

CREATE TABLE `tblComputation` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `fk_id` int(5) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `code` varchar(20) NOT NULL DEFAULT '0',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblComputationDetails
#

DROP TABLE IF EXISTS `tblComputationDetails`;

CREATE TABLE `tblComputationDetails` (
  `fk_id` int(5) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `workingDays` int(2) NOT NULL DEFAULT 0,
  `nodaysPresent` int(2) NOT NULL DEFAULT 0,
  `nodaysAbsent` int(2) NOT NULL DEFAULT 0,
  `hazardCode` varchar(20) NOT NULL DEFAULT '',
  `hazard` decimal(10,2) NOT NULL DEFAULT 0.00,
  `laundryCode` varchar(20) NOT NULL DEFAULT '',
  `laundry` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subsisCode` varchar(20) NOT NULL DEFAULT '',
  `subsistence` decimal(10,2) NOT NULL DEFAULT 0.00,
  `salaryCode` varchar(20) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `longi` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ta` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hpFactor` int(2) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL DEFAULT 0,
  `rataAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rataVehicle` char(1) NOT NULL DEFAULT '',
  `rataCode` varchar(10) NOT NULL DEFAULT '',
  `daysWithVehicle` int(2) NOT NULL DEFAULT 0,
  `raPercent` int(2) NOT NULL DEFAULT 0,
  `taPercent` int(2) NOT NULL DEFAULT 0,
  `latest` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblComputationDetails_03012017
#

DROP TABLE IF EXISTS `tblComputationDetails_03012017`;

CREATE TABLE `tblComputationDetails_03012017` (
  `fk_id` int(5) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `workingDays` int(2) NOT NULL DEFAULT 0,
  `nodaysPresent` int(2) NOT NULL DEFAULT 0,
  `nodaysAbsent` int(2) NOT NULL DEFAULT 0,
  `hazardCode` varchar(20) NOT NULL DEFAULT '',
  `hazard` decimal(10,2) NOT NULL DEFAULT 0.00,
  `laundryCode` varchar(20) NOT NULL DEFAULT '',
  `laundry` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subsisCode` varchar(20) NOT NULL DEFAULT '',
  `subsistence` decimal(10,2) NOT NULL DEFAULT 0.00,
  `salaryCode` varchar(20) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `longi` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ta` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hpFactor` int(2) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL DEFAULT 0,
  `rataAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rataVehicle` char(1) NOT NULL DEFAULT '',
  `rataCode` varchar(10) NOT NULL DEFAULT '',
  `daysWithVehicle` int(2) NOT NULL DEFAULT 0,
  `raPercent` int(2) NOT NULL DEFAULT 0,
  `taPercent` int(2) NOT NULL DEFAULT 0,
  `latest` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblComputationInstance
#

DROP TABLE IF EXISTS `tblComputationInstance`;

CREATE TABLE `tblComputationInstance` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `month` int(2) NOT NULL DEFAULT 0,
  `year` int(4) NOT NULL DEFAULT 0,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `pmonth` int(2) NOT NULL DEFAULT 0,
  `pyear` int(4) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0,
  `totalNumDays` int(11) NOT NULL DEFAULT 0,
  `processed` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblContact
#

DROP TABLE IF EXISTS `tblContact`;

CREATE TABLE `tblContact` (
  `agencyCode` varchar(10) NOT NULL DEFAULT '',
  `agency` varchar(255) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` char(1) NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(5) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `address` text NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`agencyCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblCountry
#

DROP TABLE IF EXISTS `tblCountry`;

CREATE TABLE `tblCountry` (
  `countryId` int(11) NOT NULL AUTO_INCREMENT,
  `countryName` varchar(100) NOT NULL,
  `countryCode` varchar(80) NOT NULL,
  PRIMARY KEY (`countryId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblCountry` (`countryId`, `countryName`, `countryCode`) VALUES ('1', 'Philippines', 'PH');


#
# TABLE STRUCTURE FOR: tblCourse
#

DROP TABLE IF EXISTS `tblCourse`;

CREATE TABLE `tblCourse` (
  `courseId` int(11) NOT NULL AUTO_INCREMENT,
  `courseCode` varchar(10) NOT NULL DEFAULT '',
  `courseDesc` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`courseId`)
) ENGINE=MyISAM AUTO_INCREMENT=262 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('1', 'BS ChE', 'BS Chemical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('2', 'MS ChE', 'Master of Science in Chemical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('3', 'PhD ChE', 'Doctor of Philosophy in Chemical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('4', 'MIM', 'Master in Information Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('5', 'BLAW', 'Bachelor of Laws');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('6', 'MLAW', 'Master of Laws');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('7', 'BBUSAD', 'BS Business Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('8', 'PRIM', 'Elementary');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('9', 'SEC', 'Secretarial');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('10', 'BS BIOCHEM', 'BS Bio-chemistry');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('11', 'MSH', 'Master of Science in Horticulture');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('12', 'PhD BM', 'Doctor of Business Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('13', 'AB Eco.', 'Liberal of Arts Major in Economics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('14', 'MA Eco.', 'Master of Arts in Ecomics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('15', 'MNSA', 'Master of National Security Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('16', 'MBM', 'Master in  Business Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('17', 'BS Geo', 'BS Geology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('18', 'MS Geo', 'Master of Science in Geology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('19', 'PhD Geo', ' Doctor of Geometry');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('20', 'PhDG', 'Doctor of Science in Geology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('21', 'BS IT', 'BS Information Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('22', 'BS ComSci', 'BS Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('23', 'BBM', 'Bachelor of Business Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('24', 'MPA', 'Master in Public Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('25', 'MBA', 'Master in  Business Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('26', 'ComP', 'Computer Programming');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('27', 'BS Bio', 'BS Biology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('28', 'MS Bio', 'Master of Science in Biology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('29', 'BSS', 'BS Statistics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('30', 'BSC', 'BS Commerce');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('31', 'BS Eco', 'BS Economics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('32', 'BS CE', 'BS Civil Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('33', 'BS DC', 'BS Development Communication');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('34', 'Comm', 'Commerce');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('35', 'BBA', 'Bachelor of Business Administration major in Acctg');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('36', 'BOA', 'Bachelor in Office Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('37', 'BSC Acc', 'BSC Accounting');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('38', 'BS CBM', 'BS Commerce - Business Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('39', 'BSCoE', 'BS Computer Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('40', 'MCS', 'Master in Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('41', 'PhD Tech', 'Doctor of Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('42', 'BSFN', 'BS Food and Nutrition');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('43', 'MBE', 'Master in Business Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('44', 'BSEED', 'BS Elementary Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('45', '', '');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('46', 'Pub Admin', 'Public Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('47', 'BS Agr', 'BS Agriculture');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('48', 'Edu', 'Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('49', 'MPS', 'M.A. Political Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('50', 'ABE', 'AB Economics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('51', 'BSie', 'BS Industrial Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('52', 'CSPE', 'Civil Service Prof. Exam');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('53', 'MSM', 'Master of Science in Marketing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('54', 'ME', 'Masters in Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('55', 'MCE', 'Major in Chemical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('56', 'IS', 'International Studies');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('57', 'LA', 'Liberal Arts');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('58', 'BTTEMFSM', 'Bachelor of Technical Teacher Educ. Major in FSM');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('59', 'MMPA', 'Master in management(Public Administration)');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('60', 'BBAMA', 'BS Business Administration Major in Accounting');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('61', 'CST', 'Computer Science Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('62', 'GradCertBI', 'Graduate Cert. Course in Business Intelligence');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('63', 'GradCertKM', 'Graduate Cert. Course in Knowledge Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('64', 'DipSIM', 'Diploma Course in Strategic Information Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('65', 'MEC', 'Master of Engineering Major in Chem. Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('66', 'MProfS', 'Master of Professional Studies');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('67', 'MIS', 'Master in Information Systems');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('68', 'CETech', 'Computer Engineering Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('69', 'BEng', 'Bachelor of Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('70', 'BSEnviSci', 'BS Environmental Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('71', 'MC', 'Masters in Community');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('72', 'ABComArts', 'AB Communication Arts Major in Advertising & PR');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('73', 'MA GovM', 'Master in Government Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('74', 'BSNutD', 'BS Nutrition and Dietetics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('75', 'MSSci', 'MS Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('76', 'BSCAd', 'BSC Advertising');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('77', 'MPS Food', 'MPS in Food and Nutrition Planning');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('78', 'BSBA AC', 'BS Business Administration - Accounting');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('79', 'BS ME', 'BS Mechanical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('80', 'Math', 'BS Math');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('81', 'AB Hum', 'AB Humanities w/ Prof. Cert. in Pol. Econ.');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('82', 'PG DipMan', 'Post Graduate Diploma in Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('83', 'BAc', 'BS Accountancy');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('84', 'MABA', 'Master of Arts in Business Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('85', 'PhD Co', 'PhD Commerce');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('86', 'IndusElec', 'Industrial Electricity');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('87', 'MPM', 'Master in Public Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('88', 'MSBio', 'MS Biology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('89', 'MTechMan', 'Masters in Technology Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('90', 'ComCourse', 'Computer Courses from Basic to Programming');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('91', 'BS AeEng', 'BS Aerospace Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('92', 'PSTUD', 'AB Phil Studies');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('93', 'STENO', 'STENO-TYPING COURSE');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('94', 'BSC-M', 'BS Commerce Major in Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('95', 'GRCC', 'Government Radio Communications Certificate');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('96', 'MGA-PA', 'Master in Govt Admin Major in Public Admin');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('97', 'DPA', 'Doctor of Public Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('98', 'BSElec', 'BS Electrical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('99', 'MSElec', 'Master of Science in Electrical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('100', 'MPM-TED', 'Masters in Public Management Tech. Enterprise Devt');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('101', 'PhDTM', 'PH.D. in Technology Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('102', 'DPM', 'Doctor of Public Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('103', 'Vocational', 'Basic Scriptwriting Course');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('104', 'ACS', 'Associate in Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('105', '4thYRBSCS', '4th Year BS Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('106', 'BBM-MBA', 'BBM-MBA');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('107', 'SAD', 'Systems Analysis and Design');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('108', 'BProg', 'Basic Programming');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('109', 'COBOL', 'COBOL Programming');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('110', 'FlowPro', 'Flowcharting Proficiency');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('111', 'EDP', 'Basic EDP Concepts');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('112', 'MCD', 'Masters in Community Development');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('113', '2nd', 'Secondary');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('114', 'BArt', 'Bachelor of Arts');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('115', 'BSCBF', 'BSC Major in Banking and Finance');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('116', 'D.P.A.', 'Doctor in Public Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('117', 'Primary', 'Primary');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('118', 'BSFS', 'BS Foreign Service');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('119', 'MSSD', 'M.S. Social Development');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('120', 'BType', 'Basic Typing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('121', 'MAMSMAM', 'Master of Management in Agribusiness Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('122', 'BSIndTech', 'BS Industrial Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('123', 'BSBA-Mgmt', 'BSBA Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('124', 'ABPolScie', 'AB Political Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('125', 'LIACOM', 'Liberal Arts and Commerce-Mgmt. and Economics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('126', 'LI.B', 'LI.B');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('127', 'AB-G', 'AB-General');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('128', 'BSN', 'BS Nursing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('129', 'ZMZ', 'BS Zoology Major in Marine Zoology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('130', 'FA', 'MS Fisheries Major Aquaculture');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('131', 'PhFS', 'Ph.D. Fisheries Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('132', 'MSME', 'Master of Science in Mechanical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('133', 'HDIT', 'Honors Diploma in Information Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('134', 'BSEE', 'BS Electronics Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('135', 'MSMGE', 'Master of Science in Management Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('136', 'BSECE', 'BS Electronics and Communications Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('137', 'BSCH', 'BS Chemistry');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('138', 'MSCH', 'Master of Science in Chemistry');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('139', 'PhDCH', 'Doctor of Philosophy in Chemistry');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('140', 'CTech', 'Computer Technician');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('141', 'ABBA', 'Bachelor of Arts in Communication Arts');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('142', 'MAS', 'Master of Arts in Sociology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('143', 'BSFT', 'BS Food Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('144', 'BSAP', 'BS Applied Physics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('145', 'JD', 'Juris Doctor');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('146', 'LLMIELPO', 'LL.M. IELPO Course');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('147', 'GIP', 'General Intellectual Property Couse');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('148', 'BSP', 'BS Physics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('149', 'BSA', 'BS Agriculture');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('150', 'MSA', 'Master of Science in Agriculture');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('151', 'BSICS', 'BS Information and Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('152', 'BSOM', 'BS Office Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('153', 'BSPSY', 'BS Psychology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('154', 'BAOABA', 'B.S. in Office Admin. Major in Busines Admin.');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('155', 'ABDC', 'Bachelor of Arts in Development Communication');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('156', 'CG', 'Caregiver');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('157', 'BBF', 'Bachelor in Banking and Finance');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('158', 'CET', 'Computer Electronic Technician');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('159', 'MIT', 'Master in Information Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('160', 'BSCCS', 'BS Computing Major in Computer Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('161', 'COMPST', 'Computer Software Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('162', 'ABENTRE', 'Bachelor of Arts in Entrepreneurship');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('163', 'ABL', 'Bachelor of Arts in Literature');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('164', 'BSBAM', 'BS Business Management Major in Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('165', 'MMGT', 'Master in Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('166', 'CTP', 'Certificate in Teaching Program');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('167', 'CSA', 'Computer Secretarial Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('168', 'COMPSEC', 'Computer Secretarial');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('169', 'ELEC', 'Electronics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('170', 'TM', 'Television Mechanics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('171', 'JAP', 'Japanese Language');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('172', 'BSBAA', 'BS Business Administration and Accounting');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('173', 'MSIM', 'Master of Science in Information Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('174', 'BSED', 'Bachelor of Secondary Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('175', 'BSCBA', 'BS Commerce Major in Business Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('176', 'BA', 'Journalism');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('177', 'BS PT', 'BS Physical Therapy');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('178', 'OM', 'Office Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('179', 'BOIS', 'Diploma in Business Office Information System');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('180', 'BS CBF', 'BS Commerce - Banking and Finance');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('181', 'BS BCA', 'BS Brodcast Arts');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('182', 'ICT', 'Information Communication Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('183', 'ABComm', 'AB Communication');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('184', 'BS Crim', 'BS Criminology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('185', 'MSAc', 'Master of Science in Accountancy');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('186', 'BSBMGMT', 'BS Business Management Major in Marketing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('187', 'BSBAMM', 'BS Business Management Major in Marketing Mgmt');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('188', 'BSBE', 'BS Business Economics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('189', 'BSAM', 'BS Applied Math');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('190', 'ABSComm', 'Bachelor of Arts in Speech Communication');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('191', 'MASPED', 'Master of Arts in Special Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('192', 'BJourn', 'Bachelor in Journalism');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('193', 'DRSM', 'Dressmaking');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('194', 'BSBAMgmt', 'BS Business Administration Major in Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('195', 'BSF', 'BS Forestry');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('196', 'MMDM', 'Master in Management in Development Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('197', 'BSG', 'BS Geography');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('198', 'BASocSci', 'BA Social Sciences');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('199', 'BASocio', 'BA Sociology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('200', 'BSME', 'BS Mechanical Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('201', 'BAcctg', 'Bachelor in Accounting');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('202', 'BSBAMktg', 'BS Business Administration Major in Marketing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('203', 'MTM', 'Masters in Technology Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('204', 'BSMSE', 'BS Materials Science and Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('205', 'HGM', 'Housekeeping and Guestroom Maintenance');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('206', 'BAIS', 'Bachelor of Arts in International Studies');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('207', 'DHRM', 'Diploma of Science in Hotel and Restaurant Mgmt');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('208', 'MT', 'Mechanical Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('209', 'RAT', 'Refrigeration and Aircon Technician');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('210', 'BSMM', 'BS Marketing Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('211', 'JL', 'Japanese Language');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('212', 'BSHRM', 'BS Hotel and Restaurant Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('213', 'BSHRS', 'BS Hotel and Restaurant Services');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('214', 'BSBAMMgt', 'BS Business Administration Major in Marketing Mgmt');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('215', 'BC', 'Basic Computer');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('216', 'BSAdmin', 'BS Administration');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('217', 'BSEduc', 'BS Education');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('218', 'TD', 'Technical Drawing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('219', 'ECT', 'Electronics Communication Technician');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('220', 'MStat', 'Master of Statistics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('221', 'BSMedTech', 'BS Medical Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('222', 'MPH', 'Master in Public Health');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('223', 'MSNut', 'MS Nutrition');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('224', 'DAppNut', 'Diploma in Applied Nutrition');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('225', 'PhDN', 'Ph.D. Nutrition');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('226', 'AAS', 'Associate in Arts - Secretarial Course');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('227', 'BSCA', 'BS Commerce - Accounting');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('228', 'CompTech', 'Computer Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('229', 'BSM', 'BS Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('230', 'ABP', 'AB Psychology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('231', 'BS EM', 'BS Entrepreneural Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('232', 'DIT', 'Diploma in Information Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('233', 'BSAT', 'BS Accounting Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('234', 'BS IS', 'BS Information System');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('235', 'ADC', 'Advanced Diploma in Computing');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('236', 'BSAE', 'Bachelor of Science in Agricultural Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('237', 'MSCE', 'Master in Civil Engineer');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('238', 'Phd', 'Phd');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('239', 'MS', 'MS');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('240', 'PhDEnvEng', 'PhD Environmental Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('241', 'BSIEn', 'BS Industrial Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('242', 'AT', 'Automotive Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('243', 'ASNCII', 'Automotive Servicing NC II');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('244', 'MScEE', 'MSc Environmental Engineering');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('245', 'BSSC', 'BS Sociology ');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('246', 'MSMF', 'MS Marine Fisheries');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('247', 'BSAEc', 'Bachelor of Science in Agricultural Economics');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('248', 'MAP', 'MA Philosophy');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('249', 'AB PHI', 'AB Philosophy');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('250', 'CETech.', 'Civil Engineering Technology');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('251', 'BSTTM', 'Bachelor of Science Travel and Tourism Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('252', 'PM', 'Public Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('253', 'MATV', 'Master of Art in Teaching Vocational');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('254', 'BSIM', ' BS Information Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('255', 'BIM', 'Business Information Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('256', 'BSAgr', 'BS Agronomy');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('257', 'MSIFS', 'Master of Science in food Science');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('258', 'B PE Maj', 'B in P.E. Major in Sports and Wellness Mgt.');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('259', 'MaTechMgt', 'Masters in Technology Management');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('260', 'EIM', 'Electrical Installation and Maintenance NCII');
INSERT INTO `tblCourse` (`courseId`, `courseCode`, `courseDesc`) VALUES ('261', 'BSFAgro', 'Bachelor of Science in Forestry Major in Agrofores');


#
# TABLE STRUCTURE FOR: tblCustodian
#

DROP TABLE IF EXISTS `tblCustodian`;

CREATE TABLE `tblCustodian` (
  `custodianId` int(5) NOT NULL AUTO_INCREMENT,
  `officeCode` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`custodianId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblDailyQuote
#

DROP TABLE IF EXISTS `tblDailyQuote`;

CREATE TABLE `tblDailyQuote` (
  `day` int(2) NOT NULL DEFAULT 0,
  `quote` text NOT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblDeduction
#

DROP TABLE IF EXISTS `tblDeduction`;

CREATE TABLE `tblDeduction` (
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductionDesc` varchar(50) NOT NULL DEFAULT '',
  `deductionType` varchar(20) NOT NULL DEFAULT '',
  `deductionGroupCode` varchar(20) DEFAULT NULL,
  `deductionAccountCode` varchar(50) NOT NULL DEFAULT '0',
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`deductionCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GSALLOAN', 'GSIS Salary Loan', 'Loan', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GPREMDIFF', 'Ret. Prem Diff.', 'Regular', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('PLOAN', 'Pag-ibig Loan', 'Loan', 'PAGIBIG', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GPOLLOAN', 'POL Loan', 'Loan', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('HPTAX', 'Hazard Tax', 'Regular', 'BIR', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('LPTAX', 'LP Tax', 'Regular', 'BIR', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GCONSO', 'Conso Loan', 'Loan', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GEMERGENCY', 'GSIS Emergency ', 'Loan', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('PHOUSE', 'PAGIBIG Housing', 'Loan', 'PAGIBIG', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GOPTLOAN', 'Opt Loan', 'Loan', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('ITW', 'WHTax', 'Regular', 'BIR', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('LIFE', 'Ret. Prem', 'Regular', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('PHILHEALTH', 'PhilHealth Premium', 'Regular', 'PHILHEALTH', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('PAGIBIG', 'Pag-ibig', 'Regular', 'PAGIBIG', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('', '', 'Regular', 'GSIS', '', '1');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GEducational', 'GSIS Educational', 'Loan', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('PCALAM', 'Pagibig Calamity Loan', 'Loan', 'PAGIBIG', '', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('GSISINSUR', 'GSIS Group Insurance', 'Contribution', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('REF', 'Refund', 'Others', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('ARRLIP', 'ARRLIP', 'Contribution', 'GSIS', '0', '0');
INSERT INTO `tblDeduction` (`deductionCode`, `deductionDesc`, `deductionType`, `deductionGroupCode`, `deductionAccountCode`, `hidden`) VALUES ('WHTPV', 'Withholding Tax Previous Months', 'Regular', 'BIR', '', '0');


#
# TABLE STRUCTURE FOR: tblDeductionGroup
#

DROP TABLE IF EXISTS `tblDeductionGroup`;

CREATE TABLE `tblDeductionGroup` (
  `deduct_id` int(11) NOT NULL,
  `deductionGroupCode` varchar(20) DEFAULT NULL,
  `deductionGroupDesc` varchar(50) DEFAULT NULL,
  `deductionGroupAccountCode` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblDeductionGroup` (`deduct_id`, `deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('2', 'GSIS', 'Government Service Insurance System', '20201020');
INSERT INTO `tblDeductionGroup` (`deduct_id`, `deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('3', 'BIR', 'Bureau of Internal Revenue', '20201010');
INSERT INTO `tblDeductionGroup` (`deduct_id`, `deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('4', 'PHILHEALTH', 'Philippine Health Insurance Corporation', '101010111');
INSERT INTO `tblDeductionGroup` (`deduct_id`, `deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('5', 'PAGIBIG', 'Home Development Mutual Fund', '1010112');
INSERT INTO `tblDeductionGroup` (`deduct_id`, `deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('0', 'COCO LIFE', 'COCO LIFE', '1');
INSERT INTO `tblDeductionGroup` (`deduct_id`, `deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('1', 'LBP', 'LANDBANK', '0');


#
# TABLE STRUCTURE FOR: tblDuties
#

DROP TABLE IF EXISTS `tblDuties`;

CREATE TABLE `tblDuties` (
  `duties_index` int(11) NOT NULL AUTO_INCREMENT,
  `positionCode` varchar(20) NOT NULL,
  `duties` text NOT NULL,
  `percentWork` int(5) NOT NULL,
  `dutyNumber` int(11) NOT NULL,
  PRIMARY KEY (`duties_index`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('1', 'COMP3', 'Designs software/hardware-related training module for computer literacy', '5', '1');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('3', '', 'Analyzes and designs computer system application towards the efficient utilization of the computer for efficient attainment of system requirements', '25', '1');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('4', '', 'Supervises system development and continuously evaluates system designs to ensure its effectiveness', '25', '2');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('5', '', 'Establishes program specifications and assigns programming jobs to subordinates', '20', '3');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('6', '', 'Monitors the provision of IT services and conduct of computer-related research', '15', '4');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('7', '', 'Designs software/hardware-related training module for computer literacy', '5', '5');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('8', '', 'Establishes work schedules and bases for job-cost accounting', '5', '6');
INSERT INTO `tblDuties` (`duties_index`, `positionCode`, `duties`, `percentWork`, `dutyNumber`) VALUES ('9', '', 'Performs other related tasks as maybe assigned from time to time', '5', '7');


#
# TABLE STRUCTURE FOR: tblEducationalLevel
#

DROP TABLE IF EXISTS `tblEducationalLevel`;

CREATE TABLE `tblEducationalLevel` (
  `level` int(11) NOT NULL DEFAULT 0,
  `levelCode` varchar(30) NOT NULL DEFAULT '',
  `levelDesc` varchar(50) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`levelCode`),
  KEY `levelDesc` (`levelDesc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('7', 'ELM', 'Elementary', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('5', 'VCL', 'Vocational', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('0', 'MAS', 'Masteral', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('3', 'CLG', 'College', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('2', 'MAMS', 'Master\'s Degree', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('1', 'Ph.D.', 'Doctorate', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('6', 'HSL', 'High School', '1');
INSERT INTO `tblEducationalLevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('0', 'GDS', 'Graduate Studies', '0');


#
# TABLE STRUCTURE FOR: tblEmpAccount
#

DROP TABLE IF EXISTS `tblEmpAccount`;

CREATE TABLE `tblEmpAccount` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `userName` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `userPassword` varchar(255) NOT NULL,
  `userLevel` int(2) NOT NULL DEFAULT 5,
  `userPermission` varchar(20) NOT NULL DEFAULT 'Employee',
  `accessPermission` varchar(15) NOT NULL DEFAULT '1234',
  `assignedGroup` varchar(20) NOT NULL DEFAULT '',
  `signatory` text NOT NULL,
  `signatoryPosition` text NOT NULL,
  `is_assistant` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`empNumber`),
  KEY `Emp_No` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEmpAccount` (`empNumber`, `userName`, `userPassword`, `userLevel`, `userPermission`, `accessPermission`, `assignedGroup`, `signatory`, `signatoryPosition`, `is_assistant`) VALUES ('1111', 'admin@paete.gov.ph', 'a7070cd4e44379cb4f5d2ee11b00f225', '1', 'hr', '123456', '', '', '', '0');
INSERT INTO `tblEmpAccount` (`empNumber`, `userName`, `userPassword`, `userLevel`, `userPermission`, `accessPermission`, `assignedGroup`, `signatory`, `signatoryPosition`, `is_assistant`) VALUES ('PE-MGR020106', 'maritess.reyes', '90ca772b7343dc2c37e76f217cc7608a', '1', 'hr', '123456', '', '', '', '0');
INSERT INTO `tblEmpAccount` (`empNumber`, `userName`, `userPassword`, `userLevel`, `userPermission`, `accessPermission`, `assignedGroup`, `signatory`, `signatoryPosition`, `is_assistant`) VALUES ('EO-RQB0000', 'ronald.cosico', '90ca772b7343dc2c37e76f217cc7608a', '4', 'executive', '', '', '', '', '0');
INSERT INTO `tblEmpAccount` (`empNumber`, `userName`, `userPassword`, `userLevel`, `userPermission`, `accessPermission`, `assignedGroup`, `signatory`, `signatoryPosition`, `is_assistant`) VALUES ('0100-070117', 'frank.delarosa', 'a7070cd4e44379cb4f5d2ee11b00f225', '1', 'hr', '123456', '', '', '', '0');


#
# TABLE STRUCTURE FOR: tblEmpAddIncome
#

DROP TABLE IF EXISTS `tblEmpAddIncome`;

CREATE TABLE `tblEmpAddIncome` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(2) NOT NULL DEFAULT 0,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeTaxAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpAppointment
#

DROP TABLE IF EXISTS `tblEmpAppointment`;

CREATE TABLE `tblEmpAppointment` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `dateIssued` date NOT NULL DEFAULT '0000-00-00',
  `datePublished` date NOT NULL DEFAULT '0000-00-00',
  `placePublished` varchar(100) NOT NULL DEFAULT '',
  `relevantExperience` text NOT NULL,
  `relevantTraining` text NOT NULL,
  `appointmentissuedcode` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`appointmentissuedcode`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpBenefits
#

DROP TABLE IF EXISTS `tblEmpBenefits`;

CREATE TABLE `tblEmpBenefits` (
  `benefitCode` int(10) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeMonth` int(2) NOT NULL DEFAULT 0,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`benefitCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpChild
#

DROP TABLE IF EXISTS `tblEmpChild`;

CREATE TABLE `tblEmpChild` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `childCode` mediumint(9) NOT NULL AUTO_INCREMENT,
  `childName` varchar(80) NOT NULL DEFAULT '',
  `childBirthDate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`childCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpDTR
#

DROP TABLE IF EXISTS `tblEmpDTR`;

CREATE TABLE `tblEmpDTR` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dtrDate` date NOT NULL DEFAULT '0000-00-00',
  `inAM` time NOT NULL DEFAULT '00:00:00',
  `outAM` time NOT NULL DEFAULT '00:00:00',
  `inPM` time NOT NULL DEFAULT '00:00:00',
  `outPM` time NOT NULL DEFAULT '00:00:00',
  `inOT` time NOT NULL DEFAULT '00:00:00',
  `outOT` time NOT NULL DEFAULT '00:00:00',
  `DTRreason` varchar(100) NOT NULL,
  `remarks` varchar(255) NOT NULL DEFAULT '',
  `otherInfo` varchar(255) NOT NULL DEFAULT '',
  `OT` int(1) NOT NULL DEFAULT 0,
  `name` text NOT NULL,
  `ip` text NOT NULL,
  `editdate` text NOT NULL,
  `perdiem` char(1) NOT NULL DEFAULT '',
  `oldValue` text DEFAULT NULL,
  `wfh` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dtrDate` (`dtrDate`),
  KEY `idx_empNumber` (`empNumber`)
) ENGINE=MyISAM AUTO_INCREMENT=504800 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504779', '0100-070117', '2024-08-05', '08:39:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=08:39:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504780', '0100-070117', '2024-08-07', '09:49:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:49:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504781', '0100-070117', '2024-08-08', '09:34:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:34:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504782', '0100-070117', '2024-08-12', '09:22:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:22:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504783', '0100-070117', '2024-08-13', '09:13:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:13:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504784', '0100-070117', '2024-08-14', '09:03:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:03:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504785', '0100-070117', '2024-08-15', '09:27:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:27:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504786', '0100-070117', '2024-08-16', '09:02:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=09:02:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504787', '0100-070117', '2024-08-19', '10:03:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=10:03:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504788', '0100-070117', '2024-08-20', '08:31:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=08:31:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504789', '0100-070117', '2024-08-21', '00:00:00', '00:00:00', '08:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504790', '0100-070117', '2024-08-22', '00:00:00', '00:00:00', '08:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504791', '0100-070117', '2024-08-27', '00:00:00', '00:00:00', '08:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504792', '0100-070117', '2024-08-28', '00:00:00', '00:00:00', '08:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504793', '0100-070117', '2024-08-29', '07:09:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=07:09:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504794', '0100-070117', '2024-08-30', '08:56:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';ADMIN HRMIS', ';203.160.163.101', ';2024-09-04 10:27:19 AM', '', ';inAM=08:56:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504795', '0100-070117', '2024-10-01', '00:00:00', '00:00:00', '13:01:00', '17:50:00', '00:00:00', '00:00:00', '', '', '', '0', ';FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA', ';172.68.225.228;172.71.218.250;172.70.206.78;172.71.218.208', ';2024-11-04 03:34:53 PM;2024-11-04 03:42:04 PM;2024-11-04 11:59:30 PM;2024-11-05 01:06:28 AM', '', ';inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=00:00:00, outAM=00:00:00, inPM=08:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504796', '0100-070117', '2024-10-02', '08:10:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA', ';172.68.225.228;172.71.218.250;172.71.218.208', ';2024-11-04 03:34:53 PM;2024-11-04 03:42:04 PM;2024-11-05 01:06:28 AM', '', ';inAM=08:10:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=08:10:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=08:10:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504797', '0100-070117', '2024-10-03', '09:30:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA', ';172.68.225.228;172.71.218.250;172.71.218.208', ';2024-11-04 03:34:53 PM;2024-11-04 03:42:04 PM;2024-11-05 01:06:28 AM', '', ';inAM=09:30:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=09:30:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=09:30:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504798', '0100-070117', '2024-10-04', '09:46:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA;FRANK ALBERT DELA ROSA', ';172.68.225.228;172.71.218.250;172.71.218.208', ';2024-11-04 03:34:53 PM;2024-11-04 03:42:04 PM;2024-11-05 01:06:28 AM', '', ';inAM=09:46:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=09:46:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00;inAM=09:46:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');
INSERT INTO `tblEmpDTR` (`id`, `empNumber`, `dtrDate`, `inAM`, `outAM`, `inPM`, `outPM`, `inOT`, `outOT`, `DTRreason`, `remarks`, `otherInfo`, `OT`, `name`, `ip`, `editdate`, `perdiem`, `oldValue`, `wfh`) VALUES ('504799', '0100-070117', '2024-11-04', '08:08:00', '00:00:00', '00:00:00', '08:00:00', '00:00:00', '00:00:00', '', '', '', '0', ';FRANK ALBERT DELA ROSA', ';172.71.218.99', ';2024-11-05 04:53:05 AM', '', ';inAM=08:08:00, outAM=00:00:00, inPM=00:00:00, outPM=08:00:00, inOT=00:00:00, outOT=00:00:00', '0');


#
# TABLE STRUCTURE FOR: tblEmpDTR_log
#

DROP TABLE IF EXISTS `tblEmpDTR_log`;

CREATE TABLE `tblEmpDTR_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL,
  `log_date` datetime NOT NULL,
  `log_sql` text NOT NULL,
  `log_notify` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpDeductLoan
#

DROP TABLE IF EXISTS `tblEmpDeductLoan`;

CREATE TABLE `tblEmpDeductLoan` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `loanCode` int(100) NOT NULL AUTO_INCREMENT,
  `amountGranted` decimal(10,2) NOT NULL DEFAULT 0.00,
  `dateGranted` date DEFAULT NULL,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualStartYear` year(4) NOT NULL DEFAULT 0000,
  `actualStartMonth` int(2) NOT NULL DEFAULT 0,
  `actualEndYear` year(4) NOT NULL DEFAULT 0000,
  `actualEndMonth` int(2) NOT NULL DEFAULT 0,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`loanCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpDeductLoanConAdjust
#

DROP TABLE IF EXISTS `tblEmpDeductLoanConAdjust`;

CREATE TABLE `tblEmpDeductLoanConAdjust` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(100) NOT NULL AUTO_INCREMENT,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `type` varchar(20) NOT NULL DEFAULT '',
  `adjustSwitch` char(1) NOT NULL DEFAULT '',
  `adjustMonth` varchar(10) NOT NULL DEFAULT '0',
  `adjustYear` year(4) NOT NULL DEFAULT 0000,
  `adjustPeriod` int(4) NOT NULL DEFAULT 0,
  `xappointmentCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpDeductionRemit
#

DROP TABLE IF EXISTS `tblEmpDeductionRemit`;

CREATE TABLE `tblEmpDeductionRemit` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(100) NOT NULL DEFAULT 0,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` int(11) NOT NULL DEFAULT 0,
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) DEFAULT NULL,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  `orNumber` varchar(20) DEFAULT NULL,
  `orDate` date DEFAULT NULL,
  `TYPE` varchar(20) NOT NULL DEFAULT '',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `employerAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpDeductions
#

DROP TABLE IF EXISTS `tblEmpDeductions`;

CREATE TABLE `tblEmpDeductions` (
  `deductCode` int(10) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) DEFAULT NULL,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `amountGranted` decimal(10,2) NOT NULL DEFAULT 0.00,
  `dateGranted` date NOT NULL DEFAULT '0000-00-00',
  `actualStartYear` year(4) NOT NULL DEFAULT 0000,
  `actualStartMonth` int(2) NOT NULL DEFAULT 0,
  `actualEndYear` year(4) NOT NULL DEFAULT 0000,
  `actualEndMonth` int(2) NOT NULL DEFAULT 0,
  `annual` decimal(10,2) NOT NULL DEFAULT 0.00,
  `monthly` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`deductCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpDuties
#

DROP TABLE IF EXISTS `tblEmpDuties`;

CREATE TABLE `tblEmpDuties` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `percentWork` decimal(5,2) NOT NULL DEFAULT 0.00,
  `duties` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpExam
#

DROP TABLE IF EXISTS `tblEmpExam`;

CREATE TABLE `tblEmpExam` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `examCode` varchar(20) NOT NULL DEFAULT '',
  `examDate` date NOT NULL DEFAULT '0000-00-00',
  `examRating` decimal(4,2) NOT NULL DEFAULT 0.00,
  `examPlace` varchar(100) NOT NULL DEFAULT '',
  `licenseNumber` varchar(15) DEFAULT NULL,
  `dateRelease` date NOT NULL DEFAULT '0000-00-00',
  `ExamIndex` int(10) NOT NULL AUTO_INCREMENT,
  `verifier` varchar(50) NOT NULL,
  `reviewer` varchar(50) NOT NULL,
  PRIMARY KEY (`ExamIndex`),
  KEY `Emp_No` (`empNumber`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEmpExam` (`empNumber`, `examCode`, `examDate`, `examRating`, `examPlace`, `licenseNumber`, `dateRelease`, `ExamIndex`, `verifier`, `reviewer`) VALUES ('0100-070117', 'CSCProf', '2022-08-07', '80.17', 'Sta. Cruz, Laguna', '', '0000-00-00', '2', '', '');


#
# TABLE STRUCTURE FOR: tblEmpIncome
#

DROP TABLE IF EXISTS `tblEmpIncome`;

CREATE TABLE `tblEmpIncome` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(2) NOT NULL DEFAULT 0,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `officeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `netPay` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpIncomeAdjust
#

DROP TABLE IF EXISTS `tblEmpIncomeAdjust`;

CREATE TABLE `tblEmpIncomeAdjust` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeMonth` varchar(10) NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `type` varchar(20) NOT NULL DEFAULT '',
  `adjustSwitch` char(1) NOT NULL DEFAULT '',
  `adjustMonth` varchar(10) NOT NULL DEFAULT '0',
  `adjustYear` year(4) NOT NULL DEFAULT 0000,
  `adjustPeriod` int(4) NOT NULL DEFAULT 0,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpIncomeRATA
#

DROP TABLE IF EXISTS `tblEmpIncomeRATA`;

CREATE TABLE `tblEmpIncomeRATA` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incRAAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incTAAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeave
#

DROP TABLE IF EXISTS `tblEmpLeave`;

CREATE TABLE `tblEmpLeave` (
  `leaveID` int(11) NOT NULL AUTO_INCREMENT,
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `requestID` varchar(10) NOT NULL DEFAULT '',
  `leaveCode` char(3) NOT NULL DEFAULT '',
  `specificLeave` varchar(20) NOT NULL DEFAULT '',
  `reason` varchar(50) DEFAULT NULL,
  `leaveFrom` date NOT NULL DEFAULT '0000-00-00',
  `leaveTo` date NOT NULL DEFAULT '0000-00-00',
  `certifyHR` char(1) NOT NULL DEFAULT 'N',
  `approveChief` char(1) NOT NULL DEFAULT 'N',
  `approveRequest` char(1) NOT NULL DEFAULT 'N',
  `remarks` varchar(50) DEFAULT NULL,
  `inoutpatient` varchar(20) NOT NULL DEFAULT '',
  `vllocation` varchar(20) NOT NULL DEFAULT '',
  `commutation` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`leaveID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance`;

CREATE TABLE `tblEmpLeaveBalance` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance_040716
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance_040716`;

CREATE TABLE `tblEmpLeaveBalance_040716` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance_11242016
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance_11242016`;

CREATE TABLE `tblEmpLeaveBalance_11242016` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance_Aug16
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance_Aug16`;

CREATE TABLE `tblEmpLeaveBalance_Aug16` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance_Jan2017
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance_Jan2017`;

CREATE TABLE `tblEmpLeaveBalance_Jan2017` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance_w/Dec2016
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance_w/Dec2016`;

CREATE TABLE `tblEmpLeaveBalance_w/Dec2016` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLeaveBalance_w/o_Nov2016
#

DROP TABLE IF EXISTS `tblEmpLeaveBalance_w/o_Nov2016`;

CREATE TABLE `tblEmpLeaveBalance_w/o_Nov2016` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(2) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(10) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(2) NOT NULL DEFAULT 0,
  `totalTardyHour` int(3) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(3) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(10) NOT NULL DEFAULT 0,
  `off_gain` int(10) NOT NULL DEFAULT 0,
  `off_used` int(10) NOT NULL DEFAULT 0,
  `flBalance` int(2) NOT NULL DEFAULT 0,
  `flPreBalance` int(2) NOT NULL DEFAULT 0,
  `plBalance` int(2) NOT NULL DEFAULT 0,
  `plPreBalance` int(2) NOT NULL DEFAULT 0,
  `mtlBalance` int(2) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(2) NOT NULL DEFAULT 0,
  `ptlBalance` int(2) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(2) NOT NULL DEFAULT 0,
  `stlBalance` int(2) NOT NULL DEFAULT 0,
  `stlPreBalance` int(2) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLocalHoliday
#

DROP TABLE IF EXISTS `tblEmpLocalHoliday`;

CREATE TABLE `tblEmpLocalHoliday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpLongevity
#

DROP TABLE IF EXISTS `tblEmpLongevity`;

CREATE TABLE `tblEmpLongevity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `longiDate` date NOT NULL DEFAULT '0000-00-00',
  `longiAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `longiPercent` int(2) NOT NULL DEFAULT 0,
  `longiPay` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpMealDetails
#

DROP TABLE IF EXISTS `tblEmpMealDetails`;

CREATE TABLE `tblEmpMealDetails` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(12) NOT NULL DEFAULT '',
  `mealAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(2) NOT NULL DEFAULT 0,
  `noOfDays` int(11) NOT NULL DEFAULT 0,
  `datesCovered` text NOT NULL,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpMeeting
#

DROP TABLE IF EXISTS `tblEmpMeeting`;

CREATE TABLE `tblEmpMeeting` (
  `meetingID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `meetingTitle` text NOT NULL,
  `meetingDate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`meetingID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpMonetization
#

DROP TABLE IF EXISTS `tblEmpMonetization`;

CREATE TABLE `tblEmpMonetization` (
  `mon_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `vlMonetize` decimal(5,3) NOT NULL DEFAULT 0.000,
  `slMonetize` decimal(5,3) NOT NULL DEFAULT 0.000,
  `processMonth` int(2) NOT NULL DEFAULT 0,
  `processYear` int(4) NOT NULL DEFAULT 0,
  `monetizeMonth` int(2) NOT NULL DEFAULT 0,
  `monetizeYear` year(4) NOT NULL DEFAULT 0000,
  `monetizeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`mon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpNetPay
#

DROP TABLE IF EXISTS `tblEmpNetPay`;

CREATE TABLE `tblEmpNetPay` (
  `periodMonth` int(11) NOT NULL DEFAULT 0,
  `periodYear` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  UNIQUE KEY `uid` (`periodMonth`,`periodYear`,`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpOB
#

DROP TABLE IF EXISTS `tblEmpOB`;

CREATE TABLE `tblEmpOB` (
  `obID` int(11) NOT NULL AUTO_INCREMENT,
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `requestID` varchar(10) NOT NULL DEFAULT '',
  `obDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `obDateTo` date NOT NULL DEFAULT '0000-00-00',
  `obTimeFrom` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  `obTimeTo` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  `obPlace` varchar(100) NOT NULL DEFAULT '',
  `obMeal` char(1) NOT NULL DEFAULT '',
  `purpose` text NOT NULL,
  `official` char(1) NOT NULL DEFAULT 'N',
  `approveRequest` char(1) NOT NULL DEFAULT 'N',
  `approveChief` char(1) NOT NULL DEFAULT 'N',
  `approveHR` char(1) NOT NULL DEFAULT 'N',
  `is_override` int(11) DEFAULT NULL,
  PRIMARY KEY (`obID`),
  KEY `obDateFrom` (`obDateFrom`),
  KEY `obDateTo` (`obDateTo`),
  KEY `empNumber` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpOTDetails
#

DROP TABLE IF EXISTS `tblEmpOTDetails`;

CREATE TABLE `tblEmpOTDetails` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(2) NOT NULL DEFAULT 0,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `wdNoHrs` int(11) NOT NULL DEFAULT 0,
  `wdNoMins` int(11) NOT NULL DEFAULT 0,
  `weNoHrs` int(11) NOT NULL DEFAULT 0,
  `weNoMins` int(11) NOT NULL DEFAULT 0,
  `ratePerHr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ratePerMin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `wdGrossHr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `wdGrossMin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `weGrossHr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `weGrossMin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `earnedPeriod` decimal(10,2) NOT NULL DEFAULT 0.00,
  `percent` int(11) NOT NULL DEFAULT 0,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpOtherSched
#

DROP TABLE IF EXISTS `tblEmpOtherSched`;

CREATE TABLE `tblEmpOtherSched` (
  `rec_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '0',
  `fromDate` date NOT NULL DEFAULT '0000-00-00',
  `toDate` date NOT NULL DEFAULT '0000-00-00',
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`rec_ID`),
  KEY `idx_empNumber` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpOvertime
#

DROP TABLE IF EXISTS `tblEmpOvertime`;

CREATE TABLE `tblEmpOvertime` (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `otPurpose` text NOT NULL,
  `otOutput` text NOT NULL,
  `docNumber` varchar(15) NOT NULL DEFAULT '',
  `otDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `otDateTo` date NOT NULL DEFAULT '0000-00-00',
  `otTimeFrom` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  `otTimeTo` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  PRIMARY KEY (`otID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpPersonal
#

DROP TABLE IF EXISTS `tblEmpPersonal`;

CREATE TABLE `tblEmpPersonal` (
  `empID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middlename` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` varchar(10) DEFAULT NULL,
  `nameExtension` varchar(10) DEFAULT '',
  `salutation` varchar(15) NOT NULL,
  `sex` char(1) NOT NULL DEFAULT 'M',
  `civilStatus` varchar(20) NOT NULL DEFAULT 'Single',
  `spouse` varchar(80) NOT NULL DEFAULT '',
  `spouseSurname` varchar(80) NOT NULL,
  `spouseFirstname` varchar(80) NOT NULL,
  `spouseMiddlename` varchar(80) NOT NULL,
  `spousenameExtension` varchar(80) NOT NULL,
  `spouseWork` varchar(50) NOT NULL DEFAULT '',
  `spouseBusName` varchar(70) NOT NULL DEFAULT '',
  `spouseBusAddress` text DEFAULT NULL,
  `spouseTelephone` varchar(10) DEFAULT NULL,
  `tin` varchar(20) DEFAULT NULL,
  `citizenship` varchar(10) NOT NULL DEFAULT '',
  `dualCitizenshipType` varchar(20) NOT NULL,
  `dualCitizenshipCountryId` int(11) NOT NULL,
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `birthPlace` varchar(80) NOT NULL DEFAULT '',
  `bloodType` varchar(6) DEFAULT NULL,
  `height` decimal(5,2) NOT NULL DEFAULT 0.00,
  `weight` decimal(5,2) NOT NULL DEFAULT 0.00,
  `residentialAddress` text DEFAULT NULL,
  `lot1` varchar(10) NOT NULL,
  `street1` varchar(50) NOT NULL,
  `subdivision1` varchar(50) NOT NULL,
  `barangay1` varchar(50) NOT NULL,
  `city1` varchar(50) NOT NULL,
  `province1` varchar(50) NOT NULL,
  `zipCode1` int(4) DEFAULT NULL,
  `telephone1` varchar(20) DEFAULT NULL,
  `permanentAddress` text DEFAULT NULL,
  `lot2` varchar(10) NOT NULL,
  `street2` varchar(50) NOT NULL,
  `subdivision2` varchar(50) NOT NULL,
  `barangay2` varchar(50) NOT NULL,
  `city2` varchar(50) NOT NULL,
  `province2` varchar(50) NOT NULL,
  `zipCode2` int(4) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `fatherName` varchar(80) NOT NULL DEFAULT '',
  `fatherSurname` varchar(80) NOT NULL,
  `fatherFirstname` varchar(80) NOT NULL,
  `fatherMiddlename` varchar(80) NOT NULL,
  `fathernameExtension` varchar(80) NOT NULL,
  `motherName` varchar(80) NOT NULL DEFAULT '',
  `motherSurname` varchar(80) NOT NULL,
  `motherFirstname` varchar(80) NOT NULL,
  `motherMiddlename` varchar(80) NOT NULL,
  `parentAddress` text DEFAULT NULL,
  `skills` text NOT NULL,
  `nadr` text DEFAULT NULL,
  `miao` text DEFAULT NULL,
  `relatedThird` char(1) DEFAULT NULL,
  `relatedDegreeParticularsThird` text DEFAULT NULL,
  `relatedFourth` char(1) DEFAULT NULL,
  `relatedDegreeParticulars` text DEFAULT NULL,
  `violateLaw` char(1) DEFAULT NULL,
  `violateLawParticulars` text DEFAULT NULL,
  `formallyCharged` char(1) DEFAULT NULL,
  `formallyChargedParticulars` text DEFAULT NULL,
  `adminCase` char(1) DEFAULT NULL,
  `adminCaseParticulars` text DEFAULT NULL,
  `forcedResign` char(1) DEFAULT NULL,
  `forcedResignParticulars` text DEFAULT NULL,
  `candidate` char(1) DEFAULT NULL,
  `candidateParticulars` text DEFAULT NULL,
  `campaign` char(1) NOT NULL,
  `campaignParticulars` text NOT NULL,
  `immigrant` char(1) NOT NULL,
  `immigrantParticulars` text NOT NULL,
  `indigenous` char(1) DEFAULT NULL,
  `indigenousParticulars` text DEFAULT NULL,
  `disabled` char(1) DEFAULT NULL,
  `disabledParticulars` text DEFAULT NULL,
  `soloParent` char(1) DEFAULT NULL,
  `soloParentParticulars` text DEFAULT NULL,
  `signature` varchar(50) NOT NULL DEFAULT '',
  `dateAccomplished` date DEFAULT '0000-00-00',
  `comTaxNumber` varchar(10) NOT NULL DEFAULT '',
  `issuedAt` varchar(50) DEFAULT NULL,
  `issuedOn` date NOT NULL DEFAULT '0000-00-00',
  `gsisNumber` varchar(25) DEFAULT NULL,
  `businessPartnerNumber` varchar(25) NOT NULL,
  `philHealthNumber` varchar(14) DEFAULT NULL,
  `sssNumber` varchar(20) DEFAULT '',
  `pagibigNumber` varchar(14) DEFAULT NULL,
  `AccountNum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`empID`),
  KEY `Emp_No` (`empNumber`),
  KEY `empID` (`empID`),
  FULLTEXT KEY `surname` (`surname`)
) ENGINE=MyISAM AUTO_INCREMENT=278 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('1', '1111', 'HRMIS', 'ADMIN', '', NULL, '', '', 'M', 'Single', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '0000-00-00', '', NULL, '0.00', '0.00', NULL, '', '', '', '', '', '', NULL, NULL, NULL, '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', NULL, '', NULL, '', NULL, NULL);
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('203', 'PE-BCC032392', 'CAINTO', 'BEATRIZ', '', '', '', '', 'F', 'Married', '', '', '', '', '', '', '', NULL, NULL, '', 'Filipino', '', '0', '1967-03-08', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('202', '0100-070117', 'DELA ROSA', 'FRANK ALBERT', 'NAVARRO', '', '', 'MR.', 'M', 'Single', '', '', '', '', '', '', '', NULL, NULL, '301836126', 'Filipino', '', '0', '1988-06-14', 'PAETE, LAGUNA', 'A+', '5.70', '90.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '09065554690', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('201', 'EO-RQB0000', 'COSICO', 'RONALD', 'BAGUE', '', '', 'Hon.', 'M', 'Married', '', '', '', '', '', '', '', NULL, NULL, '', 'Filipino', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('200', 'PE-MGR020106', 'REYES', 'MARITESS', 'GUERRERO', '', '', '', 'F', 'Single', '', '', '', '', '', '', '', NULL, NULL, '289990974', 'Filipino', '', '0', '1985-09-10', 'Libmanan', 'O+', '5.50', '80.00', NULL, '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '2003954245', '', '08-000090120-6', '0', '121012199542', '0');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('204', 'PE-BSA020123', 'ACHOY', 'BRYAN', '', 'S', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('205', 'PE-PBA020197', 'ADEA', ' PEMABELLE ', 'B.', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('206', 'PE-ALA031616', ' ADEFUIN', 'ARMIE ', '', 'L.', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('207', 'PE-CGA090123', 'AFRICANO', 'CHRIS JOY ', '', 'G', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('208', 'PE-CEA010319', 'AFUANG	 ', 'CARLA ', '', 'E', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('209', 'PE-MGA030199', 'AFUNGGOL	 ', 'MOISES ', '', 'G', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('210', 'PE-LVA010108', 'AFURONG	', ' LEONARD ', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('211', 'PE-EEA060123', 'ALPON	 ', 'EDITHA', '', 'E', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('212', 'PE-MYA070122', 'ASEOCHE	', 'MAR YASUKAZU', ' ', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('213', 'PE-JCA030107', 'ASIDO	', ' JERRY ', '', 'C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('214', 'PE-OMB 010106', 'BABAEL	 ', 'OFELIA ', '', 'M', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('215', 'PE-MBB031692', 'BAGABALDO	 ', 'MARITA ', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('216', 'PE-LLB050105', '  BAGCUS	', ' LOREN', '', 'L', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('217', 'PE-ADB070122', 'BALDEMOR	 ', 'ANALIE', '', 'D', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('218', 'PE-DHB010111', 'BALDEMOR	 ', 'DARWIN H.', '', 'H', '', ' ', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('219', 'PE-JLB070122', 'BALDEMOR	', 'JERIEL ', '', 'L', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('220', 'PE-LMB070201', 'BALDEMOR	 ', 'LEONARDO ', '', 'M', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('221', 'PE-SRB120104', 'BALDEMOR	 ', 'SHERYLL ', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('222', 'PE-RGB011392', 'BALLARES	 ', 'ROSALINDA ', '', 'G', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('223', 'PE-JRB020299', 'BARRETTO	 ', 'JOEL R.', 'R', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('224', 'PE-SDB030123', 'BAUTISTA', 'SHAWN MICHAEL LEE D.', '', 'D', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('225', 'PE-BBB020193', 'BUNYE	 ', 'BRIGIDA B.', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('226', 'PE-JMC070122', 'CADAWAS	 ', 'JOHN LAURENCE ', '', 'M', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('227', 'PE-SLC080192', 'CADAY	', 'SHEILA L.', '', 'L', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('228', 'PE-TRC010108', 'CADAYONA	 ', 'TERENCE ', '', 'R', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('229', 'PE-ANC020124', 'CAGAHASTIAN	 ', 'ADRIAN ', '', 'N', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('230', 'PE-CMC050105', 'CAINTO	 ', 'CHRISTINE ', '', 'M', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('231', 'PE-CDC060324', 'CAJIPE	 ', 'CHARLYN ', '', 'D', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('232', 'PE-MGAD010108', 'DANTOC	 ', 'MARY GRACE', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('233', 'PE-GED070120', 'DELA CRUZ	 ', 'GINO ', '', 'E', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('234', 'CE-MSD050218', 'DELOS SANTOS	 ', 'MARGIE ', '', 'SJ', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('235', ' PE-RVD070121', 'DE LUNA ', 'ROLANDO JR', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('236', 'PE-RGD030107', 'DIMATATAC	 ', 'RAMON ', '', 'G', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('237', 'PE-RRD021696', 'DONO	 ', 'ROBERTO ', '', 'R', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('238', 'PE-ACE050105', 'ENLAYO	 ', 'ANGELITO ', '', 'C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('239', 'PE-MPE010285', 'ESPAÑOLA	 ', 'MENCHIE ', '', 'P', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('240', 'PE-NSF010108', 'FERRER	 ', 'NANIT', '', 'S', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('241', 'PE-DMF081318', 'GAJITOS	 ', 'DEAN EMERSON', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('242', 'PE-FBG011703', 'GAJITOS	 ', 'FERNANDO', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('243', 'PE-NBG010890', 'GAJITOS	 ', 'NENITA ', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('244', 'PE-LBG010106', 'GARCIA	', 'LEOPOLDO JR', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('245', 'PE-NAG010106', 'GRIMPULA	', 'NENITA', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('246', 'PE-EVG010323', 'GONZALES	 ', 'ELLAINE JOY', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('247', 'PE-RBG070120', 'GONZALES	', 'RICHARD', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('248', 'PE-ACG020123', 'GORDULA	 ', 'AILA DOMINIQUE ', '', ' C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('249', 'PE-VNJ091018', ' JUAREZ	 ', 'VLADIMIR ', '', 'N', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('250', 'PE-RBL010198', 'LISAY	 ', 'ROMEO ', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('251', 'PE-CCM080123', 'MADRIGAL	 ', 'CORAZON ', '', 'C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('252', 'PE-JPM30107', 'MADRIGAL	', 'JOSEPH ', '', 'P', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('253', 'PE-RCM120195', 'MEDINA	 ', 'RAMON ', '', 'C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('254', 'PE-PEM090121', 'MONTES	 ', 'PHILIP ', '', 'E', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('255', 'PE-RCN070115', 'NAVAL	 ', 'ROSIE', '', 'C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('256', 'PE-AVN10305', 'NOCEJA	', 'ALBERT ', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('257', 'PE RVN 010206', 'NOMBRADO	', 'RODELINE ', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('258', 'PE-EBP070122', 'PAGALANAN	 ', 'EDMOND', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('259', 'PE-LBP020106', 'PANGILINAN	 ', 'LERMA ', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('260', 'PE-RRP022194', 'PILLAS	 ', 'RHODORA', '', 'R', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('261', 'PE-DTR012903', 'RAFOL	 ', 'DINAH', '', 'T', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('262', 'PE-LAR010220', 'RAMIREZ	 ', 'LANIE ', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('263', 'PE-AAA060109', 'RAMOS	 ', 'ANA VICTORIA', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('264', 'PE-JCR030124', 'RAMOS	 ', 'JOYZELLE', '', 'C', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('265', 'PE-RDR080204', 'REYES	', 'RODHELYN', 'D', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('266', 'PE-EDR030314', 'ROCAMORA	 ', 'EXEQUIEL ', '', 'D', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('267', 'PE-MAR030211', 'RUANTO	 ', 'MARILITO ', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('268', 'PE-MMS081897', 'SANCHEZ	 ', 'MA. VIVIAN', '', 'M', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('269', 'PE-ABS090122', 'SATINGIN	', 'ANTHONY', '', 'B', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('270', 'PE-EMS030121', 'SORIANO	 ', 'EDUARDO', '', 'M', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('271', 'PE-GVT031616', 'TRENCIO	 ', 'GARY', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('272', 'PE-MET030215', 'TRENCIO	 ', 'MARIA ELENA ', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('273', 'PE-RAT020197', 'TRENCIO	 ', 'ROSALINDA ', '', 'A', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('274', 'PE-MNU030520', ' UMALI	 ', 'MA. KATHRINA ', 'N', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('275', 'PE-JSV-020193', 'VALDECANTOS	 ', 'JOBETH ', '', 'S', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('276', 'PE-JIV020197', 'VALDELLON	', ' JOVITA', '', 'I', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblEmpPersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('277', 'PE-DVV031523', 'VALDELLON	 ', 'DEANNE MARIE', '', 'V', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: tblEmpPersonalx
#

DROP TABLE IF EXISTS `tblEmpPersonalx`;

CREATE TABLE `tblEmpPersonalx` (
  `empID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middlename` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` varchar(10) DEFAULT NULL,
  `nameExtension` varchar(10) DEFAULT '',
  `salutation` varchar(15) NOT NULL,
  `sex` char(1) NOT NULL DEFAULT 'M',
  `civilStatus` varchar(20) NOT NULL DEFAULT 'Single',
  `spouse` varchar(80) NOT NULL DEFAULT '',
  `spouseSurname` varchar(80) NOT NULL,
  `spouseFirstname` varchar(80) NOT NULL,
  `spouseMiddlename` varchar(80) NOT NULL,
  `spousenameExtension` varchar(80) NOT NULL,
  `spouseWork` varchar(50) NOT NULL DEFAULT '',
  `spouseBusName` varchar(70) NOT NULL DEFAULT '',
  `spouseBusAddress` text DEFAULT NULL,
  `spouseTelephone` varchar(10) DEFAULT NULL,
  `tin` varchar(20) DEFAULT NULL,
  `citizenship` varchar(10) NOT NULL DEFAULT '',
  `dualCitizenshipType` varchar(20) NOT NULL,
  `dualCitizenshipCountryId` int(11) NOT NULL,
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `birthPlace` varchar(80) NOT NULL DEFAULT '',
  `bloodType` varchar(6) DEFAULT NULL,
  `height` decimal(5,2) NOT NULL DEFAULT 0.00,
  `weight` decimal(5,2) NOT NULL DEFAULT 0.00,
  `residentialAddress` text DEFAULT NULL,
  `lot1` varchar(10) NOT NULL,
  `street1` varchar(50) NOT NULL,
  `subdivision1` varchar(50) NOT NULL,
  `barangay1` varchar(50) NOT NULL,
  `city1` varchar(50) NOT NULL,
  `province1` varchar(50) NOT NULL,
  `zipCode1` int(4) DEFAULT NULL,
  `telephone1` varchar(20) DEFAULT NULL,
  `permanentAddress` text DEFAULT NULL,
  `lot2` varchar(10) NOT NULL,
  `street2` varchar(50) NOT NULL,
  `subdivision2` varchar(50) NOT NULL,
  `barangay2` varchar(50) NOT NULL,
  `city2` varchar(50) NOT NULL,
  `province2` varchar(50) NOT NULL,
  `zipCode2` int(4) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `fatherName` varchar(80) NOT NULL DEFAULT '',
  `fatherSurname` varchar(80) NOT NULL,
  `fatherFirstname` varchar(80) NOT NULL,
  `fatherMiddlename` varchar(80) NOT NULL,
  `fathernameExtension` varchar(80) NOT NULL,
  `motherName` varchar(80) NOT NULL DEFAULT '',
  `motherSurname` varchar(80) NOT NULL,
  `motherFirstname` varchar(80) NOT NULL,
  `motherMiddlename` varchar(80) NOT NULL,
  `parentAddress` text DEFAULT NULL,
  `skills` text NOT NULL,
  `nadr` text DEFAULT NULL,
  `miao` text DEFAULT NULL,
  `relatedThird` char(1) DEFAULT NULL,
  `relatedDegreeParticularsThird` text DEFAULT NULL,
  `relatedFourth` char(1) DEFAULT NULL,
  `relatedDegreeParticulars` text DEFAULT NULL,
  `violateLaw` char(1) DEFAULT NULL,
  `violateLawParticulars` text DEFAULT NULL,
  `formallyCharged` char(1) DEFAULT NULL,
  `formallyChargedParticulars` text DEFAULT NULL,
  `adminCase` char(1) DEFAULT NULL,
  `adminCaseParticulars` text DEFAULT NULL,
  `forcedResign` char(1) DEFAULT NULL,
  `forcedResignParticulars` text DEFAULT NULL,
  `candidate` char(1) DEFAULT NULL,
  `candidateParticulars` text DEFAULT NULL,
  `campaign` char(1) NOT NULL,
  `campaignParticulars` text NOT NULL,
  `immigrant` char(1) NOT NULL,
  `immigrantParticulars` text NOT NULL,
  `indigenous` char(1) DEFAULT NULL,
  `indigenousParticulars` text DEFAULT NULL,
  `disabled` char(1) DEFAULT NULL,
  `disabledParticulars` text DEFAULT NULL,
  `soloParent` char(1) DEFAULT NULL,
  `soloParentParticulars` text DEFAULT NULL,
  `signature` varchar(50) NOT NULL DEFAULT '',
  `dateAccomplished` date DEFAULT '0000-00-00',
  `comTaxNumber` varchar(10) NOT NULL DEFAULT '',
  `issuedAt` varchar(50) DEFAULT NULL,
  `issuedOn` date NOT NULL DEFAULT '0000-00-00',
  `gsisNumber` varchar(25) DEFAULT NULL,
  `businessPartnerNumber` varchar(25) NOT NULL,
  `philHealthNumber` varchar(14) DEFAULT NULL,
  `sssNumber` varchar(20) DEFAULT '',
  `pagibigNumber` varchar(14) DEFAULT NULL,
  `AccountNum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`empNumber`),
  KEY `Emp_No` (`empNumber`),
  KEY `empID` (`empID`),
  FULLTEXT KEY `surname` (`surname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpPosition
#

DROP TABLE IF EXISTS `tblEmpPosition`;

CREATE TABLE `tblEmpPosition` (
  `empNumber` varchar(30) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `statusOfAppointment` varchar(50) NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  `plantillaGroupCode` varchar(10) NOT NULL DEFAULT '',
  `divisionCode` varchar(20) NOT NULL DEFAULT '',
  `sectionCode` varchar(20) NOT NULL DEFAULT '',
  `taxStatCode` varchar(20) NOT NULL DEFAULT '',
  `itemNumber` varchar(50) NOT NULL DEFAULT '',
  `salaryGradeNumber` int(2) NOT NULL DEFAULT 0,
  `authorizeSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `contractEndDate` date DEFAULT '0000-00-00',
  `effectiveDate` date NOT NULL DEFAULT '0000-00-00',
  `positionDate` date NOT NULL DEFAULT '0000-00-00',
  `longevityDate` date NOT NULL DEFAULT '0000-00-00',
  `longevityGap` decimal(4,2) DEFAULT 0.00,
  `firstDayAgency` date NOT NULL DEFAULT '0000-00-00',
  `firstDayGov` date NOT NULL DEFAULT '0000-00-00',
  `assignPlace` varchar(50) DEFAULT NULL,
  `stepNumber` int(2) NOT NULL DEFAULT 0,
  `dateIncremented` date NOT NULL DEFAULT '0000-00-00',
  `personnelAction` varchar(20) NOT NULL DEFAULT '',
  `employmentBasis` varchar(20) NOT NULL DEFAULT 'Fulltime',
  `categoryService` varchar(20) NOT NULL DEFAULT 'Career',
  `nature` varchar(20) NOT NULL DEFAULT 'Support',
  `hpFactor` decimal(2,0) NOT NULL DEFAULT 0,
  `longiFactor` decimal(2,0) DEFAULT 0,
  `payrollSwitch` char(1) NOT NULL DEFAULT 'N',
  `schemeCode` varchar(20) NOT NULL DEFAULT 'GEN',
  `itwSwitch` char(1) NOT NULL DEFAULT 'Y',
  `lifeRetSwitch` char(1) NOT NULL DEFAULT 'Y',
  `pagibigSwitch` char(1) NOT NULL DEFAULT 'Y',
  `philhealthSwitch` char(1) NOT NULL DEFAULT 'Y',
  `providentSwitch` char(1) NOT NULL DEFAULT '',
  `premiumAidSwitch` char(1) NOT NULL DEFAULT 'Y',
  `dtrSwitch` char(1) NOT NULL DEFAULT 'Y',
  `mcSwitch` char(1) NOT NULL DEFAULT 'Y',
  `hazardSwitch` char(1) NOT NULL DEFAULT 'Y',
  `longevitySwitch` char(1) NOT NULL DEFAULT 'Y',
  `PERASwitch` char(1) NOT NULL DEFAULT 'Y',
  `ADCOMSwitch` char(1) NOT NULL DEFAULT 'Y',
  `dependents` decimal(2,0) NOT NULL DEFAULT 0,
  `healthProvider` char(1) NOT NULL DEFAULT 'N',
  `tmpStepNumber` int(2) NOT NULL DEFAULT 0,
  `tmpActualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tmpDateIncremented` date NOT NULL DEFAULT '0000-00-00',
  `tmpPositionDate` date NOT NULL DEFAULT '0000-00-00',
  `regularDedSwitch` char(1) NOT NULL DEFAULT '',
  `contriDedSwitch` char(1) NOT NULL DEFAULT '',
  `loanDedSwitch` char(1) NOT NULL DEFAULT '',
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `riceSwitch` char(1) NOT NULL DEFAULT '',
  `detailedfrom` char(1) NOT NULL DEFAULT '',
  `departmentcode` varchar(5) NOT NULL DEFAULT '',
  `groupCode` varchar(10) DEFAULT NULL,
  `firefighter` char(1) NOT NULL DEFAULT 'N',
  `security` char(1) NOT NULL DEFAULT 'N',
  `uniqueItemNumber` varchar(50) NOT NULL DEFAULT '',
  `physician` char(1) DEFAULT 'N',
  `officecode` varchar(20) NOT NULL DEFAULT '',
  `service` varchar(50) NOT NULL DEFAULT '',
  `payrollGroupCode` varchar(50) DEFAULT NULL,
  `taxAmount` decimal(10,2) DEFAULT 0.00,
  `hpTax` decimal(10,2) DEFAULT NULL,
  `lpTax` decimal(10,2) DEFAULT NULL,
  `laundrySwitch` char(1) NOT NULL DEFAULT 'Y',
  `addPAGIBIGContri` decimal(10,2) NOT NULL DEFAULT 0.00,
  `includeSecondment` int(1) NOT NULL DEFAULT 0,
  `group1` varchar(20) NOT NULL DEFAULT '',
  `group2` varchar(20) NOT NULL DEFAULT '',
  `group3` varchar(20) NOT NULL DEFAULT '',
  `group4` varchar(20) NOT NULL DEFAULT '',
  `group5` varchar(20) NOT NULL DEFAULT '',
  `RATACode` char(3) DEFAULT NULL,
  `RATAVehicle` char(1) DEFAULT NULL,
  `taxRate` int(2) DEFAULT NULL,
  `taxSwitch` char(1) NOT NULL,
  PRIMARY KEY (`empNumber`),
  KEY `AppointmentCode` (`appointmentCode`),
  KEY `DivisionCode` (`divisionCode`),
  KEY `Emp_No` (`empNumber`),
  KEY `PositionCode` (`positionCode`),
  KEY `SectionCode` (`sectionCode`),
  KEY `ServiceCode` (`serviceCode`),
  KEY `TaxStatusCode` (`taxStatCode`),
  KEY `salaryGradeNumber` (`salaryGradeNumber`),
  KEY `authorizeSalary` (`authorizeSalary`),
  KEY `actualSalary` (`actualSalary`),
  KEY `itemNumber` (`itemNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('1111', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', NULL, '2021-07-13', '2021-07-13', '2021-07-13', '0.00', '2021-07-13', '2021-07-13', NULL, '0', '2021-07-13', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '2021-07-13', '2021-07-13', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-BCC032392', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('0100-070117', 'P', 'In-Service', 'ADA01', '', '', '', '', 'Single', 'PAE-MO-007', '7', '0.00', '14785.00', '0000-00-00', '2024-01-01', '0000-00-00', '0000-00-00', '0.00', '2007-07-01', '2007-07-01', '', '0', '0000-00-00', 'Original', 'FullTime', 'Career', 'Support', '0', '0', 'Y', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', 'LCEO', 'LGU', 'PR-Permanent', '0.00', NULL, NULL, 'Y', '0.00', '0', 'LCEO', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('EO-RQB0000', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MGR020106', 'P', 'In-Service', 'AO02', '', '', '', '', 'Single', 'PAE-HR-0061', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', '', '0', '0000-00-00', '', 'FullTime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', 'LGU-HRMO', 'LGU', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-BSA020123', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-PBA020197', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-ALA031616', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-CGA090123', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-CEA010319', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MGA030199', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-LVA010108', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-EEA060123', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MYA070122', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JCA030107', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-OMB 010106', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MBB031692', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-LLB050105', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-ADB070122', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-DHB010111', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JLB070122', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-LMB070201', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-SRB120104', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RGB011392', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JRB020299', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-SDB030123', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-BBB020193', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JMC070122', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-SLC080192', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-TRC010108', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-ANC020124', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-CMC050105', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-CDC060324', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MGAD010108', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-GED070120', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('CE-MSD050218', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES (' PE-RVD070121', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RGD030107', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RRD021696', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-ACE050105', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MPE010285', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-NSF010108', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-DMF081318', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-FBG011703', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-NBG010890', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-LBG010106', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-NAG010106', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-EVG010323', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RBG070120', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-ACG020123', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-VNJ091018', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RBL010198', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-CCM080123', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JPM30107', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RCM120195', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-PEM090121', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RCN070115', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-AVN10305', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE RVN 010206', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-EBP070122', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-LBP020106', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RRP022194', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-DTR012903', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-LAR010220', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-AAA060109', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JCR030124', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RDR080204', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-EDR030314', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MAR030211', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MMS081897', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-ABS090122', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-EMS030121', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-GVT031616', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MET030215', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-RAT020197', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-MNU030520', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JSV-020193', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-JIV020197', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblEmpPosition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('PE-DVV031523', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');


#
# TABLE STRUCTURE FOR: tblEmpReference
#

DROP TABLE IF EXISTS `tblEmpReference`;

CREATE TABLE `tblEmpReference` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `refName` varchar(80) NOT NULL DEFAULT '',
  `refAddress` varchar(255) NOT NULL DEFAULT '',
  `refTelephone` varchar(20) DEFAULT NULL,
  `ReferenceIndex` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ReferenceIndex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpRequest
#

DROP TABLE IF EXISTS `tblEmpRequest`;

CREATE TABLE `tblEmpRequest` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `requestID` int(6) NOT NULL AUTO_INCREMENT,
  `requestCode` varchar(20) NOT NULL DEFAULT '',
  `requestDate` date NOT NULL DEFAULT '0000-00-00',
  `requestDetails` text DEFAULT NULL,
  `requestStatus` varchar(30) NOT NULL DEFAULT '',
  `statusDate` date DEFAULT '0000-00-00',
  `remarks` varchar(50) DEFAULT NULL,
  `signatory` varchar(50) NOT NULL DEFAULT '',
  `listDisplay` int(1) NOT NULL DEFAULT 1,
  `Signatory1` text NOT NULL,
  `Sig1DateTime` datetime NOT NULL,
  `Signatory2` text NOT NULL,
  `Sig2DateTime` datetime NOT NULL,
  `Signatory3` text NOT NULL,
  `Sig3DateTime` datetime NOT NULL,
  `SignatoryFin` text NOT NULL,
  `SigFinDateTime` datetime NOT NULL,
  `file_location` varchar(255) NOT NULL,
  PRIMARY KEY (`requestID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpScholarship
#

DROP TABLE IF EXISTS `tblEmpScholarship`;

CREATE TABLE `tblEmpScholarship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empSchoolCode` int(10) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `ScholarshipCode` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpSchool
#

DROP TABLE IF EXISTS `tblEmpSchool`;

CREATE TABLE `tblEmpSchool` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `levelCode` varchar(20) NOT NULL DEFAULT '',
  `schoolName` varchar(80) NOT NULL DEFAULT '',
  `course` varchar(50) NOT NULL DEFAULT '',
  `yearGraduated` varchar(4) DEFAULT '',
  `units` varchar(15) DEFAULT NULL,
  `schoolFromDate` varchar(4) NOT NULL DEFAULT '0000',
  `schoolToDate` varchar(4) NOT NULL DEFAULT '0000',
  `ScholarshipCode` varchar(50) NOT NULL,
  `honors` text DEFAULT NULL,
  `courseCode` varchar(10) NOT NULL DEFAULT '',
  `SchoolIndex` int(11) NOT NULL AUTO_INCREMENT,
  `licensed` char(1) NOT NULL DEFAULT '',
  `graduated` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`SchoolIndex`),
  KEY `SchoolType` (`levelCode`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblEmpSchool` (`empNumber`, `levelCode`, `schoolName`, `course`, `yearGraduated`, `units`, `schoolFromDate`, `schoolToDate`, `ScholarshipCode`, `honors`, `courseCode`, `SchoolIndex`, `licensed`, `graduated`) VALUES ('POS4-5-2014', 'CLG', 'ISAT U', 'BS IS', '2012', '36', '2008', '2012', '', '', '', '1', '', 'Y');


#
# TABLE STRUCTURE FOR: tblEmpTraining
#

DROP TABLE IF EXISTS `tblEmpTraining`;

CREATE TABLE `tblEmpTraining` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `XtrainingCode` varchar(10) NOT NULL DEFAULT '',
  `trainingTitle` text NOT NULL,
  `trainingContractDate` date DEFAULT '0000-00-00',
  `trainingStartDate` date NOT NULL DEFAULT '0000-00-00',
  `trainingEndDate` date NOT NULL DEFAULT '0000-00-00',
  `trainingHours` decimal(5,2) NOT NULL DEFAULT 0.00,
  `trainingTypeofLD` varchar(100) NOT NULL,
  `trainingConductedBy` varchar(100) NOT NULL DEFAULT '',
  `trainingVenue` varchar(100) NOT NULL DEFAULT '',
  `trainingCost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `trainingDesc` varchar(200) NOT NULL DEFAULT '',
  `TrainingIndex` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`TrainingIndex`),
  KEY `Emp_No` (`empNumber`),
  KEY `TrainingID` (`XtrainingCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpTravelOrder
#

DROP TABLE IF EXISTS `tblEmpTravelOrder`;

CREATE TABLE `tblEmpTravelOrder` (
  `toID` int(10) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `toDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `toDateTo` date NOT NULL DEFAULT '0000-00-00',
  `destination` text NOT NULL,
  `purpose` text NOT NULL,
  `fund` varchar(30) NOT NULL DEFAULT '',
  `transportation` varchar(30) NOT NULL DEFAULT '',
  `perdiem` char(1) NOT NULL DEFAULT '',
  `wmeal` char(1) NOT NULL,
  PRIMARY KEY (`toID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpTripTicket
#

DROP TABLE IF EXISTS `tblEmpTripTicket`;

CREATE TABLE `tblEmpTripTicket` (
  `ttID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `destination` text NOT NULL,
  `purpose` text NOT NULL,
  `ttDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `ttDateTo` date NOT NULL DEFAULT '0000-00-00',
  `perdiem` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`ttID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblEmpVoluntaryWork
#

DROP TABLE IF EXISTS `tblEmpVoluntaryWork`;

CREATE TABLE `tblEmpVoluntaryWork` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `vwName` varchar(50) DEFAULT NULL,
  `vwAddress` text DEFAULT NULL,
  `vwDateFrom` date DEFAULT '0000-00-00',
  `vwDateTo` date DEFAULT '0000-00-00',
  `vwHours` decimal(4,2) DEFAULT 0.00,
  `vwPosition` varchar(50) DEFAULT NULL,
  `VoluntaryIndex` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`VoluntaryIndex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblExamType
#

DROP TABLE IF EXISTS `tblExamType`;

CREATE TABLE `tblExamType` (
  `examCode` varchar(20) NOT NULL DEFAULT '',
  `examDesc` varchar(50) NOT NULL DEFAULT '',
  `csElligible` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`examCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('RA1080', 'Philippine Bar Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('O', 'Others', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CATIII', 'Performance based', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('TBE', 'Teachers Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO1', 'Career Executive Service Officer 1', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('PRC-ChE', 'PRC Chemical Engineering Board', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSC-DE', 'CSC Data Encoder', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('MCP', 'Microsoft Certified Professional', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('MCDST', 'Microsoft Certified Desktop Support Technician', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CES', 'Career Executive Service Eligibility', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('PRC-Geo', 'Geologist Licensure Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO5', 'Career Executive Service Officer 5', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO4', 'Career Executive Service Officer 4', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('SROC', 'Special Radiotelephone Operator Certificate', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CPA-BE', 'CPA Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('MTBE', 'Medical Technology Board Exams', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('GCE', 'General Clerical Examinatiion', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('NBE', 'Nutritionist Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('AGSERP', 'Agri Office Exam', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('AMO', 'Accounting Machine Operator', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('BEN', 'Nursing Licensure Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CEBE', 'Chemical Engineering Board', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSP', 'Career Service Professional', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('FBS', 'Forester Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('Cpa', 'Certified Public Accountant', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('SAP', 'Stenograph exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CEB', 'Civil Engineering Board Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ACD', 'Chemist Board Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('OCD', 'General Clerical Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('DAE', 'Profesional Examinations', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('UOP', 'PD 997', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ER', 'CESO 1', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('NLE', 'Nursing Licensure Examinations', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('NCIII', 'NCIII Bookkeping', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('OP', 'Nutritionists and Dietitians Licensure Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('IO', 'Medical Technology Board Exams', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ABE', 'Agriculture Board Examination', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('OS', 'Career Executive Service Officer 2', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('DA', 'Career Executive Service Eligable', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CO', 'Management Analysis', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CS', 'First Grade Civil Service Entrance', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('TTA', 'Testimonial test for Automotive', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('BOE', 'Barangay Official Eligibility', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSE-1', 'First Grade Civil Service Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSE-2', 'Second Grade Civil Service Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CRE2', 'CESO Rank II', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CA', 'Certified Public Accountant licensure exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('SE', 'Profesore', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('SW', 'Career Service Eligibility', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('DS', 'CPA Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSEB', 'Career Executive Service Board', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('PD907', 'Presidential Decree 907 (Honor Graduate)', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('MEB', 'Mechanical Engineering Board Exam', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSC-S', 'CSC Local Scholarship Qualifying Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('AElecEng', 'Assistant Electrical Engineering Licensure Exam', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('RANo1080', 'RA No 1080', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSCTTO', 'CSC Testimonial Telephone Operator', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSC-LOC', 'Career Service Professional Exam for Local Govt', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSSP', 'Career Service Subprofessional', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('AEEng', 'Associate Electrical Engineer', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('EEBE', 'Electronics Engineering Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('EBE', 'Electrical Engineering Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO', 'Career Executive Service Officer', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('PBET', 'Professional Board Exam for Teachers', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CATI', 'Skills based', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CATII', 'License', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('GROC', 'Government Radio Operator Certificate', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ME', 'Mechanical Engineering Licensure Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('LET', 'Licensure Examination for Teachers (LET)', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSCProf', 'Career Service Professional', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('PAE', 'Professional Agricultural Engineer', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('MPLE', 'Master Plumbers Licensure Exam', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('MELE', 'Master Electrician Licensure Exam', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('HGE', 'Honor Graduate Eligibility', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO3', 'Career Executive Service Officer 3', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ALE', 'Agricultural Licensure Examination', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('SEBE', 'Sanitary Engineering Board Exam', 'Y');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ChemLicExam', 'Chemistry Licensure Examination', '');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('ElecTechLic', 'Electronics Technician Licensure Examination', 'N');
INSERT INTO `tblExamType` (`examCode`, `examDesc`, `csElligible`) VALUES ('PRC', 'Professional Regulation Commission', '');


#
# TABLE STRUCTURE FOR: tblFlagCeremony
#

DROP TABLE IF EXISTS `tblFlagCeremony`;

CREATE TABLE `tblFlagCeremony` (
  `flag_id` int(11) NOT NULL AUTO_INCREMENT,
  `flag_empNumber` varchar(35) NOT NULL,
  `flag_datetime` datetime NOT NULL,
  `flag_added_by` varchar(35) NOT NULL,
  `flag_added_by_ip` varchar(35) NOT NULL,
  PRIMARY KEY (`flag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblGroup
#

DROP TABLE IF EXISTS `tblGroup`;

CREATE TABLE `tblGroup` (
  `groupcode` varchar(10) NOT NULL DEFAULT '',
  `officecode` varchar(10) NOT NULL DEFAULT '',
  `groupname` varchar(255) NOT NULL DEFAULT '',
  `grouphead` varchar(50) NOT NULL DEFAULT '',
  `groupheadtitle` varchar(50) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`groupcode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblGroup1
#

DROP TABLE IF EXISTS `tblGroup1`;

CREATE TABLE `tblGroup1` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group1Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group1HeadTitle` varchar(20) NOT NULL DEFAULT '',
  `group1Secretary` varchar(20) NOT NULL DEFAULT '',
  `group1Custodian` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`group1Code`),
  UNIQUE KEY `group1Code` (`group1Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblGroup1` (`group1Code`, `group1Name`, `empNumber`, `group1HeadTitle`, `group1Secretary`, `group1Custodian`) VALUES ('LCEO', 'Municipal Government of Paete', 'EO-RQB0000', 'Municipal Mayor', '', '');
INSERT INTO `tblGroup1` (`group1Code`, `group1Name`, `empNumber`, `group1HeadTitle`, `group1Secretary`, `group1Custodian`) VALUES ('LGU-HRMO', 'Human Resources & Management Office', 'PE-BCC032392', 'HRMO III', '', '');


#
# TABLE STRUCTURE FOR: tblGroup2
#

DROP TABLE IF EXISTS `tblGroup2`;

CREATE TABLE `tblGroup2` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group2Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group2HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group2Secretary` varchar(20) NOT NULL DEFAULT '',
  `group2Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblGroup2` (`group1Code`, `group2Code`, `group2Name`, `empNumber`, `group2HeadTitle`, `group2Secretary`, `group2Custodian`) VALUES ('LCEO', 'GSO', 'General Services', 'EO-RQB0000', 'GSO Head', '', '');
INSERT INTO `tblGroup2` (`group1Code`, `group2Code`, `group2Name`, `empNumber`, `group2HeadTitle`, `group2Secretary`, `group2Custodian`) VALUES ('LCEO', 'HRMO', 'Human Resource Management Office', 'PE-BCC032392', 'HRMO III', 'PE-MGR020106', '');


#
# TABLE STRUCTURE FOR: tblGroup3
#

DROP TABLE IF EXISTS `tblGroup3`;

CREATE TABLE `tblGroup3` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group3Code` varchar(20) NOT NULL DEFAULT '',
  `group3Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group3HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group3Secretary` varchar(20) NOT NULL DEFAULT '',
  `group3Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblGroup4
#

DROP TABLE IF EXISTS `tblGroup4`;

CREATE TABLE `tblGroup4` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group3Code` varchar(20) NOT NULL DEFAULT '',
  `group4Code` varchar(20) NOT NULL DEFAULT '',
  `group4Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group4HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group4Secretary` varchar(20) NOT NULL DEFAULT '',
  `group4Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblGroup5
#

DROP TABLE IF EXISTS `tblGroup5`;

CREATE TABLE `tblGroup5` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group3Code` varchar(20) NOT NULL DEFAULT '',
  `group4Code` varchar(20) NOT NULL DEFAULT '',
  `group5Code` varchar(20) NOT NULL DEFAULT '',
  `group5Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group5HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group5Secretary` varchar(20) NOT NULL DEFAULT '',
  `group5Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblHoliday
#

DROP TABLE IF EXISTS `tblHoliday`;

CREATE TABLE `tblHoliday` (
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `holidayName` varchar(30) NOT NULL DEFAULT '',
  `holidayMonth` varchar(10) DEFAULT NULL,
  `holidayDay` char(2) DEFAULT NULL,
  `fixedHoliday` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`holidayCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('LD01', 'Labor Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('BONI', 'Bonifacio Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('RD', 'Rizal Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('BD09', 'Bataan Day', '4', '9', 'Y');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('HD', 'Holiday', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ID12', 'Independence Day', '6', '12', 'Y');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('KD06', 'Araw ng Kagitingan', '5', '29', 'Y');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('PP25', 'Edsa People Power Anniversary', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('SPH', 'Special Holiday', '7', '01', 'N');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ASD2', 'All Soul\'s Day', '11', '02', 'Y');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('RD01', 'Ramadan', '11', '26', 'Y');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NYD', 'New Year Day', '1', '1', 'Y');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('HDAM', 'Half Day AM', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TAGUIG', 'Taguig Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('MT', 'Maundy Thursday', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('HDPM', 'Half Day PM', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('GF', 'Good Friday', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('CD', 'Christmas Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NAD', 'Ninoy Aquino Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NYE', 'New Years Eve', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('SNWD', 'Special Non-Working Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('CN', 'Chinese New Year', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('LELEC', 'Local Election', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('EA', 'Eid l Adha', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TYP2014', 'Typhoon Mario', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('WS', 'Work Suspended', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ASD1', 'All Saints Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('EDF', 'Eidl Fitr', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('Lastday', 'Last Day of the Year', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('CNY', 'Chinese New Year', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TYP', 'Typhoon Glenda', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('DH', 'Declared Holiday', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('DAH', 'Declared Holiday', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('SHB', 'SENT HOME', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NHD', 'National Heroes Day', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('EDLA', 'Eidl Adha', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NLELEC', 'National and Local Elections', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('MCNO37', 'Suspended OP', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('', '', '', '', '');
INSERT INTO `tblHoliday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ADH', 'Additional Holiday', '', '', '');


#
# TABLE STRUCTURE FOR: tblHolidayYear
#

DROP TABLE IF EXISTS `tblHolidayYear`;

CREATE TABLE `tblHolidayYear` (
  `holidayId` int(11) NOT NULL AUTO_INCREMENT,
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `holidayDate` date NOT NULL DEFAULT '0000-00-00',
  `holidayTime` varchar(15) NOT NULL,
  PRIMARY KEY (`holidayId`),
  KEY `idx_holidayDate` (`holidayDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblID
#

DROP TABLE IF EXISTS `tblID`;

CREATE TABLE `tblID` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblIncome
#

DROP TABLE IF EXISTS `tblIncome`;

CREATE TABLE `tblIncome` (
  `incomeCode` varchar(15) NOT NULL DEFAULT '',
  `incomeDesc` varchar(50) NOT NULL DEFAULT '',
  `fixedSwitch` char(1) NOT NULL DEFAULT '',
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeType` varchar(20) NOT NULL DEFAULT '0',
  `recipient` varchar(150) NOT NULL DEFAULT 'ALL',
  `hidden` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('SUBSIS', 'Subsistence', 'N', '3300.00', 'Benefit', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('LONGI', 'Longevity', 'N', '0.00', 'Benefit', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('HAZARD', 'Hazard Pay', 'N', '0.00', 'Benefit', 'Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('LAUNDRY', 'Laundry', 'N', '500.00', 'Benefit', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('PENHBON', 'Productivity Enhancement Incentive', 'Y', '1000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('PERFBON', 'Performance Bonus', 'Y', '5000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('HEABON', 'Health Care Insurance Bonus', 'Y', '1000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('ENRBON', 'Enrollment Assistance', 'Y', '2000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('YECGF', 'Year-end Cash Gift', 'Y', '2500.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('MDCGF', 'Mid-year ', 'Y', '2500.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('MIBON', 'Miles Stone Bonus', 'Y', '3000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('ANBON', 'Anniversary Bonus', 'N', '0.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('PRBON', 'Productivity Incentive Bonus', 'Y', '2000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('CLOTH', 'Clothing Allowance', 'Y', '5000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('CHBON', 'Christmas Bonus', 'Y', '50000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('OT', 'Overtime', 'N', '0.00', 'Benefit', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('HON', 'Honorarium', 'N', '0.00', 'Additional', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('PERA', 'PERA', 'Y', '500.00', 'Benefit', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('RATA', 'RATA', 'N', '0.00', 'Benefit', 'Lump,Cas,Perm,', '1');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('RA', 'Representation Allowance', 'N', '0.00', 'Benefit', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('MYBON13', 'Interest Free Loan', 'N', '0.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('YEBON13', '13th Month Pay', 'N', '0.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('CNA', 'CNA', 'Y', '32000.00', 'Bonus', 'Lump,Cas,Perm,', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('MEA', 'Medical Allowance', '', '0.00', 'Bonus', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('DIF', 'Differential', '', '0.00', 'Additional', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('TA', 'Transportation Allowance', '', '0.00', 'Benefit', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('COMMA', 'Communication Allowance', '', '0.00', 'Benefit', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('EME', 'EME (Extraordinary Misc. Exp.)', '', '0.00', 'Benefit', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('Underpay', 'Underpay', '', '0.00', 'Benefit', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('RefundSikat', 'Overpay Sikat', '', '0.00', 'Benefit', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('Reffund', 'overpay consoloan', '', '0.00', 'Benefit', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('PBB', 'PBB 2016', '', '0.00', 'Bonus', 'ALL', '0');
INSERT INTO `tblIncome` (`incomeCode`, `incomeDesc`, `fixedSwitch`, `incomeAmount`, `incomeType`, `recipient`, `hidden`) VALUES ('hazard2018', 'hazard2018', '', '0.00', 'Bonus', 'ALL', '0');


#
# TABLE STRUCTURE FOR: tblLeave
#

DROP TABLE IF EXISTS `tblLeave`;

CREATE TABLE `tblLeave` (
  `leaveCode` char(3) NOT NULL DEFAULT '',
  `leaveType` varchar(50) NOT NULL DEFAULT '',
  `numOfDays` int(2) NOT NULL DEFAULT 0,
  `system` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`leaveCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('STL', 'Study Leave', '0', '1');
INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('FL', 'Forced Leave', '5', '1');
INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('SL', 'Sick Leave', '0', '1');
INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('VL', 'Vacation Leave', '0', '1');
INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('PL', 'Special Leave', '3', '1');
INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('MTL', 'Maternity Leave', '60', '1');
INSERT INTO `tblLeave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('PTL', 'Paternity Leave', '7', '1');


#
# TABLE STRUCTURE FOR: tblLocalHoliday
#

DROP TABLE IF EXISTS `tblLocalHoliday`;

CREATE TABLE `tblLocalHoliday` (
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `holidayName` varchar(30) NOT NULL DEFAULT '',
  `holidayMonth` varchar(10) NOT NULL DEFAULT '',
  `holidayDay` char(2) NOT NULL DEFAULT '',
  `holidayYear` varchar(10) NOT NULL DEFAULT '',
  `holidayDate` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblManualDTR
#

DROP TABLE IF EXISTS `tblManualDTR`;

CREATE TABLE `tblManualDTR` (
  `dtr_id` int(11) NOT NULL AUTO_INCREMENT,
  `dtr_name` varchar(50) NOT NULL,
  `dtr_ip` varchar(30) NOT NULL,
  PRIMARY KEY (`dtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblNonPermComputation
#

DROP TABLE IF EXISTS `tblNonPermComputation`;

CREATE TABLE `tblNonPermComputation` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `fk_id` int(5) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `basicSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) NOT NULL DEFAULT 0,
  `totalOTHour` int(11) NOT NULL DEFAULT 0,
  `totalOTMinute` int(11) NOT NULL DEFAULT 0,
  `totalTardyHour` int(11) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(11) NOT NULL DEFAULT 0,
  `no_workingdays` int(11) NOT NULL DEFAULT 0,
  `Remarks` text NOT NULL,
  `dayabsentamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hourOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `minuteOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tardyhouramount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tardyminuteamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `lateamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblNonPermComputationInstance
#

DROP TABLE IF EXISTS `tblNonPermComputationInstance`;

CREATE TABLE `tblNonPermComputationInstance` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `startDate` date NOT NULL DEFAULT '0000-00-00',
  `endDate` date NOT NULL DEFAULT '0000-00-00',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `pmonth` int(2) NOT NULL DEFAULT 0,
  `pyear` int(4) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0,
  `period` int(2) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblOTComputation
#

DROP TABLE IF EXISTS `tblOTComputation`;

CREATE TABLE `tblOTComputation` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `fk_id` int(5) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `basicSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `totalOTHour` int(11) NOT NULL DEFAULT 0,
  `totalOTMinute` int(11) NOT NULL DEFAULT 0,
  `hourOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `minuteOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxOTAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `creditableAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblOTComputationInstance
#

DROP TABLE IF EXISTS `tblOTComputationInstance`;

CREATE TABLE `tblOTComputationInstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startDate` date NOT NULL DEFAULT '0000-00-00',
  `endDate` date NOT NULL DEFAULT '0000-00-00',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `pmonth` int(2) NOT NULL DEFAULT 0,
  `pyear` int(4) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblOfficex
#

DROP TABLE IF EXISTS `tblOfficex`;

CREATE TABLE `tblOfficex` (
  `officecode` varchar(10) NOT NULL DEFAULT '',
  `officename` varchar(255) NOT NULL DEFAULT '',
  `officehead` varchar(50) NOT NULL DEFAULT '',
  `officeheadtitle` varchar(50) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`officecode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblOnlineDTR_HCD
#

DROP TABLE IF EXISTS `tblOnlineDTR_HCD`;

CREATE TABLE `tblOnlineDTR_HCD` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(50) NOT NULL,
  `dtrDate` date NOT NULL DEFAULT '0000-00-00',
  `fullName` varchar(255) NOT NULL,
  `temperature` float NOT NULL,
  `sex` char(1) NOT NULL DEFAULT 'M',
  `age` int(11) NOT NULL,
  `residence_contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `natureVisit` varchar(50) NOT NULL,
  `natureOb` varchar(50) NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `companyAddress` varchar(255) NOT NULL,
  `q1_1` tinyint(1) NOT NULL,
  `q1_1_txt` varchar(255) NOT NULL,
  `q1_2` tinyint(1) NOT NULL,
  `q1_3` tinyint(1) NOT NULL,
  `q1_4` tinyint(1) NOT NULL,
  `q1_5` tinyint(1) NOT NULL,
  `q1_6` tinyint(1) NOT NULL,
  `q1_7` tinyint(1) NOT NULL,
  `q1_8` tinyint(1) NOT NULL,
  `q1_9` tinyint(1) NOT NULL,
  `q1_10` tinyint(1) NOT NULL,
  `q1_11` tinyint(1) NOT NULL,
  `q1_12` tinyint(1) NOT NULL,
  `q1_13` tinyint(1) NOT NULL,
  `q1_14` tinyint(1) NOT NULL,
  `q2` tinyint(1) NOT NULL,
  `q3` tinyint(1) NOT NULL,
  `q4` tinyint(1) NOT NULL,
  `q5` tinyint(1) NOT NULL,
  `q5_txt` varchar(255) NOT NULL,
  `q6` tinyint(1) NOT NULL,
  `q6_txt` varchar(255) NOT NULL,
  `signature` varchar(50) NOT NULL,
  `signatureDate` date NOT NULL DEFAULT '0000-00-00',
  `wfh` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblOnlineDTR_HCD` (`id`, `empNumber`, `dtrDate`, `fullName`, `temperature`, `sex`, `age`, `residence_contact`, `email`, `natureVisit`, `natureOb`, `companyName`, `companyAddress`, `q1_1`, `q1_1_txt`, `q1_2`, `q1_3`, `q1_4`, `q1_5`, `q1_6`, `q1_7`, `q1_8`, `q1_9`, `q1_10`, `q1_11`, `q1_12`, `q1_13`, `q1_14`, `q2`, `q3`, `q4`, `q5`, `q5_txt`, `q6`, `q6_txt`, `signature`, `signatureDate`, `wfh`) VALUES ('5', '0100-070117', '2024-11-05', 'DELA ROSA,  FRANK ALBERT N. ', '33', 'M', '36', '09065554690', 'jancybhebz@gmail.com', 'Official', 'Employee', '', '', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '', '', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: tblOverride
#

DROP TABLE IF EXISTS `tblOverride`;

CREATE TABLE `tblOverride` (
  `override_id` int(11) NOT NULL AUTO_INCREMENT,
  `override_type` int(11) NOT NULL,
  `office_type` varchar(20) NOT NULL,
  `office` varchar(20) NOT NULL,
  `appt_status` varchar(20) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` varchar(20) NOT NULL,
  `lastupdated_date` datetime DEFAULT NULL,
  `lastupdate_dby` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`override_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblPayrolRegister
#

DROP TABLE IF EXISTS `tblPayrolRegister`;

CREATE TABLE `tblPayrolRegister` (
  `period` int(1) NOT NULL DEFAULT 0,
  `employeeAppoint` varchar(20) NOT NULL DEFAULT '',
  `pageNo` int(5) NOT NULL DEFAULT 0,
  `BASIC` decimal(10,2) NOT NULL DEFAULT 0.00,
  `BASIC2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `EARNED` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ACA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PERA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `TA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ADJUST` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RICE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSIS` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSL` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PROVI` decimal(10,2) NOT NULL DEFAULT 0.00,
  `OTHERDEDUCT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `NETPAY` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payRegMonth` int(2) NOT NULL DEFAULT 0,
  `payRegYear` year(4) NOT NULL DEFAULT 0000,
  `dateTime` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblPayrolRegisterZone
#

DROP TABLE IF EXISTS `tblPayrolRegisterZone`;

CREATE TABLE `tblPayrolRegisterZone` (
  `period` int(1) NOT NULL DEFAULT 0,
  `employeeAppoint` varchar(20) NOT NULL DEFAULT '',
  `pageNo` int(5) NOT NULL DEFAULT 0,
  `BASIC` decimal(10,2) NOT NULL DEFAULT 0.00,
  `BASIC2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `EARNED` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ACA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PERA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `TA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ADJUST` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RICE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSIS` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSL` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PROVI` decimal(10,2) NOT NULL DEFAULT 0.00,
  `OTHERDEDUCT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `NETPAY` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payRegMonth` int(2) NOT NULL DEFAULT 0,
  `payRegYear` year(4) NOT NULL DEFAULT 0000,
  `dateTime` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblPayrollGroup
#

DROP TABLE IF EXISTS `tblPayrollGroup`;

CREATE TABLE `tblPayrollGroup` (
  `payrollGroupCode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `payrollGroupName` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `projectCode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `payrollGroupOrder` int(11) NOT NULL DEFAULT 0,
  `payrollGroupRC` varchar(30) NOT NULL DEFAULT '-',
  PRIMARY KEY (`payrollGroupCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tblPayrollGroup` (`payrollGroupCode`, `payrollGroupName`, `projectCode`, `payrollGroupOrder`, `payrollGroupRC`) VALUES ('PR-Permanent', 'Permanent', '1', '1', '10000');


#
# TABLE STRUCTURE FOR: tblPayrollOfficer
#

DROP TABLE IF EXISTS `tblPayrollOfficer`;

CREATE TABLE `tblPayrollOfficer` (
  `poID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`poID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblPayrollProcess
#

DROP TABLE IF EXISTS `tblPayrollProcess`;

CREATE TABLE `tblPayrollProcess` (
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `processWith` varchar(200) NOT NULL DEFAULT '',
  `computation` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblPayrollProcess` (`appointmentCode`, `processWith`, `computation`) VALUES ('GIA', 'GIA', 'Semimonthly');
INSERT INTO `tblPayrollProcess` (`appointmentCode`, `processWith`, `computation`) VALUES ('JO', 'JO', 'Daily');
INSERT INTO `tblPayrollProcess` (`appointmentCode`, `processWith`, `computation`) VALUES ('P', 'CT,PC1,PC2,PC3,PC4,PC5,CTI,E,O,PA,SE,SU,T,P', 'Monthly');
INSERT INTO `tblPayrollProcess` (`appointmentCode`, `processWith`, `computation`) VALUES ('CONT', 'CONT', 'Daily');
INSERT INTO `tblPayrollProcess` (`appointmentCode`, `processWith`, `computation`) VALUES (' ', 'GIA-1, ', 'Semimonthly');


#
# TABLE STRUCTURE FOR: tblPhilhealthRange
#

DROP TABLE IF EXISTS `tblPhilhealthRange`;

CREATE TABLE `tblPhilhealthRange` (
  `philhealthFrom` decimal(10,2) NOT NULL DEFAULT 0.00,
  `philhealthTo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `philSalaryBase` decimal(10,2) NOT NULL DEFAULT 0.00,
  `philMonthlyContri` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('26000.00', '26999.99', '26000.00', '650.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('33000.00', '33999.99', '33000.00', '825.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('31000.00', '31999.99', '32000.00', '800.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('1.00', '7999.99', '7000.00', '175.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('9000.00', '9999.99', '9000.00', '225.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('10000.00', '10999.99', '10000.00', '250.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('11000.00', '11999.99', '11000.00', '275.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('12000.00', '12999.99', '12000.00', '300.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('13000.00', '13999.99', '13000.00', '325.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('14000.00', '14999.99', '14000.00', '350.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('15000.00', '15999.99', '15000.00', '375.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('16000.00', '16999.99', '16000.00', '400.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('17000.00', '17999.99', '17000.00', '425.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('18000.00', '18999.99', '18000.00', '450.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('19000.00', '19999.99', '19000.99', '475.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('20000.00', '20999.99', '20000.00', '500.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('21000.00', '21999.99', '21000.00', '525.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('22000.00', '22999.99', '22000.00', '550.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('23000.00', '23999.99', '23000.00', '575.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('24000.00', '24999.99', '24000.00', '600.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('25000.00', '25999.99', '25000.00', '625.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('27000.00', '27999.99', '27000.00', '675.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('28000.00', '28999.99', '28000.00', '700.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('29000.00', '29999.99', '29000.00', '725.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('30000.00', '30999.99', '30000.00', '750.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('34000.00', '34999.99', '34000.00', '850.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('8000.00', '8999.00', '8000.00', '200.00');
INSERT INTO `tblPhilhealthRange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('35000.00', '100000.00', '110000.00', '875.00');


#
# TABLE STRUCTURE FOR: tblPlantilla
#

DROP TABLE IF EXISTS `tblPlantilla`;

CREATE TABLE `tblPlantilla` (
  `plantillaID` int(11) NOT NULL AUTO_INCREMENT,
  `itemNumber` varchar(50) NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `authorizeSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `authorizeSalaryYear` decimal(15,2) NOT NULL DEFAULT 0.00,
  `salaryGrade` int(2) NOT NULL DEFAULT 0,
  `xstepNumber` int(2) NOT NULL DEFAULT 0,
  `plantillaGroupCode` varchar(20) NOT NULL DEFAULT '',
  `uniqueItemNumber` varchar(50) NOT NULL DEFAULT '',
  `plantillaItemOrder` int(5) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `agencyHead` int(1) NOT NULL DEFAULT 0,
  `rationalized` tinyint(1) NOT NULL DEFAULT 0,
  `salarySched` int(11) NOT NULL DEFAULT 0,
  `level` varchar(20) NOT NULL DEFAULT '',
  `areaCode` varchar(20) NOT NULL DEFAULT '',
  `areaType` varchar(20) NOT NULL DEFAULT '',
  `examCode` varchar(20) NOT NULL DEFAULT '',
  `examCode2` varchar(20) NOT NULL DEFAULT '',
  `educational` varchar(100) NOT NULL,
  `experience` varchar(100) NOT NULL,
  `training` varchar(100) NOT NULL,
  PRIMARY KEY (`plantillaID`),
  KEY `itemNumber` (`itemNumber`),
  KEY `positionCode` (`positionCode`),
  KEY `authorizeSalary` (`authorizeSalary`),
  KEY `authorizeSalaryYear` (`authorizeSalaryYear`),
  KEY `salaryGrade` (`salaryGrade`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblPlantilla` (`plantillaID`, `itemNumber`, `positionCode`, `authorizeSalary`, `authorizeSalaryYear`, `salaryGrade`, `xstepNumber`, `plantillaGroupCode`, `uniqueItemNumber`, `plantillaItemOrder`, `payrollGroupCode`, `agencyHead`, `rationalized`, `salarySched`, `level`, `areaCode`, `areaType`, `examCode`, `examCode2`, `educational`, `experience`, `training`) VALUES ('2', 'PAE-HR-0061', 'AO02', '0.00', '0.00', '11', '0', '01-GA', '', '0', '', '0', '0', '0', '', '060', 'R', 'CSP', '', '', '', '');
INSERT INTO `tblPlantilla` (`plantillaID`, `itemNumber`, `positionCode`, `authorizeSalary`, `authorizeSalaryYear`, `salaryGrade`, `xstepNumber`, `plantillaGroupCode`, `uniqueItemNumber`, `plantillaItemOrder`, `payrollGroupCode`, `agencyHead`, `rationalized`, `salarySched`, `level`, `areaCode`, `areaType`, `examCode`, `examCode2`, `educational`, `experience`, `training`) VALUES ('3', 'PAE-MO-007', 'ADA01', '0.00', '0.00', '7', '0', '01-GA', '', '0', '', '0', '0', '0', '', '007', 'R', 'CSCProf', '', '', '', '');


#
# TABLE STRUCTURE FOR: tblPlantillaDuties
#

DROP TABLE IF EXISTS `tblPlantillaDuties`;

CREATE TABLE `tblPlantillaDuties` (
  `plantilla_duties_index` int(11) NOT NULL AUTO_INCREMENT,
  `itemNumber` varchar(50) NOT NULL,
  `percentWork` int(5) NOT NULL,
  `itemDuties` text NOT NULL,
  `dutyNumber` int(11) NOT NULL,
  PRIMARY KEY (`plantilla_duties_index`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblPlantillaGroup
#

DROP TABLE IF EXISTS `tblPlantillaGroup`;

CREATE TABLE `tblPlantillaGroup` (
  `plantillaGroupID` int(11) NOT NULL AUTO_INCREMENT,
  `plantillaGroupCode` varchar(20) NOT NULL DEFAULT '',
  `plantillaGroupName` varchar(255) NOT NULL DEFAULT '',
  `plantillaGroupOrder` int(11) NOT NULL,
  PRIMARY KEY (`plantillaGroupID`),
  KEY `plantillaGroupID` (`plantillaGroupID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('1', '01-GA', 'GENERAL ADMINISTRATIVE SERVICE', '1');
INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('2', '02-FS', 'FINANCIAL SERVICE', '2');
INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('3', '03-PS', 'PLANNING SERVICE', '3');
INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('4', '04-AE', 'ARCHITECTURE AND ENGINEERING SERVICE', '4');
INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('5', '05-TC', 'TRANSPORTATION, COMMUNICATION AND PUBLIC UTILITIES SERVICE', '5');
INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('6', '06-CT', 'CRAFTS, TRADE AND RELATED SERVICE', '6');
INSERT INTO `tblPlantillaGroup` (`plantillaGroupID`, `plantillaGroupCode`, `plantillaGroupName`, `plantillaGroupOrder`) VALUES ('7', '07- SS', 'SOCIAL SCIENCES AND WELFARE SERVICE', '7');


#
# TABLE STRUCTURE FOR: tblPosition
#

DROP TABLE IF EXISTS `tblPosition`;

CREATE TABLE `tblPosition` (
  `positionId` int(11) NOT NULL AUTO_INCREMENT,
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `positionAbb` varchar(50) NOT NULL DEFAULT '',
  `positionDesc` varchar(70) NOT NULL DEFAULT '',
  `educational` varchar(100) NOT NULL DEFAULT '',
  `experience` varchar(100) NOT NULL DEFAULT '',
  `eligibility` varchar(100) NOT NULL DEFAULT '',
  `training` varchar(200) NOT NULL DEFAULT '',
  `level` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`positionCode`),
  UNIQUE KEY `positionId_2` (`positionId`),
  UNIQUE KEY `positionCode_2` (`positionCode`),
  KEY `positionCode` (`positionCode`),
  KEY `positionId` (`positionId`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblPosition` (`positionId`, `positionCode`, `positionAbb`, `positionDesc`, `educational`, `experience`, `eligibility`, `training`, `level`) VALUES ('35', 'AO02', 'AO-II', 'Administrative Officer II', '', '', '', '', '');
INSERT INTO `tblPosition` (`positionId`, `positionCode`, `positionAbb`, `positionDesc`, `educational`, `experience`, `eligibility`, `training`, `level`) VALUES ('36', 'AA01', 'AA-I', 'Administrative Aide I', '', '', '', '', '');
INSERT INTO `tblPosition` (`positionId`, `positionCode`, `positionAbb`, `positionDesc`, `educational`, `experience`, `eligibility`, `training`, `level`) VALUES ('37', 'ADA01', 'ADA-I', 'Administrative Assistant I', '', '', '', '', '');
INSERT INTO `tblPosition` (`positionId`, `positionCode`, `positionAbb`, `positionDesc`, `educational`, `experience`, `eligibility`, `training`, `level`) VALUES ('38', 'AA02', 'AA-II', 'Administrative Aide II ', '', '', '', '', '');
INSERT INTO `tblPosition` (`positionId`, `positionCode`, `positionAbb`, `positionDesc`, `educational`, `experience`, `eligibility`, `training`, `level`) VALUES ('39', 'AA03', 'AA-III', 'Administrative Aide III', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: tblProcess
#

DROP TABLE IF EXISTS `tblProcess`;

CREATE TABLE `tblProcess` (
  `processID` int(11) NOT NULL AUTO_INCREMENT,
  `employeeAppoint` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `processDate` date DEFAULT NULL,
  `processMonth` int(11) DEFAULT NULL,
  `processYear` int(11) DEFAULT NULL,
  `processCode` varchar(15) DEFAULT NULL,
  `payrollGroupCode` varchar(50) NOT NULL DEFAULT '',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `period` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`processID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblProcessedEmployees
#

DROP TABLE IF EXISTS `tblProcessedEmployees`;

CREATE TABLE `tblProcessedEmployees` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `surname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middlename` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` varchar(10) NOT NULL DEFAULT '',
  `nameExtension` varchar(10) NOT NULL DEFAULT '',
  `positionAbb` varchar(50) NOT NULL DEFAULT '',
  `processDate` date DEFAULT NULL,
  `processMonth` int(11) DEFAULT NULL,
  `processYear` int(11) DEFAULT NULL,
  `processCode` varchar(15) DEFAULT NULL,
  `payrollGroupCode` varchar(50) NOT NULL DEFAULT '',
  `projectCode` varchar(20) NOT NULL DEFAULT '',
  `netPayPeriod1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `netPayPeriod2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `netPay` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `officeCode` varchar(20) NOT NULL DEFAULT '',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `period` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblProcessedPayrollGroup
#

DROP TABLE IF EXISTS `tblProcessedPayrollGroup`;

CREATE TABLE `tblProcessedPayrollGroup` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `payrollGroupName` varchar(200) NOT NULL DEFAULT '',
  `projectCode` varchar(20) NOT NULL DEFAULT '',
  `payrollGroupOrder` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblProcessedProject
#

DROP TABLE IF EXISTS `tblProcessedProject`;

CREATE TABLE `tblProcessedProject` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `projectCode` varchar(100) NOT NULL DEFAULT '',
  `projectDesc` text NOT NULL,
  `projectOrder` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblProject
#

DROP TABLE IF EXISTS `tblProject`;

CREATE TABLE `tblProject` (
  `projectId` int(11) NOT NULL AUTO_INCREMENT,
  `projectCode` varchar(100) NOT NULL DEFAULT '',
  `projectDesc` text NOT NULL,
  `projectOrder` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`projectId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblProject` (`projectId`, `projectCode`, `projectDesc`, `projectOrder`) VALUES ('1', 'LCEO-PS1', 'EXECUTIVE PERSONAL SERVICES', '1');


#
# TABLE STRUCTURE FOR: tblRATA
#

DROP TABLE IF EXISTS `tblRATA`;

CREATE TABLE `tblRATA` (
  `RATACode` char(3) NOT NULL DEFAULT '',
  `RATAAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`RATACode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblReportType
#

DROP TABLE IF EXISTS `tblReportType`;

CREATE TABLE `tblReportType` (
  `reportCode` varchar(10) NOT NULL DEFAULT '',
  `reportDesc` text NOT NULL,
  `reportType` varchar(255) NOT NULL DEFAULT '',
  `reportModule` varchar(4) NOT NULL DEFAULT '',
  `numberOfSignatory` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`reportCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblReports
#

DROP TABLE IF EXISTS `tblReports`;

CREATE TABLE `tblReports` (
  `reportCode` varchar(10) NOT NULL DEFAULT '',
  `reportDesc` text NOT NULL,
  `reportType` varchar(255) NOT NULL DEFAULT '',
  `reportModule` varchar(4) NOT NULL DEFAULT '',
  `reportStatus` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`reportCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PR', 'Payroll Register', 'Monthly', '2', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PS', 'Pay Slip', 'Monthly', '2', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('MCBR', 'MC Benefit Register for DOST Employees', 'Monthly', '2', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('DR', 'Deduction Register for DOST Employees', 'Monthly', '2', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('FR', 'Funding Requirements', 'Monthly', '2', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('AR', 'Acceptance of Resignation', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ARO', 'Accumulated Report By Office', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('AFLF', 'Application for Leave Form', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ADR', 'Assumption of Duties and Responsibilities', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('DTR', 'Daily Time Record', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CDR', 'Certificate of Duties and Responsibilities', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PDS', 'Personal Data Sheet', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CEC', 'Certificate of Employees Compensation', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CNAC', 'Certificate of No Administrative Charge', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CNACLP', 'Certificate of No Administrative Charge (for legal purposes)', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CNACL', 'Certification of Service for Loyalty Award', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CACQ', 'Comparative Analysis of Candidates\' Qualifications', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEA', 'List of Educational Attainment', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEAGE', 'List of Employees by Age', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEDH', 'List of Employees by Date Hired', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEDB', 'List of Employees by Date of Birth', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEEA', 'List of Employees by Educational Attainment', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEG', 'List of Employees by Gender', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LELS', 'List of Employees by Length of Service', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LESG', 'List of Employees by Salary Grade', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ALC', 'Accumulated Leave Credits', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('SR', 'Service Record', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ROT', 'Report on Tardiness', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ROTUA', 'Report on Tardiness, Undertime and Absences', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('TOS', 'Trainings of Staff', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LET', 'List of Employees\' Training', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('EFDS', 'Employees First Day of Service', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('EP', 'Employees Profile', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LESGA', 'List of Employees by Salary Grade (Alphabetical)', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEDBA', 'List of Employees\' Date of Birth (Alphabetical)', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LR', 'List of Retirees', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LTP', 'List of Training Programs', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LVP', 'List of Vacant Position(s)', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LOYR', 'Loyalty Report', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('OB', 'Official Business Slip', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PSK', 'Panunumpa sa Katungkulan', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PP', 'Plantilla of Personnel', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('EAS', 'Employees Attendance Summary', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('AAR', 'Report of Attendance and Accumulated Leave Credits', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LB', 'Leave Balance Form', '', '1', '1');
INSERT INTO `tblReports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('SR67', 'Service Record (CS Form No. 67)', '', '1', '1');


#
# TABLE STRUCTURE FOR: tblRequestApplicant
#

DROP TABLE IF EXISTS `tblRequestApplicant`;

CREATE TABLE `tblRequestApplicant` (
  `AppliCode` varchar(100) NOT NULL DEFAULT '',
  `Applicant` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`AppliCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('EXECUTIVE', 'Employees under Executive Office');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('SERVICE', 'Employees under Service');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('DIVISION', 'Employees under Division');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('SECTION', 'Employees under Section');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('SECTIONHEAD', 'Section Head');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('DIVISIONHEAD', 'Division Head');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('SERVICEHEAD', 'Service Head');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('ALLEMP', 'All Employees');
INSERT INTO `tblRequestApplicant` (`AppliCode`, `Applicant`) VALUES ('EXEHEAD', 'Executive Office Head');


#
# TABLE STRUCTURE FOR: tblRequestFlow
#

DROP TABLE IF EXISTS `tblRequestFlow`;

CREATE TABLE `tblRequestFlow` (
  `reqID` int(2) NOT NULL AUTO_INCREMENT,
  `RequestType` varchar(100) NOT NULL DEFAULT '',
  `Applicant` varchar(100) NOT NULL DEFAULT '',
  `Signatory1` varchar(100) NOT NULL DEFAULT '',
  `Signatory2` varchar(100) NOT NULL DEFAULT '',
  `Signatory3` varchar(100) NOT NULL DEFAULT '',
  `SignatoryFin` varchar(100) NOT NULL DEFAULT '',
  `isactive` int(11) NOT NULL,
  PRIMARY KEY (`reqID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblRequestFlow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('1', 'TO', 'ALLEMP;PILOILO;', 'RECOMMENDED;;CADOF-96-2014', 'APPROVED;;OSEC-DENRB-CENRO-149', 'APPROVED;;PENRO-33-1998', 'CERTIFIED;;PENRO-32-1998', '0');
INSERT INTO `tblRequestFlow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('2', 'TO', 'ALLEMP;PILOILO;INFOSA2-98-2014', 'RECOMMENDED;;CADOF-96-2014', 'APPROVED;;OSEC-DENRB-CENRO-149', 'APPROVED;;PENRO-33-1998', 'CERTIFIED;;PENRO-32-1998', '0');


#
# TABLE STRUCTURE FOR: tblRequestSignatory
#

DROP TABLE IF EXISTS `tblRequestSignatory`;

CREATE TABLE `tblRequestSignatory` (
  `SignCode` varchar(50) NOT NULL DEFAULT '',
  `Signatory` varchar(100) NOT NULL DEFAULT '',
  `SignHead` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`SignCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblRequestSignatoryAction
#

DROP TABLE IF EXISTS `tblRequestSignatoryAction`;

CREATE TABLE `tblRequestSignatoryAction` (
  `ID` int(2) NOT NULL AUTO_INCREMENT,
  `ActionDesc` varchar(50) NOT NULL DEFAULT '',
  `ActionCode` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblRequestSignatoryAction` (`ID`, `ActionDesc`, `ActionCode`) VALUES ('1', 'CERTIFY', 'CERTIFIED');
INSERT INTO `tblRequestSignatoryAction` (`ID`, `ActionDesc`, `ActionCode`) VALUES ('2', 'APPROVE', 'APPROVED');
INSERT INTO `tblRequestSignatoryAction` (`ID`, `ActionDesc`, `ActionCode`) VALUES ('3', 'RECOMMEND', 'RECOMMENDED');


#
# TABLE STRUCTURE FOR: tblRequestType
#

DROP TABLE IF EXISTS `tblRequestType`;

CREATE TABLE `tblRequestType` (
  `requestCode` varchar(20) NOT NULL DEFAULT '',
  `requestDesc` text NOT NULL,
  PRIMARY KEY (`requestCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('Leave', 'Leave');
INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('OB', 'Official Business');
INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('201', 'Update PDS');
INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('Report', 'Reports');
INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('Trainings', 'Seminars / Trainings');
INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('TO', 'Travel Order');
INSERT INTO `tblRequestType` (`requestCode`, `requestDesc`) VALUES ('DTR', 'DTR Update Request');


#
# TABLE STRUCTURE FOR: tblSalarySched
#

DROP TABLE IF EXISTS `tblSalarySched`;

CREATE TABLE `tblSalarySched` (
  `stepNumber` int(2) NOT NULL DEFAULT 0,
  `salaryGradeNumber` int(2) NOT NULL DEFAULT 0,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `version` varchar(11) NOT NULL DEFAULT '1',
  KEY `stepNumber` (`stepNumber`),
  KEY `salaryGradeNumber` (`salaryGradeNumber`),
  KEY `actualSalary` (`actualSalary`),
  KEY `version` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '9982.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '10072.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '10165.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '10258.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '10352.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '10453.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '10543.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '10640.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '10667.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '10761.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '10856.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '10952.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '11049.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '11147.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '11245.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '11345.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '11387.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '11488.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '11589.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '11691.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '11795.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '11899.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '12110.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '12004.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '12155.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '12262.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '12371.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '12480.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '12591.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '12702.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '12814.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '12927.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '12975.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '13117.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '13206.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '13322.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '13440.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '13559.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '13679.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '13799.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '13851.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '13973.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '14096.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '14221.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '14347.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '14474.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '14602.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '14731.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '14785.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '14916.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '15048.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '15181.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '15315.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '15450.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '15587.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '15725.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '15818.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '15969.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '16121.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '16275.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '16430.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '16586.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '16744.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '16903.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '16986.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '17142.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '17299.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '17458.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '17618.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '17780.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '17943.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '18108.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '18217.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '18385.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '18553.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '18724.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '18896.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '19095.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '19244.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '19421.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '19620.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '19853.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '20088.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '20326.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '20567.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '20811.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '21058.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '21307.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '21387.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '21626.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '21868.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '22113.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '22361.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '22611.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '22864.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '23120.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '23257.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '23517.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '23780.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '24047.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '24315.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '24587.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '24863.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '25141.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '25290.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '25573.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '25859.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '26149.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '26441.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '26737.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '27036.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '27339.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '27565.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '27887.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '28214.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '28544.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '28877.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '29214.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '29557.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '29902.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '30044.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '30396.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '30751.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '31111.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '31474.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '31843.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '32215.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '32592.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '32747.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '33131.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '33518.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '33909.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '34306.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '34707.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '35113.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '35524.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '35693.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '36111.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '36532.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '36960.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '37392.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '37829.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '38272.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '38719.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '39151.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '39685.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '40227.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '40776.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '41333.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '41898.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '42470.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '43051.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '43250.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '43841.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '44440.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '45047.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '45662.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '46285.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '46917.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '47559.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '47779.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '48432.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '49094.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '49764.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '50443.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '51132.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '51831.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '52539.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '52783.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '53503.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '54234.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '54975.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '55726.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '56487.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '57258.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '58040.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '58310.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '59106.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '59913.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '60732.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '61561.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '62402.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '63255.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '64118.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '64416.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '65296.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '66187.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '67092.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '68008.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '68937.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '69878.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '70832.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '71476.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '72452.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '73441.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '74444.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '75461.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '76491.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '77536.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '78595.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '78960.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '80039.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '81132.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '82240.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '83363.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '84502.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '85657.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '86825.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '87229.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '88420.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '89628.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '90852.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '92093.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '93351.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '94625.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '95925.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '96363.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '97679.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '99013.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '100366.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '101736.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '103126.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '104534.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '105962.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '106454.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '107908.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '109382.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '110875.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '112390.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '113925.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '115481.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '117058.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '117601.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '119208.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '120836.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '122486.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '124159.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '125855.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '127855.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '129316.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '152325.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '154649.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '157008.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '159404.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '161836.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '164305.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '166812.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '169357.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '177929.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '180700.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '33', '222278.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '215804.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '198255.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '195215.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '192221.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '189274.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '186372.00', '5');
INSERT INTO `tblSalarySched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '183513.00', '5');


#
# TABLE STRUCTURE FOR: tblSalarySchedVersion
#

DROP TABLE IF EXISTS `tblSalarySchedVersion`;

CREATE TABLE `tblSalarySchedVersion` (
  `version` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(50) NOT NULL DEFAULT '',
  `effectivity` date NOT NULL DEFAULT current_timestamp(),
  `unused` tinyint(1) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblSalarySchedVersion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('5', 'LBC 149-24 A-6 (Fourth Tranche)', 'LBC 149-24 A-6 (Fourth Tranche)', '2017-01-01', '0', '1');


#
# TABLE STRUCTURE FOR: tblScheduler_Logs
#

DROP TABLE IF EXISTS `tblScheduler_Logs`;

CREATE TABLE `tblScheduler_Logs` (
  `id` int(10) NOT NULL DEFAULT 0,
  `script` varchar(130) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `output` text CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `execution_time` varchar(130) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblScholarship
#

DROP TABLE IF EXISTS `tblScholarship`;

CREATE TABLE `tblScholarship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('1', 'DOST-SEI Scholarship');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('2', 'MalacaÃ±ang Scholar');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('6', 'ACTC Scholarship Develpoment Program');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('4', 'DOST-HRDP');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('5', 'FPJ Scholarship Program');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('7', 'DOST Scholarship Program');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('8', 'JLP Scholar');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('9', 'DOST-ASTHRDP');
INSERT INTO `tblScholarship` (`id`, `description`) VALUES ('10', 'CHED Scholarship');


#
# TABLE STRUCTURE FOR: tblSecurityCode
#

DROP TABLE IF EXISTS `tblSecurityCode`;

CREATE TABLE `tblSecurityCode` (
  `securityID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `securityQuestion` varchar(30) NOT NULL DEFAULT '',
  `securityAnswer` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`securityID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblSecurityQuestion
#

DROP TABLE IF EXISTS `tblSecurityQuestion`;

CREATE TABLE `tblSecurityQuestion` (
  `securityCode` int(11) NOT NULL AUTO_INCREMENT,
  `securityQuestion` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`securityCode`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('1', 'What is the first name of your favorite uncle?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('2', 'Where did you meet your spouse?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('3', 'What is your oldest cousin\'s name?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('4', 'What is your youngest child\'s nickname?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('5', 'What is the first name of your oldest niece?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('6', 'What is the first name of your oldest nephew?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('7', 'What is the first name of favourite aunt?');
INSERT INTO `tblSecurityQuestion` (`securityCode`, `securityQuestion`) VALUES ('8', 'Where did you spent your honeymoon?');


#
# TABLE STRUCTURE FOR: tblSeparationCause
#

DROP TABLE IF EXISTS `tblSeparationCause`;

CREATE TABLE `tblSeparationCause` (
  `separationCause` varchar(50) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`separationCause`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('AWOL', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Deceased', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Drop-from-the-Rolls', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('End-of-Contract', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Rationalization-Plan', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Resigned', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Retired', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Terminated', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Transferred', '1');
INSERT INTO `tblSeparationCause` (`separationCause`, `system`) VALUES ('Permanent', '0');


#
# TABLE STRUCTURE FOR: tblServiceCode
#

DROP TABLE IF EXISTS `tblServiceCode`;

CREATE TABLE `tblServiceCode` (
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  `serviceDesc` varchar(50) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`serviceCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('GOV', 'Government', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('PRIV', 'Private', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('SPRIV', 'Semi-Private', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('LGU', 'Local Government Unit', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('GOCC', 'Government Owned and Controlled Corporation', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('SGOV', 'Semi-Government', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('GPRJ', 'Government Project', '1');
INSERT INTO `tblServiceCode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('SUC', 'State Universities and Colleges', '0');


#
# TABLE STRUCTURE FOR: tblServiceRecord
#

DROP TABLE IF EXISTS `tblServiceRecord`;

CREATE TABLE `tblServiceRecord` (
  `serviceRecID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `serviceFromDate` date NOT NULL DEFAULT '0000-00-00',
  `serviceToDate` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `tmpServiceToDate` varchar(25) NOT NULL DEFAULT 'Present',
  `positionCode` varchar(10) NOT NULL DEFAULT '',
  `positionDesc` text NOT NULL,
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `salaryPer` varchar(10) NOT NULL DEFAULT '',
  `stationAgency` varchar(50) NOT NULL DEFAULT '',
  `salaryGrade` varchar(10) DEFAULT '',
  `appointmentCode` varchar(50) NOT NULL DEFAULT '',
  `governService` varchar(5) DEFAULT NULL,
  `NCCRA` varchar(20) DEFAULT NULL,
  `separationCause` varchar(20) DEFAULT NULL,
  `separationDate` varchar(10) DEFAULT NULL,
  `branch` varchar(50) DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT '',
  `remarks` varchar(50) NOT NULL DEFAULT '',
  `lwop` int(3) NOT NULL DEFAULT 0,
  `processor` varchar(50) NOT NULL,
  `signee` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceRecID`),
  KEY `empNumber` (`empNumber`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblSignatory
#

DROP TABLE IF EXISTS `tblSignatory`;

CREATE TABLE `tblSignatory` (
  `signatoryId` int(11) NOT NULL AUTO_INCREMENT,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `signatory` text NOT NULL,
  `signatoryPosition` text NOT NULL,
  `signatoryOrder` int(11) NOT NULL DEFAULT 0,
  `sig_module` tinyint(4) NOT NULL,
  PRIMARY KEY (`signatoryId`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblSignatory` (`signatoryId`, `payrollGroupCode`, `signatory`, `signatoryPosition`, `signatoryOrder`, `sig_module`) VALUES ('1', '', 'Livino B. Duran', 'Regional Executive Director', '0', '1');
INSERT INTO `tblSignatory` (`signatoryId`, `payrollGroupCode`, `signatory`, `signatoryPosition`, `signatoryOrder`, `sig_module`) VALUES ('2', '', 'Raul L. Lorilla', 'Assistant Regional Director for Technical Services', '0', '1');
INSERT INTO `tblSignatory` (`signatoryId`, `payrollGroupCode`, `signatory`, `signatoryPosition`, `signatoryOrder`, `sig_module`) VALUES ('3', '', 'Atty. Noel C. Empleo', 'Assistant Regional Director for Management Services', '0', '1');
INSERT INTO `tblSignatory` (`signatoryId`, `payrollGroupCode`, `signatory`, `signatoryPosition`, `signatoryOrder`, `sig_module`) VALUES ('4', '', 'Ernest C. Federiso', 'Chief, Administrative Division', '0', '1');
INSERT INTO `tblSignatory` (`signatoryId`, `payrollGroupCode`, `signatory`, `signatoryPosition`, `signatoryOrder`, `sig_module`) VALUES ('5', '', 'Merlene B. Aborka', 'PENRO Aklan', '0', '1');
INSERT INTO `tblSignatory` (`signatoryId`, `payrollGroupCode`, `signatory`, `signatoryPosition`, `signatoryOrder`, `sig_module`) VALUES ('6', '', 'Salvador C. Manglinong Jr.', 'OIC - PENR Officer', '0', '1');


#
# TABLE STRUCTURE FOR: tblSignatory_edited
#

DROP TABLE IF EXISTS `tblSignatory_edited`;

CREATE TABLE `tblSignatory_edited` (
  `signatoryId` int(11) NOT NULL AUTO_INCREMENT,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `signatory` text NOT NULL,
  `signatoryPosition` text NOT NULL,
  `signatoryOrder` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`signatoryId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblSpecificLeave
#

DROP TABLE IF EXISTS `tblSpecificLeave`;

CREATE TABLE `tblSpecificLeave` (
  `leaveCode` char(3) NOT NULL DEFAULT '',
  `specifyLeave` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Personal Milestone');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Parental Obligation');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Filial Obligation');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('VL', 'Abroad');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Domestic Emergency');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Personal Transaction');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('SL', 'Out-patient');
INSERT INTO `tblSpecificLeave` (`leaveCode`, `specifyLeave`) VALUES ('VL', 'PERSONAL TRANSACTION');


#
# TABLE STRUCTURE FOR: tblTaxDetails
#

DROP TABLE IF EXISTS `tblTaxDetails`;

CREATE TABLE `tblTaxDetails` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `otherDependent` varchar(50) DEFAULT NULL,
  `dRelationship` varchar(15) DEFAULT NULL,
  `dBirthDate` date DEFAULT NULL,
  `pTin` varchar(20) DEFAULT NULL,
  `pAddress` text NOT NULL,
  `pEmployer` varchar(50) DEFAULT NULL,
  `pZipCode` varchar(6) DEFAULT NULL,
  `pTin1` varchar(20) DEFAULT NULL,
  `pAddress1` text NOT NULL,
  `pEmployer1` varchar(50) DEFAULT NULL,
  `pZipCode1` varchar(6) DEFAULT NULL,
  `pTin2` varchar(20) DEFAULT NULL,
  `pAddress2` text DEFAULT NULL,
  `pEmployer2` varchar(50) NOT NULL DEFAULT '',
  `pZipCode2` varchar(6) NOT NULL DEFAULT '',
  `pTaxComp` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pTaxWheld` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblTaxExempt
#

DROP TABLE IF EXISTS `tblTaxExempt`;

CREATE TABLE `tblTaxExempt` (
  `taxStatus` varchar(20) NOT NULL DEFAULT '',
  `exemptAmount` float(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`taxStatus`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblTaxExempt` (`taxStatus`, `exemptAmount`) VALUES ('Married', '50000.00');
INSERT INTO `tblTaxExempt` (`taxStatus`, `exemptAmount`) VALUES ('Head', '50000.00');
INSERT INTO `tblTaxExempt` (`taxStatus`, `exemptAmount`) VALUES ('Single', '50000.00');


#
# TABLE STRUCTURE FOR: tblTaxRange
#

DROP TABLE IF EXISTS `tblTaxRange`;

CREATE TABLE `tblTaxRange` (
  `taxableFrom` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxableTo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxFactor` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxBase` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxDeduct` decimal(10,2) NOT NULL DEFAULT 0.00,
  `orderNumber` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tblTaxRange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('140000.00', '250000.00', '0.25', '140000.00', '22500.00', '4');
INSERT INTO `tblTaxRange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('500000.00', '2000000.00', '0.32', '500000.00', '125000.00', '6');
INSERT INTO `tblTaxRange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('250000.00', '500000.00', '0.30', '250000.00', '50000.00', '5');
INSERT INTO `tblTaxRange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('70000.00', '140000.00', '0.20', '70000.00', '8500.00', '3');
INSERT INTO `tblTaxRange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('10000.00', '30000.00', '0.10', '10000.00', '500.00', '1');
INSERT INTO `tblTaxRange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('30000.00', '70000.00', '0.15', '30000.00', '2500.00', '2');


#
# TABLE STRUCTURE FOR: tblTempNotification
#

DROP TABLE IF EXISTS `tblTempNotification`;

CREATE TABLE `tblTempNotification` (
  `tmpDate` date NOT NULL DEFAULT '0000-00-00',
  `tmpStepIncrement` int(11) NOT NULL DEFAULT 0,
  `tmpBirthday` int(11) NOT NULL DEFAULT 0,
  `tmpEmployeesMovement` int(11) NOT NULL DEFAULT 0,
  `tmpVacantPosition` int(11) NOT NULL DEFAULT 0,
  `tmpRetiree` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblWorkZone
#

DROP TABLE IF EXISTS `tblWorkZone`;

CREATE TABLE `tblWorkZone` (
  `currentWorkZone` varchar(20) DEFAULT NULL,
  `currentchiefworkzone` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='stores the current working zone. 201 display depend on which';

INSERT INTO `tblWorkZone` (`currentWorkZone`, `currentchiefworkzone`) VALUES ('Home', 'Laptop');


#
# TABLE STRUCTURE FOR: tblZone
#

DROP TABLE IF EXISTS `tblZone`;

CREATE TABLE `tblZone` (
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `zonedesc` varchar(255) NOT NULL DEFAULT '',
  `serverName` varchar(30) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `databaseName` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblcompensatory_timeoff
#

DROP TABLE IF EXISTS `tblcompensatory_timeoff`;

CREATE TABLE `tblcompensatory_timeoff` (
  `cto_id` int(11) NOT NULL AUTO_INCREMENT,
  `empnumber` varchar(20) NOT NULL,
  `dtr_id` int(11) NOT NULL,
  `cto_date` date DEFAULT NULL,
  `cto_timefrom` time DEFAULT NULL,
  `cto_timeto` time DEFAULT NULL,
  `process_by` varchar(20) DEFAULT NULL,
  `process_date` datetime DEFAULT NULL,
  `process_ip` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblraffle
#

DROP TABLE IF EXISTS `tblraffle`;

CREATE TABLE `tblraffle` (
  `name` text NOT NULL,
  `amount` double(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tempEmpDeduct
#

DROP TABLE IF EXISTS `tempEmpDeduct`;

CREATE TABLE `tempEmpDeduct` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductionDesc` varchar(30) NOT NULL DEFAULT '',
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tempEmpIncome
#

DROP TABLE IF EXISTS `tempEmpIncome`;

CREATE TABLE `tempEmpIncome` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeDesc` varchar(30) NOT NULL DEFAULT '',
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xbacktblEmpPersonal
#

DROP TABLE IF EXISTS `xbacktblEmpPersonal`;

CREATE TABLE `xbacktblEmpPersonal` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `surname` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middlename` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` varchar(10) DEFAULT NULL,
  `nameExtension` varchar(10) DEFAULT '',
  `sex` char(1) NOT NULL DEFAULT 'M',
  `civilStatus` varchar(20) NOT NULL DEFAULT 'Single',
  `spouse` varchar(80) NOT NULL DEFAULT '',
  `spouseWork` varchar(50) NOT NULL DEFAULT '',
  `spouseBusName` varchar(70) NOT NULL DEFAULT '',
  `spouseBusAddress` text DEFAULT NULL,
  `spouseTelephone` varchar(10) DEFAULT NULL,
  `tin` varchar(20) DEFAULT NULL,
  `citizenship` varchar(10) NOT NULL DEFAULT '',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `birthPlace` varchar(80) NOT NULL DEFAULT '',
  `bloodType` varchar(6) DEFAULT NULL,
  `height` decimal(5,2) NOT NULL DEFAULT 0.00,
  `weight` decimal(5,2) NOT NULL DEFAULT 0.00,
  `residentialAddress` text DEFAULT NULL,
  `zipCode1` int(4) DEFAULT NULL,
  `telephone1` varchar(20) DEFAULT NULL,
  `permanentAddress` text DEFAULT NULL,
  `zipCode2` int(4) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `fatherName` varchar(80) NOT NULL DEFAULT '',
  `motherName` varchar(80) NOT NULL DEFAULT '',
  `parentAddress` text DEFAULT NULL,
  `skills` text NOT NULL,
  `nadr` text DEFAULT NULL,
  `miao` text DEFAULT NULL,
  `relatedThird` char(1) DEFAULT NULL,
  `relatedDegreeParticularsThird` text DEFAULT NULL,
  `relatedFourth` char(1) DEFAULT NULL,
  `relatedDegreeParticulars` text DEFAULT NULL,
  `violateLaw` char(1) DEFAULT NULL,
  `violateLawParticulars` text DEFAULT NULL,
  `formallyCharged` char(1) DEFAULT NULL,
  `formallyChargedParticulars` text DEFAULT NULL,
  `adminCase` char(1) DEFAULT NULL,
  `adminCaseParticulars` text DEFAULT NULL,
  `forcedResign` char(1) DEFAULT NULL,
  `forcedResignParticulars` text DEFAULT NULL,
  `candidate` char(1) DEFAULT NULL,
  `candidateParticulars` text DEFAULT NULL,
  `indigenous` char(1) DEFAULT NULL,
  `indigenousParticulars` text DEFAULT NULL,
  `disabled` char(1) DEFAULT NULL,
  `disabledParticulars` text DEFAULT NULL,
  `soloParent` char(1) DEFAULT NULL,
  `soloParentParticulars` text DEFAULT NULL,
  `signature` varchar(50) NOT NULL DEFAULT '',
  `dateAccomplished` date DEFAULT '0000-00-00',
  `comTaxNumber` varchar(10) NOT NULL DEFAULT '',
  `issuedAt` varchar(50) DEFAULT NULL,
  `issuedOn` date NOT NULL DEFAULT '0000-00-00',
  `gsisNumber` varchar(25) DEFAULT NULL,
  `philHealthNumber` varchar(14) DEFAULT NULL,
  `sssNumber` varchar(20) DEFAULT '',
  `pagibigNumber` varchar(14) DEFAULT NULL,
  `AccountNum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`empNumber`),
  KEY `Emp_No` (`empNumber`),
  FULLTEXT KEY `surname` (`surname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xbacktblEmpPosition
#

DROP TABLE IF EXISTS `xbacktblEmpPosition`;

CREATE TABLE `xbacktblEmpPosition` (
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `statusOfAppointment` varchar(50) NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  `plantillaGroupCode` varchar(10) NOT NULL DEFAULT '',
  `divisionCode` varchar(20) NOT NULL DEFAULT '',
  `sectionCode` varchar(20) NOT NULL DEFAULT '',
  `taxStatCode` varchar(20) NOT NULL DEFAULT '',
  `itemNumber` varchar(50) NOT NULL DEFAULT '',
  `salaryGradeNumber` int(2) NOT NULL DEFAULT 0,
  `authorizeSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `contractEndDate` date DEFAULT '0000-00-00',
  `effectiveDate` date NOT NULL DEFAULT '0000-00-00',
  `positionDate` date NOT NULL DEFAULT '0000-00-00',
  `longevityDate` date NOT NULL DEFAULT '0000-00-00',
  `longevityGap` decimal(4,2) DEFAULT 0.00,
  `firstDayAgency` date NOT NULL DEFAULT '0000-00-00',
  `firstDayGov` date NOT NULL DEFAULT '0000-00-00',
  `assignPlace` varchar(50) DEFAULT NULL,
  `stepNumber` int(2) NOT NULL DEFAULT 0,
  `dateIncremented` date NOT NULL DEFAULT '0000-00-00',
  `personnelAction` varchar(20) NOT NULL DEFAULT '',
  `employmentBasis` varchar(20) NOT NULL DEFAULT 'Fulltime',
  `categoryService` varchar(20) NOT NULL DEFAULT 'Career',
  `nature` varchar(20) NOT NULL DEFAULT 'Support',
  `hpFactor` decimal(2,0) NOT NULL DEFAULT 0,
  `longiFactor` decimal(2,0) DEFAULT 0,
  `payrollSwitch` char(1) NOT NULL DEFAULT 'N',
  `schemeCode` varchar(20) NOT NULL DEFAULT 'GEN',
  `itwSwitch` char(1) NOT NULL DEFAULT 'Y',
  `lifeRetSwitch` char(1) NOT NULL DEFAULT 'Y',
  `pagibigSwitch` char(1) NOT NULL DEFAULT 'Y',
  `philhealthSwitch` char(1) NOT NULL DEFAULT 'Y',
  `providentSwitch` char(1) NOT NULL DEFAULT '',
  `premiumAidSwitch` char(1) NOT NULL DEFAULT 'Y',
  `dtrSwitch` char(1) NOT NULL DEFAULT 'Y',
  `mcSwitch` char(1) NOT NULL DEFAULT 'Y',
  `hazardSwitch` char(1) NOT NULL DEFAULT 'Y',
  `longevitySwitch` char(1) NOT NULL DEFAULT 'Y',
  `PERASwitch` char(1) NOT NULL DEFAULT 'Y',
  `ADCOMSwitch` char(1) NOT NULL DEFAULT 'Y',
  `dependents` decimal(2,0) NOT NULL DEFAULT 0,
  `healthProvider` char(1) NOT NULL DEFAULT 'N',
  `tmpStepNumber` int(2) NOT NULL DEFAULT 0,
  `tmpActualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tmpDateIncremented` date NOT NULL DEFAULT '0000-00-00',
  `tmpPositionDate` date NOT NULL DEFAULT '0000-00-00',
  `regularDedSwitch` char(1) NOT NULL DEFAULT '',
  `contriDedSwitch` char(1) NOT NULL DEFAULT '',
  `loanDedSwitch` char(1) NOT NULL DEFAULT '',
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `riceSwitch` char(1) NOT NULL DEFAULT '',
  `detailedfrom` char(1) NOT NULL DEFAULT '',
  `departmentcode` varchar(5) NOT NULL DEFAULT '',
  `groupCode` varchar(10) DEFAULT NULL,
  `firefighter` char(1) NOT NULL DEFAULT 'N',
  `security` char(1) NOT NULL DEFAULT 'N',
  `uniqueItemNumber` varchar(50) NOT NULL DEFAULT '',
  `physician` char(1) DEFAULT 'N',
  `officecode` varchar(20) NOT NULL DEFAULT '',
  `service` varchar(50) NOT NULL DEFAULT '',
  `payrollGroupCode` varchar(50) DEFAULT NULL,
  `taxAmount` decimal(10,2) DEFAULT 0.00,
  `hpTax` decimal(10,2) DEFAULT NULL,
  `lpTax` decimal(10,2) DEFAULT NULL,
  `laundrySwitch` char(1) NOT NULL DEFAULT 'Y',
  `addPAGIBIGContri` decimal(10,2) NOT NULL DEFAULT 0.00,
  `includeSecondment` int(1) NOT NULL DEFAULT 0,
  `group1` varchar(20) NOT NULL DEFAULT '',
  `group2` varchar(20) NOT NULL DEFAULT '',
  `group3` varchar(20) NOT NULL DEFAULT '',
  `group4` varchar(20) NOT NULL DEFAULT '',
  `group5` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`empNumber`),
  KEY `AppointmentCode` (`appointmentCode`),
  KEY `DivisionCode` (`divisionCode`),
  KEY `Emp_No` (`empNumber`),
  KEY `PositionCode` (`positionCode`),
  KEY `SectionCode` (`sectionCode`),
  KEY `ServiceCode` (`serviceCode`),
  KEY `TaxStatusCode` (`taxStatCode`),
  FULLTEXT KEY `assignPlace` (`assignPlace`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xesessions
#

DROP TABLE IF EXISTS `xesessions`;

CREATE TABLE `xesessions` (
  `sess_id` varchar(32) NOT NULL DEFAULT '',
  `sess_sec_level` tinyint(3) unsigned NOT NULL DEFAULT 255,
  `sess_created` int(11) NOT NULL DEFAULT 0,
  `sess_expiry` int(11) NOT NULL DEFAULT 0,
  `sess_timeout` int(11) NOT NULL DEFAULT 0,
  `sess_locked` tinyint(1) NOT NULL DEFAULT 1,
  `sess_value` text NOT NULL,
  `sess_enc_iv` varchar(32) NOT NULL DEFAULT '',
  `sess_sec_id` varchar(32) NOT NULL DEFAULT '',
  `sess_trace` tinytext NOT NULL,
  PRIMARY KEY (`sess_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='This table stores PHP session data';

#
# TABLE STRUCTURE FOR: xphpjobscheduler
#

DROP TABLE IF EXISTS `xphpjobscheduler`;

CREATE TABLE `xphpjobscheduler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scriptpath` varchar(255) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `time_interval` int(11) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT 0,
  `time_last_fired` int(11) DEFAULT NULL,
  `run_only_once` tinyint(1) NOT NULL DEFAULT 0,
  `currently_running` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fire_time` (`fire_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xphpjobscheduler_logs
#

DROP TABLE IF EXISTS `xphpjobscheduler_logs`;

CREATE TABLE `xphpjobscheduler_logs` (
  `id` int(11) NOT NULL DEFAULT 0,
  `script` varchar(128) DEFAULT NULL,
  `output` text DEFAULT NULL,
  `execution_time` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblBackUpScheduler
#

DROP TABLE IF EXISTS `xtblBackUpScheduler`;

CREATE TABLE `xtblBackUpScheduler` (
  `id` int(10) NOT NULL DEFAULT 0,
  `time_interval` int(10) DEFAULT NULL,
  `fire_time` int(10) NOT NULL DEFAULT 0,
  `time_last_fired` int(10) DEFAULT NULL,
  `email` varchar(50) NOT NULL DEFAULT '',
  `ftpip` varchar(20) NOT NULL DEFAULT '',
  `ftpuname` varchar(20) NOT NULL DEFAULT '',
  `ftppass` varchar(20) NOT NULL DEFAULT '',
  `ftppath` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblDept
#

DROP TABLE IF EXISTS `xtblDept`;

CREATE TABLE `xtblDept` (
  `departmentcode` varchar(10) NOT NULL DEFAULT '',
  `groupcode` varchar(10) NOT NULL DEFAULT '',
  `departmentname` varchar(255) NOT NULL DEFAULT '',
  `departmenthead` varchar(50) NOT NULL DEFAULT '',
  `departmentheadtitle` varchar(50) NOT NULL DEFAULT '',
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`departmentcode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblDivision
#

DROP TABLE IF EXISTS `xtblDivision`;

CREATE TABLE `xtblDivision` (
  `divisionCode` varchar(20) NOT NULL DEFAULT '',
  `divisionName` varchar(100) NOT NULL DEFAULT '',
  `projectCode` text NOT NULL,
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `divisionHead` varchar(50) NOT NULL DEFAULT '',
  `divisionHeadTitle` varchar(50) NOT NULL DEFAULT '',
  `divisionCustodian` varchar(15) NOT NULL DEFAULT '',
  `divisionSecretary` varchar(15) NOT NULL DEFAULT '',
  `departmentcode` varchar(10) NOT NULL DEFAULT '',
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  `eoCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`divisionCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblEmpDeductConRemit
#

DROP TABLE IF EXISTS `xtblEmpDeductConRemit`;

CREATE TABLE `xtblEmpDeductConRemit` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(100) NOT NULL DEFAULT 0,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) DEFAULT NULL,
  `orNumber` varchar(20) DEFAULT NULL,
  `orDate` date NOT NULL DEFAULT '0000-00-00',
  `TYPE` varchar(20) NOT NULL DEFAULT '',
  `appointmentCode` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblEmpDeductContri
#

DROP TABLE IF EXISTS `xtblEmpDeductContri`;

CREATE TABLE `xtblEmpDeductContri` (
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `contriCode` int(100) NOT NULL AUTO_INCREMENT,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`contriCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblEmpDeductOtherAdjust
#

DROP TABLE IF EXISTS `xtblEmpDeductOtherAdjust`;

CREATE TABLE `xtblEmpDeductOtherAdjust` (
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `adjustSwitch` char(1) NOT NULL DEFAULT '',
  `adjustMonth` varchar(10) NOT NULL DEFAULT '0',
  `adjustYear` year(4) NOT NULL DEFAULT 0000,
  `appointmentCode` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblEmpDeductOtherRemit
#

DROP TABLE IF EXISTS `xtblEmpDeductOtherRemit`;

CREATE TABLE `xtblEmpDeductOtherRemit` (
  `processID` int(11) DEFAULT NULL,
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblEmpDeductReguAdjust
#

DROP TABLE IF EXISTS `xtblEmpDeductReguAdjust`;

CREATE TABLE `xtblEmpDeductReguAdjust` (
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `orNumber` varchar(20) DEFAULT NULL,
  `orDate` date DEFAULT NULL,
  `employerAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `adjustSwitch` char(1) NOT NULL DEFAULT '',
  `adjustMonth` varchar(10) NOT NULL DEFAULT '0',
  `adjustYear` year(4) NOT NULL DEFAULT 0000,
  `appointmentCode` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblEmpDeductReguRemit
#

DROP TABLE IF EXISTS `xtblEmpDeductReguRemit`;

CREATE TABLE `xtblEmpDeductReguRemit` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `orNumber` varchar(20) DEFAULT NULL,
  `orDate` date DEFAULT NULL,
  `employerAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `appointmentCode` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblExeOffice
#

DROP TABLE IF EXISTS `xtblExeOffice`;

CREATE TABLE `xtblExeOffice` (
  `eoCode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `eoName` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `eoHead` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `eoHeadTitle` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `eoCustodian` varchar(15) NOT NULL DEFAULT '',
  `eoSecretary` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`eoCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

#
# TABLE STRUCTURE FOR: xtblPlantillaGroup2
#

DROP TABLE IF EXISTS `xtblPlantillaGroup2`;

CREATE TABLE `xtblPlantillaGroup2` (
  `plantillaGroupCode` varchar(20) NOT NULL DEFAULT '',
  `plantillaGroupName` varchar(255) NOT NULL DEFAULT '',
  `plantillaGroupOrder` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblSection
#

DROP TABLE IF EXISTS `xtblSection`;

CREATE TABLE `xtblSection` (
  `sectionCode` varchar(20) NOT NULL DEFAULT '',
  `divisionCode` varchar(20) NOT NULL DEFAULT '',
  `sectionName` varchar(50) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `sectionHead` varchar(50) NOT NULL DEFAULT '',
  `sectionHeadTitle` varchar(50) NOT NULL DEFAULT '',
  `sectionCustodian` varchar(15) NOT NULL DEFAULT '',
  `sectionSecretary` varchar(15) NOT NULL DEFAULT '',
  `eoCode` varchar(20) NOT NULL DEFAULT '',
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`sectionCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: xtblService
#

DROP TABLE IF EXISTS `xtblService`;

CREATE TABLE `xtblService` (
  `serviceCode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `serviceName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `empNumber` varchar(15) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `serviceHead` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `serviceHeadTitle` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `serviceCustodian` varchar(15) NOT NULL DEFAULT '',
  `serviceSecretary` varchar(15) NOT NULL DEFAULT '',
  `eoCode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`serviceCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

#
# TABLE STRUCTURE FOR: xtblURLparam
#

DROP TABLE IF EXISTS `xtblURLparam`;

CREATE TABLE `xtblURLparam` (
  `url` text NOT NULL,
  `param` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

